"""Validate the exact production before/after HTTP matrix and provenance."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from benchmark_prefill_first_token import validate_cold, validate_overlap

p=Path(sys.argv[1])
data=json.loads(p.read_text())
expected=int(sys.argv[2])
assert len(data['rows'])==expected
assert 'summary' in data
assert data['_schema_version']==1
runner=Path(__file__).with_name('benchmark_prefill_default_routes.py' if p.parent.name=='qwen-default-routes' else 'benchmark_prefill_first_token.py')
assert data['_methodology_hash']==hashlib.sha256(runner.read_bytes()).hexdigest()
assert data['harness_sha256']==data['_methodology_hash']
for arm in data['arms']:
    assert arm['exit_code'] in (0,-15)
    source=subprocess.check_output(['git','show',arm['source_commit']+':rapid_mlx/scheduler.py'])
    assert hashlib.sha256(source).hexdigest()==arm['scheduler_sha256']
    trace=p.parent/(arm['label']+'.trace.jsonl')
    rows=[json.loads(line) for line in trace.read_text().splitlines()]
    assert rows
    assert all(0<row['dispatched']<=row['selected'] for row in rows)
    assert all(row['ended_ns']>=row['started_ns'] for row in rows)
seen=set()
for row in data['rows']:
    key=(row['arm'],row['cycle'],row['repeat'],row['workload'])
    assert key not in seen
    seen.add(key)
    validate_overlap(row['long'],row['short'])
    for which in ('long_solo','long','short_solo','short'):
        expected_answer=(
            '42' if row['workload']=='exact'
            else '7319' if which.startswith('long') else '9283'
        )
        receipt=row[which]
        validate_cold(receipt, expected_answer)
        assert receipt['done'] and receipt['finish_reason']=='stop'
        assert receipt['started_ns']<receipt['first_ns']<=receipt['ended_ns']
        assert hashlib.sha256(receipt['output_text'].encode()).hexdigest()==receipt['output_sha256']
        assert 0<receipt['usage']['completion_tokens']<=32
print(f'{expected} paired waves validated; exact/cold/terminal/overlap/provenance checks passed')
