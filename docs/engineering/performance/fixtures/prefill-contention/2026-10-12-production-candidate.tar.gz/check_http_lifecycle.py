"""Offline HTTP correctness/lifecycle probe; no timing claims."""
import argparse
import concurrent.futures as cf
import hashlib
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import time

import httpx

ap = argparse.ArgumentParser()
ap.add_argument('--model', required=True)
ap.add_argument('--output', type=Path, required=True)
ap.add_argument('--port', type=int, default=18362)
args = ap.parse_args()
root = Path('/private/tmp/rapid-mlx-prefill-contention/worktree')
args.output.mkdir(parents=True, exist_ok=False)
base = f'http://127.0.0.1:{args.port}'
env = {k: os.environ[k] for k in ('HOME', 'TMPDIR', 'PATH', 'LANG') if k in os.environ}
env.update(PYTHONPATH=str(root), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false')
command = [sys.executable, '-c', 'from rapid_mlx.cli import cli_entrypoint; cli_entrypoint()', 'serve', args.model, '--host', '127.0.0.1', '--port', str(args.port), '--served-model-name', 'lifecycle-probe', '--no-mllm', '--no-spec-decode', '--disable-disk-caches', '--disable-model-downloads', '--prefill-step-size', '512', '--prefill-batch-size', '8']
result = {'source_commit': subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip(), 'scheduler_sha256':hashlib.sha256((root/'rapid_mlx/scheduler.py').read_bytes()).hexdigest(), 'model_revision':Path(args.model).name, 'checks':[]}

def payload(text, *, stream=False, max_tokens=32):
    return dict(model='lifecycle-probe', messages=[{'role':'user','content':text}], temperature=0, max_tokens=max_tokens, stream=stream, enable_thinking=False, chat_template_kwargs={'enable_thinking':False})

def check_answer(row, expected='7319'):
    assert row['choices'][0]['message']['content'].strip() == expected, row
    assert row['choices'][0]['finish_reason'] == 'stop', row
    assert 0 < row['usage']['completion_tokens'] <= 32, row

def cached(row):
    return (row['usage'].get('prompt_tokens_details') or {}).get('cached_tokens',0)

with (args.output/'server.log').open('w') as log:
    proc = subprocess.Popen(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    try:
        with httpx.Client(timeout=180, trust_env=False) as client:
            deadline=time.monotonic()+180
            while time.monotonic()<deadline:
                assert proc.poll() is None, 'server exited'
                try:
                    if client.get(base+'/health/ready').status_code==200:
                        break
                except httpx.TransportError:
                    pass
                time.sleep(.2)
            else:
                raise TimeoutError('readiness')

            def idle():
                deadline=time.monotonic()+30
                while time.monotonic()<deadline:
                    s=client.get(base+'/v1/status').raise_for_status().json()
                    if s.get('num_running',0)==s.get('num_waiting',0)==0:
                        return s
                    time.sleep(.1)
                raise TimeoutError('orphaned active request')

            def ask(text):
                return client.post(base+'/v1/chat/completions', json=payload(text)).raise_for_status().json()

            prefix='These records belong to one archive.\n'+''.join(f'Record {i}: code {i*17+3}.\n' for i in range(400))+'Archive verification code: 7319.\n'
            question='What is the archive verification code? Reply with only its four digits.'
            client.post(base+'/v1/cache/clear').raise_for_status()
            first=ask(prefix+question); check_answer(first); assert cached(first)==0
            second=ask(prefix+question); check_answer(second); assert cached(second)>0
            third=ask(prefix+question+' Do not add explanation.'); check_answer(third); assert cached(third)>0
            idle()
            result['checks'].append({'name':'exact_and_shared_prefix_cache','cold':first,'exact_hit':second,'shared_hit':third})

            def stream_long(ids):
                with httpx.Client(timeout=180,trust_env=False) as c:
                    with c.stream('POST',base+'/v1/chat/completions',json=payload(' '.join(['independent']*16000)+' Explain the records.',stream=True,max_tokens=128)) as response:
                        response.raise_for_status()
                        seen_id=False; done=False
                        for line in response.iter_lines():
                            if not line.startswith('data:'): continue
                            data=line[5:].strip()
                            if data=='[DONE]': done=True; break
                            obj=json.loads(data)
                            if obj.get('id') and not seen_id:
                                ids.put(obj['id']); seen_id=True
                        return {'done':done}

            client.post(base+'/v1/cache/clear').raise_for_status()
            with cf.ThreadPoolExecutor(max_workers=2) as pool:
                ids=queue.Queue()
                cancelled=pool.submit(stream_long, ids)
                rid=ids.get(timeout=30)
                deadline=time.monotonic()+30
                while time.monotonic()<deadline:
                    s=client.get(base+'/v1/status').raise_for_status().json()
                    if s.get('num_running',0)>0: break
                    time.sleep(.01)
                else: raise TimeoutError('long never admitted')
                survivor=pool.submit(ask, prefix+question)
                deadline=time.monotonic()+30
                while time.monotonic()<deadline:
                    s=client.get(base+'/v1/status').raise_for_status().json()
                    if s.get('num_running',0)>=2: break
                    if cancelled.done(): raise RuntimeError('long completed before cancellation')
                    time.sleep(.01)
                else: raise TimeoutError('peer not admitted')
                response=client.post(base+f'/v1/requests/{rid}/cancel').raise_for_status().json()
                assert response['cancelled'] is True
                survivor_row=survivor.result(timeout=180); check_answer(survivor_row)
                cancelled_stream=cancelled.result(timeout=180)
            after=idle()
            assert client.post(base+f'/v1/requests/{rid}/cancel').status_code==404
            final=ask(prefix+question); check_answer(final)
            idle()
            result['checks'].append({'name':'cancel_long_while_peer_prefills','cancel_response':response,'cancelled_stream':cancelled_stream,'survivor':survivor_row,'after':after,'subsequent':final})
            result['passed']=True
    finally:
        proc.terminate()
        try: proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=10)
        result['exit_code']=proc.returncode
        (args.output/'results.json').write_text(json.dumps(result,indent=2)+'\n')
assert result['exit_code'] in (0,-15)
print('HTTP lifecycle checks passed')
