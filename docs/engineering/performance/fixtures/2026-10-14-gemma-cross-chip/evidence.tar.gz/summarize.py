import json,statistics,hashlib
from pathlib import Path
r=Path(__file__).parent
EXPECTED_SOURCE={'rapid_mlx/engine/batched.py': 'bcace87255ea857bdc254aea471a1f9bd3784a60e109019017f4c40d36d55f6c', 'rapid_mlx/engine_core.py': '476c4749dbb086622c04dc882fed292868b6020693e7279d3572bad7db96cfb7', 'rapid_mlx/scheduler.py': 'e2a69f0ef6ff8852efb168b41bbeeaee75e8553d07461f604d6d21a513cc675b', 'rapid_mlx/mllm_scheduler.py': '371351460318cc03242c087b8990eae3c571aa500a294269efcf3cd6009fba30', 'rapid_mlx/mllm_batch_generator.py': 'cb6f193b74cc1dceb8a82e165a23930e94471e9b998d784827284bebf1c5a6b8', 'rapid_mlx/_sampler_fast_path.py': 'f7a3cc06d93afa52af61d496e8603f0601b8bd1deb3536148177f2936ce2359e', 'rapid_mlx/models/gemma4_text.py': '843aee38d1424dd3a08272133b4aaf793c9580d6fb96c8171f5d6d27d3c14b36'}
EXPECTED_MODELS={'238767527555cb75a05732a84dff5d6ba0dd6809': {'.gitattributes': {'bytes': 1570, 'sha256': '34448b82c17d60fec9b65b1f093c115ddbaadc04beb1b0140b6bfed2e012a930'}, 'chat_template.jinja': {'bytes': 17336, 'sha256': '2f1b4d75d067bae3fe44e676721c7f077d243bc007156cb9c2f8b5836613d082'}, 'config.json': {'bytes': 6395, 'sha256': '6397cb6eca41b911d1dcab74e17941351057bd759284052a2331918ff6f9246c'}, 'generation_config.json': {'bytes': 208, 'sha256': 'd4226bbe3117d2d253ba4609720ba82c6c4ce4627a9a6ae05387c78983ac03de'}, 'model.safetensors': {'bytes': 3550670554, 'sha256': '038e39a37a7667373d2c3991375446b10c96ae1d717a68674870343db376b76e'}, 'model.safetensors.index.json': {'bytes': 218323, 'sha256': 'edb157dbf495e23f37377af4a628a9ad13c4ee7937f93ccb36ec9e9a19940f16'}, 'processor_config.json': {'bytes': 1316, 'sha256': 'de3e580aebdc98272d4c4547daffe6525fcbae18a83a0e0bcf0d7444d4ee6f37'}, 'tokenizer.json': {'bytes': 32169626, 'sha256': 'cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f'}, 'tokenizer_config.json': {'bytes': 2740, 'sha256': '080d9e1aff284e2f6043889cd05367966f7c7b80e025fbc0b06745e218158656'}}, '475b9088d29754a3379866cf5aeb6b41acd313c2': {'.gitattributes': {'bytes': 1570, 'sha256': '34448b82c17d60fec9b65b1f093c115ddbaadc04beb1b0140b6bfed2e012a930'}, 'chat_template.jinja': {'bytes': 17336, 'sha256': '2f1b4d75d067bae3fe44e676721c7f077d243bc007156cb9c2f8b5836613d082'}, 'config.json': {'bytes': 6628, 'sha256': '780ccb3a514a5f1ced161d383f948fc22eca9b84b752ca19494f625bd9bad7a6'}, 'generation_config.json': {'bytes': 208, 'sha256': 'd4226bbe3117d2d253ba4609720ba82c6c4ce4627a9a6ae05387c78983ac03de'}, 'model.safetensors': {'bytes': 5146800534, 'sha256': '932b8271fc3fe65adcc78b96c10c6268bbfb13e8f67d1358727c0d6ee97e1eff'}, 'model.safetensors.index.json': {'bytes': 240961, 'sha256': 'f8accac59ee7efe87e0c298c854610b262c3cadd477407503147c71209ff0093'}, 'processor_config.json': {'bytes': 1316, 'sha256': 'de3e580aebdc98272d4c4547daffe6525fcbae18a83a0e0bcf0d7444d4ee6f37'}, 'tokenizer.json': {'bytes': 32169626, 'sha256': 'cc8d3a0ce36466ccc1278bf987df5f71db1719b9ca6b4118264f45cb627bfe0f'}, 'tokenizer_config.json': {'bytes': 2740, 'sha256': '080d9e1aff284e2f6043889cd05367966f7c7b80e025fbc0b06745e218158656'}}}
EXPECTED_DEPENDENCIES={'mlx-vlm': {'files': 1450, 'aggregate_sha256': '2670ed206a160fed35fd011492d7fdb93e7a5f2ec540213c25ddc27c407f55e9'}, 'mlx-lm': {'files': 166, 'aggregate_sha256': 'b5d47b1382bf62e6dbe8a89c2d49fe1bace3bcbe14af0383d4590634cf9ad056'}}
EXPECTED_MODELS['0d77464eeb233a2da68ebf9d7dc4edaac7db956d']={'model-00001-of-00003.safetensors': {'bytes': 5320218487, 'sha256': '683f420ee09550b8027bf0335c4202e196b37eb520b60a4bcbe8690b9e388c07'}, 'model-00002-of-00003.safetensors': {'bytes': 5363328422, 'sha256': 'feab2873c2976fb7ed666f8462549564a29409364388e0c8f6b015729d165e15'}, 'model-00003-of-00003.safetensors': {'bytes': 4657658867, 'sha256': 'bc607486deb1de5bc7e459932fda5c776a4f816b368feaa661bab8cfbb47e567'}}
out={}
for host in ('m2-e2b','m4-e4b','m5-e2b','m5-26b'):
 p=r/'receipts'/host
 assert p.exists(),host
 required=['audit.json','metadata.json','gemma-balanced.json','gemma-quality.json']
 if host!='m4-e4b':required+=['last-logits-trials.json','last-logits-quality.json']
 for name in required:assert (p/name).exists(),(host,name)
 for suite in ('check_gemma.py','check_last_logits.py'):
  if suite=='check_last_logits.py' and host=='m4-e4b':continue
  expected_exit=1 if host=='m5-26b' and suite=='check_gemma.py' else 0
  assert int((p/(suite+'.exit')).read_text())==expected_exit,(host,suite)
 audit=json.loads((p/'audit.json').read_text())
 metadata=json.loads((p/'metadata.json').read_text())
 for pkg,d in audit['dependencies'].items():
  assert not d['mismatches']
  assert all(d[k]==v for k,v in EXPECTED_DEPENDENCIES[pkg].items())
 assert metadata['source']=='6d617f51cea61f9fa1cdd07a4dea11f66e04c355'
 for name,wanted in EXPECTED_SOURCE.items():assert metadata['source_hashes'][name]==wanted
 for name,wanted in EXPECTED_MODELS[audit['model_revision']].items():assert audit['model_files'][name]==wanted,(host,name)
 for pkg,version in {'mlx':'0.32.3','mlx-lm':'0.31.3','mlx-vlm':'0.7.2','transformers':'5.15.1','numpy':{'m2-e2b':'2.5.4','m4-e4b':'2.4.4','m5-e2b':'2.5.3','m5-26b':'2.5.3'}[host]}.items():assert metadata['versions'][pkg]==version,(host,pkg)
 result={}
 if (p/'last-logits-trials.json').exists():
  rows=json.loads((p/'last-logits-trials.json').read_text())
  assert len(rows)==64
  for case in (16,64,192,'image'):
   q={v:[x for x in rows if not x['warmup'] and x['variant']==v and x['case']==case] for v in ('baseline','last_logits')}
   assert all(len(x)==6 for x in q.values())
   assert all(x['correct'] for items in q.values() for x in items)
   a,b=[statistics.median(x['ttft_s'] for x in q[v]) for v in q]
   tokens={x['usage']['prompt_tokens'] for values in q.values() for x in values}
   assert len(tokens)==1
   result[str(case)]={'prompt_tokens':next(iter(tokens)),'baseline_ttft_s':a,'candidate_ttft_s':b,'reduction_pct':100*(1-b/a)}
  for run in range(4):
   probe=json.loads((p/f'last-logits-probe-{run}.json').read_text())
   shapes=[x['logits_shape'] for x in probe['events'] if 'logits_shape' in x]
   assert shapes
   if probe['variant']=='last_logits':assert all(x[1]==1 for x in shapes)
 if (p/'gemma-balanced.json').exists():
  rows=json.loads((p/'gemma-balanced.json').read_text());assert len(rows)==20
  med={}
  for case in ('solo_before','solo_after','active','waiter'):
   samples=[x for x in rows if x['case']==case]
   assert len(samples)==4 and len({x['text_sha256'] for x in samples})==1,(host,case)
   med[case]={v:{metric:statistics.median(x[metric] for x in samples if x['variant']==v) for metric in ('ttft_s','decode_s','total_s')} for v in ('baseline','native_prototype')}
  for run in range(4):
   active=next(x for x in rows if x['run']==run and x['case']=='active')
   waiter=next(x for x in rows if x['run']==run and x['case']=='waiter')
   assert active['first_ns']<waiter['started_ns']<active['ended_ns']
   assert (waiter['first_ns']<active['ended_ns'])==(waiter['variant']=='native_prototype')
   probe=json.loads((p/f"gemma-probe-{active['variant']}-balanced-{run}.json").read_text())
   if active['variant']=='native_prototype':
    start=next(x for x in probe if x.get('native_engine_started'))
    assert start['shared_language_identity'] and start['active_before']==start['active_after']
  result['routing']=med
 for name in ('last-logits-quality','gemma-quality'):
  if (p/(name+'.json')).exists():
   checks=json.loads((p/(name+'.json')).read_text());assert len(checks)==28,(host,name)
   failed=[x for x in checks if not x['pass']]
   if host=='m5-26b' and name=='gemma-quality':
    assert len(failed)==1
    f=failed[0]
    assert f['variant']=='baseline' and f['check']=='seeded_repeat' and f['first']!=f['second']
    assert all(x['pass'] for x in checks if x['variant']=='native_prototype')
    result[name]={'passed':27,'failed':1,'failed_control':'baseline_seeded_repeat'}
    result['routing_qualification']='not_fully_qualified_baseline_repeatability_control_failed'
   else:
    assert not failed,(host,name,failed)
    result[name]={'passed':len(checks),'failed':0}
 samples=[]
 expected_host_files=4 if host=='m4-e4b' else 8
 assert len(list(p.glob('last-logits-host-*.json')))+len(list(p.glob('gemma-host-*.json')))==expected_host_files
 for pat in ('last-logits-host-*.json','gemma-host-*.json'):
  for f in p.glob(pat):
   d=json.loads(f.read_text());assert d['exit']==0
   samples.extend(d['samples'])
 if samples:
  result['host_samples']={'count':len(samples),'swap_values':sorted({x['swap'] for x in samples}),'foreign_large_python_count':sum(len(x['foreign']) for x in samples)}
  assert result['host_samples']['foreign_large_python_count']==0
  assert len(result['host_samples']['swap_values'])==1
 out[host]=result
(r/'summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
