from pathlib import Path
import shutil
from huggingface_hub import snapshot_download
r=Path('/private/tmp/rapid-mlx-cross-gemma')
assert shutil.disk_usage(Path.home()).free>35*1024**3
print('Research #4649: larger Gemma4 26B-A4B ~15.37GB pinned weights for cross-size falsification, standard HF cache only; existing snapshot contains metadata only.',flush=True)
p=snapshot_download('mlx-community/gemma-4-26b-a4b-it-4bit',revision='0d77464eeb233a2da68ebf9d7dc4edaac7db956d',ignore_patterns=['*.md','*.png','*.jpg'])
(r/'gemma-26b-model-path').write_text(p)
print('26B model ready',flush=True)
