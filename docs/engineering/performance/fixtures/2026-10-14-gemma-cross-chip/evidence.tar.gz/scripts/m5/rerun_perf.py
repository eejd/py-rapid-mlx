from pathlib import Path
import subprocess,sys,os,shutil
r=Path('/private/tmp/rapid-mlx-cross-gemma')
p=r/'observer-failed-private';p.mkdir(exist_ok=False)
for pat in ['last-logits-trials.json','last-logits-probe-*.json','last-logits-host-*.json','last-logits-server-*.log','gemma-balanced.json','gemma-probe-*.json','gemma-host-*.json','gemma-balanced-server-*.log']:
 for f in r.glob(pat):shutil.move(f,p/f.name)
e=dict(os.environ,PYTHONPATH=str(r/'src'),RAPID_MLX_TELEMETRY='0')
for name in ['run_last_logits.py','run_gemma_balanced.py']:
 print('START repaired-observer',name,flush=True)
 with (r/(name+'.log')).open('w') as f:p=subprocess.run([sys.executable,str(r/name)],cwd=r/'src',env=e,stdout=f,stderr=subprocess.STDOUT)
 assert p.returncode==0,name
print('REPAIRED PERFORMANCE COMPLETE',flush=True)
