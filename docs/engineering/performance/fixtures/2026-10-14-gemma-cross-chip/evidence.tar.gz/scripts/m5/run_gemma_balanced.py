import asyncio
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import httpx
import psutil

ROOT = Path('/private/tmp/rapid-mlx-cross-gemma')
assert (ROOT / '.task-owner').read_text() == 'rapid-cross-gemma-20261014-v1'
rows = []
prompt = ('Write Python source code only. Define 1000 small functions named square_0001 through '
          'square_1000. Each function takes x, assigns result = x * x, and returns result. '
          'Put each function on separate lines. Do not use a loop or abbreviate the functions. '
          'Keep writing functions until the output limit. Start with def square_0001(x):')

async def request(client, run, variant, case, n, ready=None, trigger=None):
    if trigger is not None:
        await asyncio.wait_for(trigger.wait(), timeout=60)
    body = {'model': 'hotpath', 'messages': [{'role': 'user', 'content': prompt}],
            'max_tokens': n, 'temperature': 0, 'enable_thinking': False,
            'stream': True, 'stream_options': {'include_usage': True}}
    at = time.perf_counter_ns()
    arrivals, text, usage, done, finish = [], [], None, False, None
    async with client.stream('POST', '/v1/chat/completions', json=body) as response:
        response.raise_for_status()
        async for line in response.aiter_lines():
            if not line.startswith('data:'):
                continue
            payload = line[5:].strip()
            if payload == '[DONE]':
                done = True
                continue
            event = json.loads(payload)
            usage = event.get('usage') or usage
            for choice in event.get('choices', []):
                content = choice.get('delta', {}).get('content') or ''
                if content:
                    arrivals.append(time.perf_counter_ns())
                    text.append(content)
                    if ready is not None and len(arrivals) == 16:
                        ready.set()
                finish = choice.get('finish_reason') or finish
    end = time.perf_counter_ns()
    assert done and arrivals and usage and usage['completion_tokens'] == n and finish == 'length'
    row = {'run': run, 'variant': variant, 'case': case, 'budget': n, 'usage': usage,
           'ttft_s': (arrivals[0]-at)/1e9, 'decode_s': (end-arrivals[0])/1e9,
           'total_s': (end-at)/1e9, 'started_ns': at, 'first_ns': arrivals[0], 'ended_ns': end,
           'max_content_gap_s': max((b-a for a,b in zip(arrivals, arrivals[1:])), default=0)/1e9,
           'text_sha256': hashlib.sha256(''.join(text).encode()).hexdigest()}
    rows.append(row)
    (ROOT / 'gemma-balanced.json').write_text(json.dumps(rows, indent=2))
    print(json.dumps(row), flush=True)

async def trials(run, variant, proc):
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18646', timeout=300, trust_env=False) as client:
        deadline = time.monotonic() + 300
        while True:
            if proc.poll() is not None:
                raise RuntimeError('route server exited')
            try:
                if (await client.get('/health/ready')).status_code == 200:
                    break
            except httpx.HTTPError:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError('readiness')
            await asyncio.sleep(.5)
        await request(client, run, variant, 'warmup', 32)
        await request(client, run, variant, 'solo_before', 512)
        ready = asyncio.Event()
        await asyncio.gather(request(client, run, variant, 'active', 512, ready=ready),
                             request(client, run, variant, 'waiter', 64, trigger=ready))
        await request(client, run, variant, 'solo_after', 512)

import threading
for run, variant in enumerate(('baseline', 'native_prototype', 'native_prototype', 'baseline')):
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'), HOTPATH_ROUTE=variant,
               HOTPATH_RUN='balanced-'+str(run), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    host_samples = []
    stop = threading.Event()
    with (ROOT / f'gemma-balanced-server-{run}.log').open('w') as log:
        proc = subprocess.Popen([sys.executable, str(ROOT / 'serve_gemma.py')],
                                cwd=ROOT / 'src', env=env, stdout=log,
                                stderr=subprocess.STDOUT, start_new_session=True)
        (ROOT / 'active-pgid').write_text(str(proc.pid))
        def monitor():
            while not stop.wait(1):
                try:
                    foreign = []
                    for other in psutil.process_iter(['pid', 'name', 'memory_info', 'cmdline']):
                        item = other.info
                        if item['pid'] not in (os.getpid(), proc.pid) and 'python' in (item['name'] or '').lower() and item['memory_info'] is not None and item['memory_info'].rss > 512*1024**2:
                            if not any(str(ROOT) in str(arg) for arg in (item['cmdline'] or [])):
                                foreign.append({'pid': item['pid'], 'rss': item['memory_info'].rss})
                    host_samples.append({'at_ns': time.perf_counter_ns(),
                                         'rss': psutil.Process(proc.pid).memory_info().rss,
                                         'swap': psutil.swap_memory().used, 'foreign': foreign})
                except psutil.Error:
                    pass
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        try:
            asyncio.run(trials(run, variant, proc))
        finally:
            stop.set()
            thread.join(timeout=3)
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=10)
            (ROOT / 'active-pgid').unlink(missing_ok=True)
            (ROOT / f'gemma-host-{run}.json').write_text(json.dumps({'samples': host_samples, 'exit': proc.returncode}))
    assert proc.returncode == 0
for case in ('solo_before', 'solo_after', 'active', 'waiter'):
    assert len({r['text_sha256'] for r in rows if r['case'] == case}) == 1, case
print('Balanced campaign: all measured visible outputs exact across both routes.', flush=True)
