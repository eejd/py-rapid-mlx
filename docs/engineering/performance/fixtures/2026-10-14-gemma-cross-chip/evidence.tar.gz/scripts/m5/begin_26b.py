from pathlib import Path
import shutil,subprocess,os,sys,json
r=Path('/private/tmp/rapid-mlx-cross-gemma');old=r/'e2b-completed';old.mkdir(exist_ok=False)
for pat in ['metadata.json','audit.json','last-logits-trials.json','last-logits-probe-*.json','last-logits-host-*.json','last-logits-server-*.log','last-logits-quality*.json','last-logits-quality*.log','gemma-balanced.json','gemma-probe-*.json','gemma-host-*.json','gemma-balanced-server-*.log','gemma-quality*.json','gemma-quality*.log','*.exit']:
 for p in r.glob(pat):shutil.move(p,old/p.name)
(r/'gemma-model-path').write_text((r/'gemma-26b-model-path').read_text())
p=r/'check_last_logits.py';t=p.read_text().replace("for m in ('e2b',)","for m in ('26b',)").replace("('serve_last_logits.py' if model_key == 'e2b' else 'serve_last_logits_e4b.py')","'serve_last_logits.py'");p.write_text(t)
e=dict(os.environ,PYTHONPATH=str(r/'src'),RAPID_MLX_TELEMETRY='0')
subprocess.run([sys.executable,str(r/'audit.py')],env=e,check=True)
raise SystemExit(subprocess.call([sys.executable,str(r/'campaign.py')],env=e))
