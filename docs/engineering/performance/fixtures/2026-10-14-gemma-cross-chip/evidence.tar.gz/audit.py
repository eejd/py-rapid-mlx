from pathlib import Path
import importlib.metadata as m,hashlib,json,platform,subprocess,psutil,shutil,os
r=Path('/private/tmp/rapid-mlx-cross-gemma')
o=json.loads((r/'official-dependency-files.json').read_text())
results={}
for pkg,d in o.items():
 dist=m.distribution(pkg)
 mismatches=[]
 actual={}
 for n,wanted in d['python_files'].items():
  p=Path(dist.locate_file(n))
  got=hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
  actual[n]=got
  if got!=wanted: mismatches.append(n)
 results[pkg]={'version':m.version(pkg),'files':len(actual),'mismatches':mismatches,'aggregate_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
 assert not mismatches,(pkg,mismatches)
model=Path((r/'gemma-model-path').read_text())
files={}
for p in sorted(model.rglob('*')):
 if not p.is_file():continue
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
 files[str(p.relative_to(model))]={'bytes':p.stat().st_size,'sha256':h.hexdigest()}
a={'dependencies':results,'model_revision':model.name,'model_files':files,'platform':platform.platform(),'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':psutil.virtual_memory().total,'swap_used':psutil.swap_memory().used,'disk_free':shutil.disk_usage(Path.home()).free,'python':platform.python_version()}
(r/'audit.json').write_text(json.dumps(a,indent=2));print('AUDIT PASS',a['chip'],a['model_revision'],flush=True)
