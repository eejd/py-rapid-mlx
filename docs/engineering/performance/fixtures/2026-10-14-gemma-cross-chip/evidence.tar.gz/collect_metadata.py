import hashlib
import importlib.metadata as metadata
import json
import platform
from pathlib import Path
import subprocess
import sys

ROOT = Path('/private/tmp/rapid-mlx-cross-gemma')
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8*1024**2), b''):
            h.update(chunk)
    return h.hexdigest()

source = ROOT/'src'
names = ['rapid_mlx/engine/batched.py', 'rapid_mlx/engine_core.py', 'rapid_mlx/scheduler.py',
         'rapid_mlx/mllm_scheduler.py', 'rapid_mlx/mllm_batch_generator.py',
         'rapid_mlx/_sampler_fast_path.py', 'rapid_mlx/models/gemma4_text.py']
versions = {}
for name in ('mlx', 'mlx-lm', 'mlx-vlm', 'transformers', 'numpy', 'httpx', 'psutil',
             'rapid-mlx', 'pytest', 'pytest-asyncio'):
    try:
        versions[name] = metadata.version(name)
    except metadata.PackageNotFoundError:
        versions[name] = None
models = {}
for repo, revision in (
    ('mlx-community/Qwen3.5-4B-MLX-4bit', '32f3e8ecf65426fc3306969496342d504bfa13f3'),
    ('mlx-community/gemma-4-e2b-it-4bit', '238767527555cb75a05732a84dff5d6ba0dd6809')):
    snapshot = Path.home()/'.cache/huggingface/hub'/('models--'+repo.replace('/', '--'))/'snapshots'/revision
    models[repo] = {'revision': revision, 'files': {
        str(p.relative_to(snapshot)): {'bytes': p.stat().st_size, 'sha256': digest(p)}
        for p in sorted(snapshot.rglob('*')) if p.is_file()}}
result = {'source': '6d617f51cea61f9fa1cdd07a4dea11f66e04c355',
          'source_hashes': {n: digest(source/n) for n in names}, 'versions': versions,
          'python': sys.version, 'platform': platform.platform(),
          'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
          'memory_bytes': int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)),
          'models': models,
          'limitation': 'Source-level experiments through PYTHONPATH; inherited rapid-mlx distribution metadata is not a packaged release acceptance.'}
(ROOT/'metadata.json').write_text(json.dumps(result, indent=2))
print('Metadata and exact source/model hashes recorded.', flush=True)
