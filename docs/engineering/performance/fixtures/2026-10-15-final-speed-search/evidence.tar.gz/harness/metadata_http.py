import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-final-v1'
sys.path.insert(0, str(ROOT / 'src'))
import rapid_mlx
assert Path(rapid_mlx.__file__).resolve().is_relative_to(ROOT / 'src')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(block)
    return h.hexdigest()


versions = {n: metadata.version(n) for n in ['mlx', 'mlx-lm', 'mlx-vlm', 'transformers', 'tokenizers', 'numpy', 'httpx', 'psutil']}
models = {}
for repo, expected in json.loads((ROOT / 'expected-models.json').read_text()).items():
    snapshot = Path.home() / '.cache/huggingface/hub' / ('models--' + repo.replace('/', '--')) / 'snapshots' / expected['revision']
    files = {str(p.relative_to(snapshot)): {'bytes': p.stat().st_size, 'sha256': digest(p)} for p in snapshot.rglob('*') if p.is_file()}
    for name, identity in expected['large_files'].items():
        assert files[name] == identity, (repo, name)
    models[repo] = {'revision': expected['revision'], 'files': files}
dependencies = {}
for name, expected in json.loads((ROOT / 'official-dependency-files.json').read_text()).items():
    assert versions[name] == expected['version']
    dist = metadata.distribution(name)
    assert all(digest(Path(dist.locate_file(p))) == value for p, value in expected['python_files'].items())
    dependencies[name] = {'version': expected['version'], 'verified_python_files': len(expected['python_files']),
                          'official_wheel_sha256': expected['wheel_sha256']}
sources = ['rapid_mlx/engine/batched.py', 'rapid_mlx/scheduler.py', 'rapid_mlx/repetition_guard.py',
           'rapid_mlx/utils/decode.py', 'rapid_mlx/reasoning/think_stop.py', 'rapid_mlx/reasoning/harmony_stop.py']
harness = ['serve_profile.py', 'run_profile.py', 'serve_compare.py', 'run_compare.py', 'driver_compare.py', 'fast_decode_prototype.py']
result = {'source_commit': '5c70e238f6068d373553c48d92786a5cf333d05b',
          'source_hashes': {name: digest(ROOT / 'src' / name) for name in sources},
          'harness_sha256': {name: digest(ROOT / name) for name in harness},
          'versions': versions, 'dependencies': dependencies, 'models': models,
          'python': sys.version, 'platform': platform.platform(),
          'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
          'memory_bytes': int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)),
          'mlx_core_sha256': digest(Path(importlib.util.find_spec('mlx.core').origin)),
          'limitation': 'One M4, source checkout, private CPU hot-path prototypes, native text-only route selected explicitly. No release or other model/hardware qualification.'}
(ROOT / 'http-metadata.json').write_text(json.dumps(result, indent=2) + '\n')
print('Verified source/harness, official dependency Python files, cached model and tokenizer identities', flush=True)
