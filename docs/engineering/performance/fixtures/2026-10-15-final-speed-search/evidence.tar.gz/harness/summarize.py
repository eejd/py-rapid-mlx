"""Recompute final serving result and enforce evidence/activation contracts."""
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
RAW = ROOT / 'receipts'


def read(name):
    return json.loads((RAW / name).read_text())


status = read('compare-status.json')
profile = read('http-profile.json')
assert len(profile) == 4 and profile[0]['warmup']
assert [x['completion_tokens'] for x in profile] == [32, 512, 2048, 4096]
assert all(x['done'] and x['finish'] == 'length' and x['usage']['completion_tokens'] == x['completion_tokens'] for x in profile)
profile_host = read('host.json')
assert profile_host['server_exit'] == 0 and profile_host['samples']
assert not any(x['foreign'] for x in profile_host['samples'])
assert status == [{'variant': v, 'trial': t, 'exit': 0} for v, t in
                  [('baseline', 'A1'), ('candidate', 'B1'), ('candidate', 'B2'), ('baseline', 'A2')]]
trials = {}
for trial, variant in [('A1', 'baseline'), ('B1', 'candidate'), ('B2', 'candidate'), ('A2', 'baseline')]:
    rows = read(trial + '-http.json')
    assert len(rows) == 3 and rows[0]['warmup']
    assert [x['workload'] for x in rows] == ['warmup', 'python_service', 'sql_migration']
    for row in rows:
        assert row['variant'] == variant and row['trial'] == trial
        assert row['done'] and row['finish'] in ['length', 'stop']
        assert row['completion_tokens'] == row['usage']['completion_tokens'] > 0
        assert row['elapsed_s'] > row['ttft_s'] > 0
        assert row['cumulative_instrumentation']['route']['is_mllm'] is False
    counters = read(trial + '-instrumentation.json')['totals']
    assert counters['decode_add']['calls'] >= sum(x['completion_tokens'] for x in rows) - 3
    assert counters['guard_predict']['calls'] > 0 and counters['guard_detect']['calls'] > 0
    if variant == 'candidate':
        assert counters['fast_decode_activation']['calls'] >= sum(x['completion_tokens'] for x in rows) - 3
    else:
        assert counters.get('fast_decode_activation', {}).get('calls', 0) == 0
    host = read(trial + '-host.json')
    assert host['server_exit'] == 0 and host['samples']
    assert not any(x['foreign'] for x in host['samples']), (trial, 'foreign worker detected')
    trials[trial] = rows

results = []
for index in [1, 2]:
    cells = [trials[t][index] for t in ['A1', 'B1', 'B2', 'A2']]
    assert len({x['answer_sha256'] for x in cells}) == 1
    assert len({json.dumps(x['usage'], sort_keys=True) for x in cells}) == 1
    assert len({x['finish'] for x in cells}) == 1
    baseline = statistics.median(trials[t][index]['elapsed_s'] for t in ['A1', 'A2'])
    candidate = statistics.median(trials[t][index]['elapsed_s'] for t in ['B1', 'B2'])
    reduction = 100 * (1 - candidate / baseline)
    results.append({'workload': cells[0]['workload'], 'completion_tokens': cells[0]['completion_tokens'],
                    'baseline_median_s': baseline, 'candidate_median_s': candidate,
                    'latency_reduction_percent': reduction,
                    'answer_sha256': cells[0]['answer_sha256'], 'all_four_answers_equal': True,
                    'individual_elapsed_s': {t: trials[t][index]['elapsed_s'] for t in trials},
                    'greater_than_10_percent': reduction > 10})

metadata = read('http-metadata.json')
assert metadata['source_commit'] == '5c70e238f6068d373553c48d92786a5cf333d05b'
for name, expected in metadata['harness_sha256'].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
for name, expected in metadata['source_hashes'].items():
    assert hashlib.sha256((ROOT / 'worktree' / name).read_bytes()).hexdigest() == expected
for package, identity in metadata['dependencies'].items():
    expected = json.loads((ROOT / 'official-dependency-files.json').read_text())[package]
    assert identity['verified_python_files'] == len(expected['python_files'])
    assert identity['official_wheel_sha256'] == expected['wheel_sha256']

summary = {'source_commit': metadata['source_commit'], 'http_requests': 16,
           'measured_comparison_requests': 8, 'warmups': 5, 'attribution_measured_requests': 3,
           'comparison': results, 'any_qualified_workload': any(x['greater_than_10_percent'] for x in results)}
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
