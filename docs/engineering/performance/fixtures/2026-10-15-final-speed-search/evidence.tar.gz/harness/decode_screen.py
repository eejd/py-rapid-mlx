"""Compare existing full-prefix decode with native tokenizer streaming on CPU."""
from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import time

from tokenizers.decoders import DecodeStream
from transformers import AutoTokenizer

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
SOURCE = ROOT / 'worktree/rapid_mlx/utils/decode.py'
spec = importlib.util.spec_from_file_location('baseline_decoder', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

models = [
    ('qwen27b', 'models--mlx-community--Qwen3.6-27B-4bit', 'c000ac2c2057d94be3fa931000c31723aac53282'),
    ('gemma4b', 'models--mlx-community--gemma-4-e4b-it-4bit', '475b9088d29754a3379866cf5aeb6b41acd313c2'),
]
sentences = [
    'Write an implementation and explain its time complexity.\n',
    "def merge(xs):\n    return {'value': sum(xs), 'count': len(xs)}\n",
    '中文测试：加速需要保持正确性。🙂🚀 café naïve e\u0301\n',
    '  leading spaces\t\n\n',
    "I ' m testing spaces , punctuation ! \n",
    '<think>reasoning</think><tool_call>{"name":"write_file","arguments":{"path":"x.py"}}</tool_call>\n',
    '<|im_start|>assistant<|im_end|><|tool_call>call:f{a:1}<tool_call|>\n',
]


def compare(tokenizer, ids):
    baseline = module.IncrementalDecoder(tokenizer)
    native = DecodeStream(skip_special_tokens=False)
    differences = []
    errors = []
    for index, token in enumerate(ids):
        expected = baseline.add_token(token)
        try:
            actual = native.step(tokenizer.backend_tokenizer, token) or ''
        except Exception as exc:
            errors.append({'index': index, 'type': type(exc).__name__, 'message': str(exc)[:160]})
            break
        if actual != expected and len(differences) < 5:
            differences.append({'index': index, 'expected': expected, 'actual': actual})
    return {'tokens_checked': index + 1 if ids else 0, 'first_differences': differences, 'errors': errors,
            'all_delta_equal': not differences and not errors}


result = {'cpu_only': True, 'python': sys.version, 'platform': platform.platform(),
          'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
          'versions': {n: importlib.metadata.version(n) for n in ['transformers', 'tokenizers']},
          'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'models': []}
for label, repository, revision in models:
    snapshot = Path.home() / '.cache/huggingface/hub' / repository / 'snapshots' / revision
    tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=False)
    model = {'label': label, 'repository': repository, 'revision': revision,
             'tokenizer_sha256': hashlib.sha256((snapshot / 'tokenizer.json').read_bytes()).hexdigest(),
             'checks': {}, 'timings': []}
    for index, text in enumerate(sentences):
        ids = tokenizer.encode(text, add_special_tokens=False)
        model['checks'][f'text-{index}'] = compare(tokenizer, ids)
    rng = random.Random(7106)
    # Finite valid IDs can still produce non-monotonic/invalid UTF-8 prefixes.
    ids = [rng.choice(list(tokenizer.get_vocab().values())) for _ in range(500)]
    model['checks']['random-valid-ids'] = compare(tokenizer, ids)
    seed = tokenizer.encode(''.join(sentences[:4]) * 30, add_special_tokens=False)
    for count in [512, 2048, 8192]:
        ids = (seed * ((count // len(seed)) + 1))[:count]
        check = compare(tokenizer, ids)
        if not check['all_delta_equal']:
            model['timings'].append({'tokens': count, 'check': check, 'timing_accepted': False})
            continue
        samples = {'baseline': [], 'native': []}
        for repeat in range(4):
            for arm in (['baseline', 'native'] if repeat % 2 == 0 else ['native', 'baseline']):
                before = time.process_time()
                if arm == 'baseline':
                    decoder = module.IncrementalDecoder(tokenizer)
                    for token in ids:
                        decoder.add_token(token)
                else:
                    stream = DecodeStream(skip_special_tokens=False)
                    text = ''
                    for token in ids:
                        text += stream.step(tokenizer.backend_tokenizer, token) or ''
                samples[arm].append(time.process_time() - before)
        model['timings'].append({'tokens': count, 'check': check, 'timing_accepted': True,
                                 'samples_cpu_s': samples,
                                 'median_cpu_s': {k: statistics.median(v) for k, v in samples.items()}})
    result['models'].append(model)
    (ROOT / 'decode-screen.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({'model': label, 'correctness': {k:v['all_delta_equal'] for k,v in model['checks'].items()},
                      'timings': model['timings']}, ensure_ascii=False), flush=True)
