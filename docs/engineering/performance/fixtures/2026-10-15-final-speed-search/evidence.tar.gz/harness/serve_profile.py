import atexit
import collections
import functools
import json
import os
import signal
from pathlib import Path
import sys
import time

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-final-v1'
sys.path.insert(0, str(ROOT / 'src'))
import rapid_mlx.repetition_guard as guard
import rapid_mlx.utils.decode as decode

totals = collections.defaultdict(lambda: {'calls': 0, 'wall_s': 0.0, 'thread_cpu_s': 0.0})
route = {}


def instrument(owner, name, label):
    original = getattr(owner, name)

    @functools.wraps(original)
    def call(*args, **kwargs):
        wall = time.perf_counter()
        cpu = time.thread_time()
        try:
            return original(*args, **kwargs)
        finally:
            item = totals[label]
            item['calls'] += 1
            item['wall_s'] += time.perf_counter() - wall
            item['thread_cpu_s'] += time.thread_time() - cpu
    setattr(owner, name, call)


instrument(guard, 'predict_repeated_token_suffix', 'guard_predict')
instrument(guard, 'detect_repeated_token_suffix', 'guard_detect')
instrument(decode.IncrementalDecoder, 'add_token', 'decode_add')
instrument(decode.IncrementalDecoder, 'get_full_text', 'decode_full')
from rapid_mlx.engine.batched import BatchedEngine
original_start = BatchedEngine.start


async def start(self):
    await original_start(self)
    route.update({'is_mllm': self._is_mllm,
                  'model_type': type(self._model).__module__,
                  'spec_decode_configured': getattr(self, '_spec_decode_enabled', None)})
    assert not self._is_mllm


BatchedEngine.start = start


@atexit.register
def save():
    (ROOT / 'http-instrumentation.json').write_text(json.dumps({'at': time.time(), 'route': route, 'totals': dict(totals)}, indent=2))


signal.signal(signal.SIGUSR1, lambda *_: save())


from rapid_mlx.cli import cli_entrypoint
sys.argv = [sys.argv[0], 'serve', os.environ['STUDY_MODEL'], '--host', '127.0.0.1',
            '--port', '18649', '--served-model-name', 'decode-study', '--no-mllm',
            '--no-spec-decode', '--disable-prefix-cache', '--disable-disk-caches',
            '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
