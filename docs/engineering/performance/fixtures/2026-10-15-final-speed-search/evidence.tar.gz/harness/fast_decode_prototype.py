"""Private compatibility prototype; not installed in production source."""
from tokenizers.decoders import DecodeStream


def make_decoder(original):
    class FastDecoder:
        def __init__(self, tokenizer, skip_special_tokens=False):
            self._slow = original(tokenizer, skip_special_tokens=skip_special_tokens)
            self._backend = getattr(tokenizer, 'backend_tokenizer', None)
            self._enabled = self._backend is not None and not getattr(tokenizer, 'clean_up_tokenization_spaces', True)
            self._skip = skip_special_tokens
            self._stream = DecodeStream(skip_special_tokens=skip_special_tokens)
            self._full = None

        def add_token(self, token_id):
            self._full = None
            if not self._enabled:
                return self._slow.add_token(token_id)
            self._slow._token_ids.append(token_id)
            try:
                chunk = self._stream.step(self._backend, token_id)
            except Exception:
                chunk = '\ufffd'
            if chunk is not None and '\ufffd' not in chunk:
                self._slow._prev_text += chunk
                self._full = self._slow._prev_text
                return chunk
            if chunk is None:
                return ''
            # Preserve the original UTF-8 hold-back semantics permanently
            # after a non-monotonic or replacement-character boundary.
            self._enabled = False
            self._full = self._slow.get_full_text()
            delta = self._full[len(self._slow._prev_text):]
            if '\ufffd' in delta:
                return ''
            self._slow._prev_text = self._full
            return delta

        def get_full_text(self):
            if self._full is None:
                self._full = self._slow.get_full_text()
            return self._full

        @property
        def token_ids(self):
            return self._slow.token_ids

        @property
        def prev_text(self):
            return self._slow.prev_text

        def reset(self):
            self._slow.reset()
            self._stream = DecodeStream(skip_special_tokens=self._skip)
            self._full = None
    return FastDecoder
