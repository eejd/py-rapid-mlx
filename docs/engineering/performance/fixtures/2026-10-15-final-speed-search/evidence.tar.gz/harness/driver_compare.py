from pathlib import Path
import json, subprocess, sys
r=Path('/private/tmp/rapid-mlx-speed-search-final'); status=[]
for variant,trial in [('baseline','A1'),('candidate','B1'),('candidate','B2'),('baseline','A2')]:
 with (r/(trial+'-client.log')).open('w') as log:
  p=subprocess.run([sys.executable,str(r/'run_compare.py'),variant,trial],stdout=log,stderr=subprocess.STDOUT)
 status.append({'variant':variant,'trial':trial,'exit':p.returncode})
 (r/'compare-status.json').write_text(json.dumps(status,indent=2));print(status[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
