"""CPU screen of an exact rejection filter, without importing GPU libraries."""
from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path
import random
import statistics
import sys
import time
import types

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
SOURCE = ROOT / 'worktree/rapid_mlx/repetition_guard.py'
source = SOURCE.read_text()
cpu_source = source.replace('import mlx.core as mx', '# GPU import omitted for pure CPU functions')
needle = '        pattern = suffix[:period]\n'
assert cpu_source.count(needle) == 2
candidate_source = cpu_source.replace(needle, needle + '        if suffix[-period:] != pattern:\n            continue\n')


def load(name, body):
    module = types.ModuleType(name)
    sys.modules[name] = module
    exec(compile(body, str(SOURCE), 'exec'), module.__dict__)
    return module


baseline = load('guard_screen_baseline', cpu_source)
candidate = load('guard_screen_candidate', candidate_source)
functions = ['detect_repeated_token_suffix', 'predict_repeated_token_suffix']


def result(module, fn, tokens, kwargs):
    value = getattr(module, fn)(tokens, **kwargs)
    return None if value is None else dataclasses.asdict(value)


rng = random.Random(7105)
histories = []
for period in range(1, 129):
    pattern = list(range(period))
    for repeats in [1, 2, 3, 5, 12, 260]:
        tokens = (pattern * repeats)[-1200:]
        histories.extend([tokens, tokens[:-1], tokens + [99999]])
for _ in range(600):
    size = rng.randrange(1600)
    histories.append([rng.randrange(rng.choice([4, 200, 250000])) for _ in range(size)])
histories.extend([[], [0], [0] * 256, list(range(2000))])
settings = [{}, {'min_period_tokens': 2, 'max_period_tokens': 64,
                 'required_repeats': 4, 'min_repeated_tokens': 100,
                 'min_short_period_tokens': 300, 'max_window_tokens': 512}]
checks = matches = 0
for tokens in histories:
    for fn in functions:
        for kwargs in settings:
            ref = result(baseline, fn, tokens, kwargs)
            got = result(candidate, fn, tokens, kwargs)
            assert ref == got, (fn, kwargs, tokens, ref, got)
            checks += 1
            matches += ref is not None

rows = []
for size in [128, 512, 1024, 4096]:
    for vocabulary in [8, 250000]:
        tokens = [rng.randrange(vocabulary) for _ in range(size)]
        for fn in functions:
            samples = {'baseline': [], 'candidate': []}
            for repeat in range(8):
                for label in (['baseline', 'candidate'] if repeat % 2 == 0 else ['candidate', 'baseline']):
                    func = getattr(baseline if label == 'baseline' else candidate, fn)
                    before = time.process_time()
                    for _ in range(100):
                        func(tokens)
                    samples[label].append((time.process_time() - before) / 100)
            rows.append({'function': fn, 'history_tokens': size, 'vocabulary': vocabulary,
                         'samples_cpu_s': samples,
                         'median_cpu_s': {k: statistics.median(v) for k, v in samples.items()}})

out = {'source_sha256': hashlib.sha256(source.encode()).hexdigest(),
       'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
       'correctness_checks': checks, 'nonempty_reference_results': matches,
       'cpu_only': True, 'rows': rows}
(ROOT / 'guard-screen.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'correctness_checks': checks, 'nonempty_reference_results': matches,
                  'max_baseline_us': max(x['median_cpu_s']['baseline'] for x in rows) * 1e6,
                  'max_saving_us': max(x['median_cpu_s']['baseline'] - x['median_cpu_s']['candidate'] for x in rows) * 1e6}), flush=True)
