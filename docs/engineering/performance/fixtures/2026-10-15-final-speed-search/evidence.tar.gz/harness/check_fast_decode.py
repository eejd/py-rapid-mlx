"""Exact per-step delta, raw stop surface and reset checks for the prototype."""
import hashlib
import importlib.util
import json
from pathlib import Path

from transformers import AutoTokenizer
from fast_decode_prototype import make_decoder

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
spec = importlib.util.spec_from_file_location('baseline_decoder', ROOT / 'worktree/rapid_mlx/utils/decode.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
candidate = make_decoder(module.IncrementalDecoder)
metadata = json.loads((ROOT / 'decode-screen.json').read_text())
boundaries = json.loads((ROOT / 'decode-boundaries.json').read_text())
rows = []
for model in metadata['models']:
    snapshot = Path.home() / '.cache/huggingface/hub' / model['repository'] / 'snapshots' / model['revision']
    tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=False)
    for case in [x for x in boundaries['rows'] if x['model'] == model['label']]:
        for skip in [False, True]:
            baseline = module.IncrementalDecoder(tokenizer, skip_special_tokens=skip)
            fast = candidate(tokenizer, skip_special_tokens=skip)
            for _ in range(2):
                for token in case['token_ids']:
                    assert baseline.add_token(token) == fast.add_token(token), (model['label'], case['case'], token, skip)
                    assert baseline.get_full_text() == fast.get_full_text(), (model['label'], case['case'], 'stop surface', skip)
                    assert baseline.prev_text == fast.prev_text
                baseline.reset()
                fast.reset()
            rows.append({'model': model['label'], 'case': case['case'], 'skip_special_tokens': skip,
                         'steps': 2 * len(case['token_ids']), 'passed': True})
(ROOT / 'fast-decode-checks.json').write_text(json.dumps({'rows': rows, 'prototype_sha256': hashlib.sha256((ROOT / 'fast_decode_prototype.py').read_bytes()).hexdigest()}, indent=2) + '\n')
print('PASS', len(rows), 'case/settings; steps', sum(x['steps'] for x in rows))
