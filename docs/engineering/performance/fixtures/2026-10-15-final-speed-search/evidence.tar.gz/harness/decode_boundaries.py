"""Retain deterministic token sequences for streaming-surface boundary checks."""
import hashlib
import importlib.util
import json
from pathlib import Path
import random

from tokenizers.decoders import DecodeStream
from transformers import AutoTokenizer

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
spec = importlib.util.spec_from_file_location('baseline_decoder', ROOT / 'worktree/rapid_mlx/utils/decode.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
metadata = json.loads((ROOT / 'decode-screen.json').read_text())
results = []
for model in metadata['models']:
    snapshot = Path.home() / '.cache/huggingface/hub' / model['repository'] / 'snapshots' / model['revision']
    tokenizer = AutoTokenizer.from_pretrained(snapshot, local_files_only=True, trust_remote_code=False)
    rng = random.Random(7107)
    vocabulary = sorted(tokenizer.get_vocab().values())
    cases = {
        'random-valid-ids': [rng.choice(vocabulary) for _ in range(2000)],
        'unicode': tokenizer.encode('中文🙂 café e\u0301\n' * 30, add_special_tokens=False),
        'markers-and-stops': tokenizer.encode('<think>Do not stop at END</think>\nAnswer ends at END\n<|im_end|>', add_special_tokens=False),
        'replacement-character': tokenizer.encode('hello\ufffdworld\n', add_special_tokens=False),
    }
    for label, ids in cases.items():
        baseline = module.IncrementalDecoder(tokenizer)
        stream = DecodeStream(skip_special_tokens=False)
        native = ''
        differences = 0
        errors = []
        for index, token in enumerate(ids):
            expected = baseline.add_token(token)
            try:
                chunk = stream.step(tokenizer.backend_tokenizer, token) or ''
            except Exception as exc:
                errors.append({'index': index, 'type': type(exc).__name__, 'message': str(exc)[:160]})
                break
            differences += chunk != expected
            native += chunk
        full = baseline.get_full_text()
        results.append({'model': model['label'], 'case': label, 'token_ids': ids,
                        'processed': index + 1, 'delta_differences': differences, 'errors': errors,
                        'visible_concatenation_equal': native == baseline.prev_text,
                        'native_equals_full_decode': native == full,
                        'baseline_visible_chars': len(baseline.prev_text), 'native_visible_chars': len(native),
                        'baseline_visible_sha256': hashlib.sha256(baseline.prev_text.encode()).hexdigest(),
                        'native_visible_sha256': hashlib.sha256(native.encode()).hexdigest(),
                        'full_decode_sha256': hashlib.sha256(full.encode()).hexdigest()})
(ROOT / 'decode-boundaries.json').write_text(json.dumps({'harness_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'rows': results}, indent=2) + '\n')
for row in results:
    print(row['model'], row['case'], row['delta_differences'], row['visible_concatenation_equal'], row['native_equals_full_decode'])
