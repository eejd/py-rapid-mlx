"""Actual HTTP cost attribution only: no optimization or disabled guard."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import httpx
import psutil

ROOT = Path('/private/tmp/rapid-mlx-speed-search-final')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-final-v1'
snapshot = Path.home() / '.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3'
assert snapshot.is_dir()
environment = dict(os.environ, PYTHONPATH=str(ROOT / 'src'), STUDY_MODEL=str(snapshot),
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', RAPID_MLX_TELEMETRY='0', DO_NOT_TRACK='1')
samples = []
rows = []
stopping = threading.Event()
with (ROOT / 'server.log').open('w') as log:
    process = subprocess.Popen([sys.executable, str(ROOT / 'serve_profile.py')], cwd=ROOT / 'src',
                               env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    (ROOT / 'active-pgid.json').write_text(json.dumps({'pgid': process.pid}))

    def monitor():
        while not stopping.wait(1):
            try:
                foreign = []
                for p in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_times']):
                    info = p.info
                    if info['pid'] not in [os.getpid(), process.pid] and 'python' in (info['name'] or '').lower() and info['memory_info'] and info['memory_info'].rss > 512 * 1024**2:
                        foreign.append({'pid': info['pid'], 'rss': info['memory_info'].rss,
                                        'cpu_s': sum(info['cpu_times'][:2]) if info['cpu_times'] else None})
                samples.append({'at': time.time(), 'rss': psutil.Process(process.pid).memory_info().rss,
                                'swap': psutil.swap_memory().used, 'foreign': foreign})
            except psutil.Error:
                pass
    thread = threading.Thread(target=monitor, daemon=True)
    thread.start()
    try:
        with httpx.Client(base_url='http://127.0.0.1:18649', timeout=300, trust_env=False) as client:
            deadline = time.monotonic() + 240
            while True:
                if process.poll() is not None:
                    raise RuntimeError('Server exited')
                try:
                    if client.get('/health/ready').status_code == 200:
                        break
                except httpx.HTTPError:
                    pass
                if time.monotonic() > deadline:
                    raise TimeoutError('Readiness')
                time.sleep(.5)
            for index, count in enumerate([32, 512, 2048, 4096]):
                body = {'model': 'decode-study', 'messages': [{'role': 'user', 'content':
                        'Write Python source only. Do not call tools. Define 1000 functions named square_0001 through square_1000. Each takes x, assigns result = x * x, and returns result. Do not abbreviate or use a loop. Keep writing functions until the output limit. Start with def square_0001(x):'}],
                        'tools': [{'type': 'function', 'function': {'name': 'read_file', 'description': 'Read a file if needed.',
                                   'parameters': {'type': 'object', 'properties': {'path': {'type': 'string'}}}}}],
                        'temperature': 0, 'enable_thinking': False, 'stop': ['<END-OF-ANSWER>'],
                        'max_tokens': count, 'stream': True, 'stream_options': {'include_usage': True}}
                answer, stamps = [], []
                done, finish, usage = False, None, None
                before = time.perf_counter()
                with client.stream('POST', '/v1/chat/completions', json=body) as response:
                    response.raise_for_status()
                    for line in response.iter_lines():
                        if not line.startswith('data:'):
                            continue
                        raw = line[5:].strip()
                        if raw == '[DONE]':
                            done = True
                            continue
                        event = json.loads(raw)
                        usage = event.get('usage') or usage
                        for choice in event.get('choices', []):
                            delta = choice.get('delta') or {}
                            assert not delta.get('tool_calls'), delta
                            text = delta.get('content') or delta.get('reasoning_content') or ''
                            if text:
                                answer.append(text)
                                stamps.append(time.perf_counter())
                            finish = choice.get('finish_reason') or finish
                elapsed = time.perf_counter() - before
                assert done and stamps and usage and finish == 'length', (done, finish, usage)
                assert usage['completion_tokens'] == count
                text = ''.join(answer)
                assert 'def square_' in text
                sampled_at = time.time()
                process.send_signal(signal.SIGUSR1)
                checkpoint = ROOT / 'http-instrumentation.json'
                for _ in range(100):
                    try:
                        counters = json.loads(checkpoint.read_text())
                        if counters['at'] >= sampled_at:
                            break
                    except (FileNotFoundError, json.JSONDecodeError):
                        pass
                    time.sleep(.02)
                else:
                    raise TimeoutError('Instrumentation checkpoint')
                row = {'index': index, 'warmup': index == 0, 'completion_tokens': count,
                       'elapsed_s': elapsed, 'ttft_s': stamps[0] - before, 'usage': usage,
                       'finish': finish, 'done': done, 'answer_sha256': hashlib.sha256(text.encode()).hexdigest(),
                       'answer_prefix': text[:100], 'sse_content_chunks': len(stamps),
                       'cumulative_instrumentation': counters}
                rows.append(row)
                (ROOT / 'http-profile.json').write_text(json.dumps(rows, indent=2))
                print(json.dumps(row), flush=True)
    finally:
        stopping.set()
        thread.join(timeout=3)
        if process.poll() is None:
            process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=15)
        (ROOT / 'host.json').write_text(json.dumps({'samples': samples, 'server_exit': process.returncode}, indent=2))
        (ROOT / 'active-pgid.json').unlink(missing_ok=True)
assert process.returncode == 0
