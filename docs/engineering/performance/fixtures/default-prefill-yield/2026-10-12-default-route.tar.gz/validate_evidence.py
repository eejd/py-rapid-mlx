"""Validate the exact production before/after HTTP matrix and provenance."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys

from benchmark_default_prefill import validate_cold, validate_overlap

p = Path(sys.argv[1])
data = json.loads(p.read_text())
expected = int(sys.argv[2])
assert len(data["rows"]) == expected
assert data.get("complete") and "summary" in data
assert data["_schema_version"] == 1
runner = Path(__file__).with_name("benchmark_default_prefill.py")
assert data["_methodology_hash"] == hashlib.sha256(runner.read_bytes()).hexdigest()
assert data["harness_sha256"] == data["_methodology_hash"]
for arm in data["arms"]:
    assert arm["exit_code"] in (0, -15)
    assert arm["final_status"].get("num_running", 0) == 0
    assert arm["final_status"].get("num_waiting", 0) == 0
    for name, expected_hash in arm["source_sha256"].items():
        source = subprocess.check_output(
            ["git", "show", arm["source_commit"] + ":" + name]
        )
        assert hashlib.sha256(source).hexdigest() == expected_hash
    trace = p.parent / (arm["label"] + ".trace.jsonl")
    rows = [json.loads(line) for line in trace.read_text().splitlines()]
    assert rows
    assert all(
        0 < row["dispatched"] <= row["selected"]
        for row in rows
        if row.get("lane") != "mllm"
    )
    if "candidate" in arm["label"]:
        assert any(row.get("suspended") for row in rows)
        assert all(row["cooperative"] for row in rows if row.get("lane") == "mllm")
    assert all(row["ended_ns"] >= row["started_ns"] for row in rows)
seen = set()
for row in data["rows"]:
    key = (row["arm"], row["cycle"], row["repeat"], row["workload"])
    assert key not in seen
    seen.add(key)
    validate_overlap(row["long"], row["short"])
    for which in ("long_solo", "long", "short_solo", "short"):
        expected_answer = (
            "42"
            if row["workload"] == "exact"
            else "7319"
            if which.startswith("long")
            else "9283"
        )
        receipt = row[which]
        validate_cold(receipt, expected_answer)
        assert receipt["done"] and receipt["finish_reason"] == "stop"
        assert receipt["started_ns"] < receipt["first_ns"] <= receipt["ended_ns"]
        assert (
            hashlib.sha256(receipt["output_text"].encode()).hexdigest()
            == receipt["output_sha256"]
        )
        assert 0 < receipt["usage"]["completion_tokens"] <= 32
        assert receipt["usage"]["total_tokens"] == (
            receipt["usage"]["prompt_tokens"] + receipt["usage"]["completion_tokens"]
        )
print(
    f"{expected} paired waves validated; exact/cold/terminal/overlap/provenance checks passed"
)

lifecycle = json.loads(
    (p.parent.parent / "http-lifecycle-paused/results.json").read_text()
)
assert lifecycle["passed"] and lifecycle["exit_code"] in (0, -15)
for name, expected_hash in lifecycle["source_sha256"].items():
    source = subprocess.check_output(
        ["git", "show", lifecycle["source_commit"] + ":" + name]
    )
    assert hashlib.sha256(source).hexdigest() == expected_hash
prefix, cancel = lifecycle["checks"]
for receipt in (
    prefix["cold"],
    prefix["exact_hit"],
    prefix["shared_hit"],
    cancel["survivor"],
    cancel["subsequent"],
):
    assert receipt["choices"][0]["message"]["content"].strip() == "7319"
    assert receipt["choices"][0]["finish_reason"] == "stop"
    assert 0 < receipt["usage"]["completion_tokens"] <= 32
    assert (
        receipt["usage"]["total_tokens"]
        == receipt["usage"]["prompt_tokens"] + receipt["usage"]["completion_tokens"]
    )
assert (
    prefix["cold"]["usage"].get("prompt_tokens_details", {}).get("cached_tokens", 0)
    == 0
)
for receipt in (prefix["exact_hit"], prefix["shared_hit"]):
    assert receipt["usage"]["prompt_tokens_details"]["cached_tokens"] == 5454
assert (
    cancel["suspended_before_cancel"]["pending_id"] == cancel["cancel_response"]["id"]
)
assert cancel["cancel_response"]["cancelled"]
assert (
    cancel["cancelled_stream"]["done"]
    and not cancel["cancelled_stream"]["content_seen"]
)
assert cancel["after"]["num_running"] == cancel["after"]["num_waiting"] == 0
print(
    "Default-route exact/shared cache, suspended cancellation, survivor, idle and subsequent request checks passed"
)
