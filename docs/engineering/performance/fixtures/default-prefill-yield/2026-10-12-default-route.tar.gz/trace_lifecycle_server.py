"""Observe suspended prefill identity without changing serving decisions."""

import json
from pathlib import Path
import sys
import time

from rapid_mlx.cli import cli_entrypoint
from rapid_mlx.mllm_batch_generator import MLLMBatchGenerator

trace = Path(sys.argv.pop(1)).open("w", buffering=1)
original = MLLMBatchGenerator.next


def observe(self):
    responses = original(self)
    pending = self._pending_prefill
    trace.write(
        json.dumps(
            {
                "at_ns": time.perf_counter_ns(),
                "pending_id": pending[0].request_id if pending else None,
                "responses": len(responses),
            }
        )
        + "\n"
    )
    return responses


MLLMBatchGenerator.next = observe
cli_entrypoint()
