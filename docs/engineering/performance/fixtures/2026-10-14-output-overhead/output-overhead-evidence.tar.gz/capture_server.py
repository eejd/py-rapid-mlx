import json,sys,time
from pathlib import Path
from rapid_mlx.mllm_scheduler import MLLMScheduler
from rapid_mlx.scheduler import Scheduler
from rapid_mlx.cli import cli_entrypoint
ROOT=Path('/private/tmp/rapid-mlx-decode-output-exp')
trace=(ROOT/'native-events.jsonl').open('a',buffering=1)

def install(cls,lane):
 original=cls._process_batch_responses
 states={}
 def observe(self,responses):
  wall=time.perf_counter_ns();cpu=time.thread_time_ns()
  result=original(self,responses)
  cpu=time.thread_time_ns()-cpu;wall=time.perf_counter_ns()-wall
  outs=result[0]
  for out in outs:
   state=states.setdefault(out.request_id,{'lane':lane,'events':0,'response_cpu_ns':0,'response_wall_ns':0,'history_objects':set(),'started_ns':time.perf_counter_ns()})
   state['events']+=1;state['response_cpu_ns']+=cpu;state['response_wall_ns']+=wall
   state['history_objects'].add(id(out.output_token_ids))
   if out.finished:
    state=states.pop(out.request_id)
    state['history_objects']=len(state['history_objects']);state['request_id']=out.request_id
    state['native_ids']=list(out.output_token_ids);state['completion_tokens']=out.completion_tokens
    state['prompt_tokens']=out.prompt_tokens;state['finish_reason']=out.finish_reason
    state['ended_ns']=time.perf_counter_ns()
    trace.write(json.dumps(state)+'\n')
  return result
 cls._process_batch_responses=observe
install(MLLMScheduler,'mllm');install(Scheduler,'native')
model=(ROOT/'model-path').read_text().strip()
sys.argv=[sys.argv[0],'serve',model,'--host','127.0.0.1','--port','18645','--served-model-name','decode-overhead','--no-spec-decode','--disable-disk-caches','--disable-model-downloads','--log-level','WARNING']
cli_entrypoint()
