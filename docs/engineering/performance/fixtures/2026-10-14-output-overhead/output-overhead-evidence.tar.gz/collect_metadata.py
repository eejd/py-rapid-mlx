import hashlib,importlib.metadata,json,platform,subprocess,sys
from pathlib import Path
ROOT=Path('/private/tmp/rapid-mlx-decode-output-exp')
model=Path((ROOT/'model-path').read_text().strip())
hardware=json.loads(subprocess.check_output(['system_profiler','SPHardwareDataType','-json'],text=True))['SPHardwareDataType'][0]
meta={'source_revision':'6d617f51c','python':sys.version,'os':platform.mac_ver()[0],'machine':platform.machine(),'chip':hardware.get('chip_type'),'memory':hardware.get('physical_memory'),'cpu_cores':hardware.get('number_processors'),'packages':{n:importlib.metadata.version(n) for n in ('rapid-mlx','mlx','mlx-lm','mlx-vlm','transformers','numpy','httpx','psutil')},'model_revision':model.name,'model_hashes':{},'source_hashes':{}}
for f in model.iterdir():
 if f.is_file():
  h=hashlib.sha256()
  with f.open('rb') as stream:
   for block in iter(lambda:stream.read(4*1024**2),b''):h.update(block)
  meta['model_hashes'][f.name]=h.hexdigest()
for rel in ('rapid_mlx/mllm_scheduler.py','rapid_mlx/scheduler.py','rapid_mlx/speculative/tensorfold_qwen27_server.py','rapid_mlx/engine_core.py'):
 meta['source_hashes'][rel]=hashlib.sha256((ROOT/'src'/rel).read_bytes()).hexdigest()
(ROOT/'metadata.json').write_text(json.dumps(meta,indent=2))
print(json.dumps({k:v for k,v in meta.items() if k not in ('model_hashes','source_hashes')}))
