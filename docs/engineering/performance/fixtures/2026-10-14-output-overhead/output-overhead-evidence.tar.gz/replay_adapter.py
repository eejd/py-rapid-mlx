import argparse,hashlib,importlib.util,json,os,queue,resource,sys,threading,time,tracemalloc
from pathlib import Path
from types import SimpleNamespace
import psutil
ROOT=Path('/private/tmp/rapid-mlx-decode-output-exp')
parser=argparse.ArgumentParser();parser.add_argument('--child',action='store_true');parser.add_argument('--variant',choices=['current','terminal_only','linear']);parser.add_argument('--n',type=int);parser.add_argument('--trace',action='store_true');args=parser.parse_args()
if not args.child:raise SystemExit('child-only replay harness')
from tensorfold.families.tokenizer import load_tokenizer
path=ROOT/'src/rapid_mlx/speculative/tensorfold_qwen27_server.py';source=path.read_text();source_hash=hashlib.sha256(source.encode()).hexdigest()
if args.variant in ('terminal_only','linear'):
 assert source.count('outputs.append(output)')==2
 assert source.count('outputs.append(terminal)')==1
 source=source.replace('outputs.append(output)','outputs[:] = [output]').replace('outputs.append(terminal)','outputs[:] = [terminal]')
if args.variant=='linear':
 assert source.count('output_token_ids=list(collected)')==3
 source=source.replace('output_token_ids=list(collected)','output_token_ids=collected',1)
name='rapid_mlx.speculative._experiment_replay_provider'
spec=importlib.util.spec_from_loader(name,loader=None,origin=str(path));module=importlib.util.module_from_spec(spec);sys.modules[name]=module;exec(compile(source,str(path),'exec'),module.__dict__)
tokenizer=load_tokenizer(Path((ROOT/'model-path').read_text().strip()))
# Choose the first actual native response of the requested length, never synthesize token IDs.
records=[json.loads(line) for line in (ROOT/'native-events.jsonl').read_text().splitlines()]
record=next(x for x in records if x['completion_tokens']==args.n)
ids=record['native_ids'];assert len(ids)==args.n
class Scheduler:
 def submit(self,job):
  for token in ids:job.chunks.put([token])
  job.chunks.put(None);job.error=None;job.cached_tokens=0;job.stream=SimpleNamespace(finish_reason='length')
app=SimpleNamespace(tokenizer=tokenizer,tokenizer_lock=threading.Lock(),stop_ids=frozenset(),min_match=3,scheduler=Scheduler(),_resolve_sampling=lambda *a:None)
provider=module.TensorFoldRequestProvider(SimpleNamespace(_app=app))
expected=tokenizer.decode(ids);expected_hash=hashlib.sha256(expected.encode()).hexdigest()
before_rss=psutil.Process().memory_info().rss
if args.trace:tracemalloc.start()
at=time.perf_counter_ns();cpu=time.process_time_ns();text_hash=hashlib.sha256();tokens=[];chars=0
for item in provider.stream_generate(None,None,'Replay actual ordinary decode output.',max_tokens=len(ids),temperature=0):
 text_hash.update(item.text.encode());chars+=len(item.text)
 if item.token>=0:tokens.append(item.token)
cpu_ns=time.process_time_ns()-cpu;wall_ns=time.perf_counter_ns()-at
peak=tracemalloc.get_traced_memory()[1] if args.trace else None
if args.trace:tracemalloc.stop()
assert tokens==ids and provider.last_token_ids==ids
assert text_hash.hexdigest()==expected_hash
terminal=provider.last_outputs[-1];assert terminal.finished and terminal.output_token_ids==ids and terminal.output_text==expected
print(json.dumps({'variant':args.variant,'n':args.n,'trace':args.trace,'wall_s':wall_ns/1e9,'cpu_s':cpu_ns/1e9,'rss_before':before_rss,'rss_after':psutil.Process().memory_info().rss,'peak_rss':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'traced_peak_bytes':peak,'retained_records':len(provider.last_outputs),'retained_history_items':sum(len(o.output_token_ids) for o in provider.last_outputs),'text_sha256':text_hash.hexdigest(),'token_sha256':hashlib.sha256(','.join(map(str,ids)).encode()).hexdigest(),'chars':chars,'source_sha256':source_hash,'experiment_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'all_correct':True}))
