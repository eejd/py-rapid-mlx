import hashlib,json,os,signal,subprocess,sys,threading,time
from datetime import datetime,timezone
from pathlib import Path
import httpx,psutil
ROOT=Path('/private/tmp/rapid-mlx-decode-output-exp');assert (ROOT/'.task-owner').read_text()=='rapid-decode-output-m4-20261014-v1'
env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',PYTHONPATH=str(ROOT/'src'))
log=(ROOT/'native-server.log').open('w')
proc=subprocess.Popen([sys.executable,str(ROOT/'capture_server.py')],cwd=ROOT/'src',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
(ROOT/'active-pgid').write_text(str(proc.pid));stop=threading.Event();samples=[]
def monitor():
 p=psutil.Process(proc.pid);p.cpu_percent()
 while not stop.wait(1):
  try:
   busy=[]
   for o in psutil.process_iter(['pid','name','memory_info','cpu_percent']):
    i=o.info
    if i['pid'] not in (os.getpid(),proc.pid) and 'python' in (i['name'] or '').lower() and i['memory_info'].rss>512*1024**2:busy.append({'pid':i['pid'],'rss':i['memory_info'].rss,'cpu':i['cpu_percent']})
   samples.append({'at_ns':time.perf_counter_ns(),'rss':p.memory_info().rss,'cpu':p.cpu_percent(),'foreign_large_python':busy,'swap':psutil.swap_memory().used})
  except psutil.Error:pass
thread=threading.Thread(target=monitor,daemon=True);thread.start()
results={'source':'6d617f51c','model_revision':'32f3e8ecf65426fc3306969496342d504bfa13f3','utc':datetime.now(timezone.utc).isoformat(),'instrumentation':'thread CPU/wall around existing scheduler response processing; no serving decisions changed','rows':[]}
try:
 with httpx.Client(base_url='http://127.0.0.1:18645',timeout=600,trust_env=False) as client:
  deadline=time.monotonic()+300
  while time.monotonic()<deadline:
   if proc.poll() is not None:raise RuntimeError('server exited')
   try:
    if client.get('/health/ready').status_code==200:break
   except httpx.HTTPError:pass
   time.sleep(.5)
  else:raise TimeoutError('readiness')
  results['status']=client.get('/v1/status').json()
  prompt='Write Python source code only. Define 1000 small functions named square_0001 through square_1000. Each function takes x, assigns result = x * x, and returns result. Put each function on separate lines. Do not use a loop or abbreviate the functions. Keep writing functions until the output limit. Start with def square_0001(x):'
  for index,n in enumerate((32,512,2048,4096,4096,2048,512)):
   before=psutil.Process(proc.pid).cpu_times();at=time.perf_counter_ns();first=None;usage=None;done=False;finish=None;pieces=[];rid=None
   with client.stream('POST','/v1/chat/completions',json={'model':'decode-overhead','messages':[{'role':'user','content':prompt}],'max_tokens':n,'temperature':0,'enable_thinking':False,'stream':True,'stream_options':{'include_usage':True}}) as response:
    response.raise_for_status()
    for line in response.iter_lines():
     if not line.startswith('data:'):continue
     body=line[5:].strip()
     if body=='[DONE]':done=True;continue
     d=json.loads(body);rid=d.get('id',rid)
     if d.get('usage'):usage=d['usage']
     for choice in d.get('choices',[]):
      text=choice.get('delta',{}).get('content') or ''
      if text:
       if first is None:first=time.perf_counter_ns()
       pieces.append(text)
      if choice.get('finish_reason'):finish=choice['finish_reason']
   end=time.perf_counter_ns();after=psutil.Process(proc.pid).cpu_times()
   assert done and usage and first and finish
   row={'index':index,'warmup':index==0,'request_id':rid,'max_tokens':n,'usage':usage,'finish_reason':finish,'ttft_s':(first-at)/1e9,'total_s':(end-at)/1e9,'decode_s':(end-first)/1e9,'server_cpu_s':after.user+after.system-before.user-before.system,'text_sha256':hashlib.sha256(''.join(pieces).encode()).hexdigest(),'text_chars':sum(map(len,pieces)),'done':done}
   results['rows'].append(row);(ROOT/'native-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
  results['status_after']=client.get('/v1/status').json()
finally:
 stop.set();thread.join(timeout=3)
 results['host_samples']=samples
 proc.send_signal(signal.SIGINT)
 try:proc.wait(timeout=30)
 except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);proc.wait(timeout=15)
 (ROOT/'active-pgid').unlink(missing_ok=True);log.close()
 results['server_exit']=proc.returncode
 (ROOT/'native-results.json').write_text(json.dumps(results,indent=2))
