import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/private/tmp/rapid-mlx-decode-output-exp');env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',DO_NOT_TRACK='1',PYTHONPATH=str(ROOT/'src')+os.pathsep+str(ROOT/'runtime-src/src'))
rows=[]
for trace,cycle in ((False,0),(False,1),(True,0)):
 ns=(512,2048,4096) if cycle==0 else (4096,2048,512)
 arms=('current','terminal_only','linear') if cycle==0 else ('linear','terminal_only','current')
 for n in ns:
  for arm in arms:
   cmd=[sys.executable,str(ROOT/'replay_adapter.py'),'--child','--variant',arm,'--n',str(n)]
   if trace:cmd+=['--trace']
   p=subprocess.run(cmd,env=env,cwd=ROOT/'src',capture_output=True,text=True,timeout=180)
   if p.returncode:
    (ROOT/f'replay-failure-{n}-{arm}.log').write_text(p.stdout+p.stderr);raise RuntimeError(f'{n}/{arm}: child failed')
   d=json.loads(p.stdout);d['cycle']=cycle;rows.append(d);(ROOT/'replay-results.json').write_text(json.dumps(rows,indent=2));print(json.dumps(d),flush=True)
