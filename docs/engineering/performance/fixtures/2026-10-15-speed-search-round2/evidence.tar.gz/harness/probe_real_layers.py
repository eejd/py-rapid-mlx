import asyncio
import json
from pathlib import Path
import sys

ROOT=Path('/private/tmp/rapid-mlx-speed-search-round2')
sys.path.insert(0,str(ROOT/'src'))
import mlx.core as mx
from mlx_vlm.models.cache import ArraysCache
from rapid_mlx.engine.batched import BatchedEngine
from rapid_mlx.scheduler import SchedulerConfig
import gdn_proto

def probe(model):
    layers=[(name,layer) for name,layer in model.named_modules() if gdn_proto.module._structurally_eligible(layer)]
    originals={type(layer):type(layer).__call__ for _,layer in layers}
    enrolled=gdn_proto.install(model)
    assert enrolled==24 and len(layers)==24
    records=[]
    for index,(name,layer) in enumerate(layers):
        caches=[ArraysCache(2),ArraysCache(2)]
        warm=(mx.random.normal((1,16,layer.hidden_size),key=mx.random.key(1000+index))*.3).astype(mx.bfloat16)
        for cache in caches:mx.eval(originals[type(layer)](layer,warm,None,cache),cache.cache)
        for step in range(8):
            x=(mx.random.normal((1,1,layer.hidden_size),key=mx.random.key(2000+8*index+step))*.3).astype(mx.bfloat16)
            a=originals[type(layer)](layer,x,None,caches[0])
            b=layer(x,None,caches[1])
            mx.eval(a,b,caches[0].cache,caches[1].cache)
            pairs=[(a,b),*zip(caches[0].cache,caches[1].cache)]
            exact=[bool(mx.array_equal(u.view(mx.uint16 if u.dtype in (mx.bfloat16,mx.float16) else mx.uint32),v.view(mx.uint16 if v.dtype in (mx.bfloat16,mx.float16) else mx.uint32)).item()) and bool(mx.all(mx.isfinite(u)).item()) and bool(mx.all(mx.isfinite(v)).item()) for u,v in pairs]
            records.append({'module':name,'step':step,'exact_output_conv_recurrent':exact,
                            'cache_dtypes':[str(x.dtype) for x in caches[0].cache],
                            'max_abs':[float(mx.max(mx.abs(u.astype(mx.float32)-v.astype(mx.float32))).item()) for u,v in pairs]})
            (ROOT/'real-layer-parity.json').write_text(json.dumps({'enrolled':enrolled,'records':records,'runtime':dict(gdn_proto.COUNTS)},indent=2))
            assert all(exact),(name,step,exact)
    assert gdn_proto.COUNTS['kernel']==24*8
    print('Real learned layers:192 exact output/conv/recurrent comparisons;192 fused activations',flush=True)

async def main():
    model=str(Path.home()/'.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3')
    engine=BatchedEngine(model,no_spec_decode=True,scheduler_config=SchedulerConfig(spec_decode='none',kv_cache_dtype='bf16'))
    try:
        await engine.start()
        engine._model_load_executor.submit(probe,engine._model).result()
    finally:await engine.stop()

asyncio.run(main())
