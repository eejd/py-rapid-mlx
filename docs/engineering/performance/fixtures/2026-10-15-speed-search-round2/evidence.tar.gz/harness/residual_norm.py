# RMS reduction order adapted from MLX rms_norm.metal.
# Copyright (c) 2024 Apple Inc. MIT license; preserve the accompanying license.
import mlx.core as mx
from functools import cache

SOURCE = r'''
uint tid = thread_position_in_threadgroup.x;
uint lane = thread_index_in_simdgroup;
uint group = simdgroup_index_in_threadgroup;
uint row = threadgroup_position_in_grid.x;
threadgroup float sums[32];
threadgroup float inverse[1];
float acc = 0;
for (uint base = 0; base < N; base += NT * 4) {
    for (uint i = 0; i < 4; ++i) {
        uint col = base + tid * 4 + i;
        float value = col < N ? float(T(float(x[row*N+col]) + float(r[row*N+col]))) : 0.0f;
        acc += value * value;
    }
}
acc = simd_sum(acc);
if (group == 0) sums[lane] = 0;
threadgroup_barrier(mem_flags::mem_threadgroup);
if (lane == 0) sums[group] = acc;
threadgroup_barrier(mem_flags::mem_threadgroup);
if (group == 0) {
    acc = simd_sum(sums[lane]);
    if (lane == 0) inverse[0] = metal::precise::rsqrt(acc / axis[0] + eps[0]);
}
threadgroup_barrier(mem_flags::mem_threadgroup);
for (uint base = 0; base < N; base += NT * 4) {
    for (uint i = 0; i < 4; ++i) {
        uint col = base + tid * 4 + i;
        if (col < N) {
            T value = T(float(x[row*N+col]) + float(r[row*N+col]));
            residual[row*N+col] = value;
            y[row*N+col] = T(float(w[col]) * float(T(float(value) * inverse[0])));
        }
    }
}
'''
KERNEL = mx.fast.metal_kernel(name='study_residual_rms', input_names=['x','r','w','eps','axis'],
                              output_names=['y','residual'], source=SOURCE)

@cache
def parameters(n, eps):
    return mx.array([eps],mx.float32), mx.array([n],mx.uint32)

def fused(x, residual, weight, eps):
    n = x.shape[-1]
    nt = min(1024, ((n + 127) // 128) * 32)
    rows = x.size // n
    epsilon, axis = parameters(n, eps)
    return KERNEL(inputs=[x, residual, weight, epsilon, axis],
                  template=[('T',x.dtype),('N',n),('NT',nt)], grid=(rows*nt,1,1),
                  threadgroup=(nt,1,1), output_shapes=[x.shape,x.shape],
                  output_dtypes=[x.dtype,x.dtype])

def stock(x, residual, weight, eps):
    combined = x + residual
    return mx.fast.rms_norm(combined, weight, eps), combined
