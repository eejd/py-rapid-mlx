import json
from pathlib import Path
import statistics
import time

import mlx.core as mx
from residual_norm import fused, stock

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round2')
rows=[]
for n in [2048,2560,4096,5120]:
    x=mx.random.normal((1,1,n),key=mx.random.key(n)).astype(mx.bfloat16)
    r=mx.random.normal(x.shape,key=mx.random.key(n+1)).astype(mx.bfloat16)
    w=mx.random.normal((n,),key=mx.random.key(n+2)).astype(mx.bfloat16)
    mx.eval(x,r,w)
    fns={'stock':lambda a,b:stock(a,b,w,1e-6),
         'fused':lambda a,b:fused(a,b,w,1e-6),
         'stock_compiled':mx.compile(lambda a,b:stock(a,b,w,1e-6)),
         'fused_compiled':mx.compile(lambda a,b:fused(a,b,w,1e-6))}
    def chain(fn):
        a,b=x,r
        for _ in range(32):a,b=fn(a,b)
        return a,b
    reference=chain(fns['stock']);mx.eval(reference)
    exact={}
    for name,fn in fns.items():
        output=chain(fn);mx.eval(output)
        exact[name]=all(bool(mx.array_equal(a,b).item()) for a,b in zip(reference,output))
    timings={name:[] for name in fns if exact[name]}
    for name in timings:
        for _ in range(3):mx.eval(chain(fns[name]))
    for repeat in range(10):
        order=list(timings) if repeat%2==0 else list(reversed(timings))
        for name in order:
            start=time.perf_counter()
            for _ in range(5):mx.eval(chain(fns[name]))
            timings[name].append((time.perf_counter()-start)/5)
    row={'width':n,'chain_length':32,'exact':exact,'samples_s':timings,
         'median_s':{k:statistics.median(v) for k,v in timings.items()}}
    rows.append(row);(ROOT/'norm-chain.json').write_text(json.dumps(rows,indent=2))
    print(json.dumps(row),flush=True)
