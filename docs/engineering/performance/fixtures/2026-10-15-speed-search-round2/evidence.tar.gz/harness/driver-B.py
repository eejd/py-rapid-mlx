import json,os,subprocess,time
from pathlib import Path
r=Path('/private/tmp/rapid-mlx-speed-search-round2')
python=str(r/'venv/bin/python')
env=dict(os.environ,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',RAPID_MLX_TELEMETRY='0',DO_NOT_TRACK='1')
status=[]
for script in ['metadata.py','probe_real_layers.py']:
 with (r/(script+'.log')).open('w') as f:p=subprocess.run([python,str(r/script)],cwd=r,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(script,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
for variant,trial in [('baseline','B-A1'),('gdn','B-B1'),('gdn','B-B2'),('baseline','B-A2')]:
 with (r/('http-'+trial+'.log')).open('w') as f:p=subprocess.run([python,str(r/'run_long.py'),variant,'qwen4b'],cwd=r,env=dict(env,STUDY_TRIAL=trial),stdout=f,stderr=subprocess.STDOUT)
 status.append({'phase':'replication','variant':variant,'trial':trial,'exit':p.returncode})
 (r/'validation-status.json').write_text(json.dumps(status,indent=2));print(status[-1],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
