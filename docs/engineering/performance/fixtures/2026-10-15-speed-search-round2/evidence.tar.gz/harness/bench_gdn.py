import json
from pathlib import Path
import statistics
import sys
import time

import mlx.core as mx
import mlx.nn as nn
from mlx_lm.models.gated_delta import gated_delta_update
ROOT=Path('/private/tmp/rapid-mlx-speed-search-round2')
sys.path.insert(0,str(ROOT/'src'))
from gdn_proto import module as m

rows=[]
for hv in [32,48]:
    m._NUM_VALUE_HEADS=hv;m._VALUE_DIM=hv*128;m._CONV_DIM=4096+hv*128
    conv=nn.Conv1d(m._CONV_DIM,m._CONV_DIM,4,groups=m._CONV_DIM,bias=False)
    conv.weight=(mx.random.normal(conv.weight.shape,key=mx.random.key(1))*.1).astype(mx.bfloat16)
    qkv=mx.random.normal((1,1,m._CONV_DIM),key=mx.random.key(2)).astype(mx.bfloat16)
    z=mx.random.normal((1,1,hv*128),key=mx.random.key(3)).astype(mx.bfloat16)
    beta=mx.random.normal((1,1,hv),key=mx.random.key(4)).astype(mx.bfloat16)
    alpha=mx.random.normal(beta.shape,key=mx.random.key(5)).astype(mx.bfloat16)
    cs=mx.random.normal((1,3,m._CONV_DIM),key=mx.random.key(6)).astype(mx.bfloat16)
    rs=mx.random.normal((1,hv,128,128),key=mx.random.key(7)).astype(mx.float32)
    al=mx.random.normal((hv,),key=mx.random.key(8)).astype(mx.bfloat16)
    dt=mx.random.normal((hv,),key=mx.random.key(9)).astype(mx.bfloat16)
    w=mx.random.normal((128,),key=mx.random.key(10)).astype(mx.bfloat16)
    mx.eval(conv.parameters(),qkv,z,beta,alpha,cs,rs,al,dt,w)
    def stock():
        return m._stock_step(nn=nn,gated_delta_update=gated_delta_update,conv=conv,qkv=qkv,z=z,beta=beta,alpha=alpha,
                             conv_state=cs,recurrent_state=rs,a_log=al,dt_bias=dt,norm_weight=w,norm_eps=1e-6)
    def candidate(ty):
        return m.fused_gdn_decode(qkv,z,beta,alpha,cs,conv.weight,al,dt,rs,w,1e-6,
                                 threadgroup_y=ty,num_key_heads=16,num_value_heads=hv,key_head_dim=128,value_head_dim=128,
                                 conv_kernel=4,qwen35_semantics=True)
    fns={'stock':stock,**{str(ty):(lambda ty=ty:candidate(ty)) for ty in [32,16,8,4]}}
    reference=stock();mx.eval(reference);exact={}
    for name,fn in fns.items():
        out=fn();mx.eval(out);exact[name]=all(bool(mx.array_equal(a,b).item()) for a,b in zip(reference,out))
    timings={k:[] for k in fns if exact[k]}
    for k in timings:
        for _ in range(5):mx.eval(fns[k]())
    for repeat in range(8):
        for k in (list(timings) if repeat%2==0 else list(reversed(timings))):
            at=time.perf_counter()
            for _ in range(30):mx.eval(fns[k]())
            timings[k].append((time.perf_counter()-at)/30)
    row={'value_heads':hv,'exact':exact,'samples_s':timings,'median_s':{k:statistics.median(v) for k,v in timings.items()}}
    rows.append(row);(ROOT/'gdn-components.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
