"""Experimental projection packing, retaining stock attributes as row views."""
import copy
import types

import mlx.core as mx
from rapid_mlx import gdn_in_proj_fusion as shared
import gdn_proto

RECEIPTS=[]
original_project=gdn_proto.module._project_inputs

def project(layer, inputs):
    pack=getattr(layer,'_study_projection_pack',None)
    if pack is None:return original_project(layer,inputs)
    gdn_proto.COUNTS['packed_projection']+=1
    return shared._fused_projections(pack,inputs)

gdn_proto.module._project_inputs=project

def install(model):
    rows=[]
    for name,layer in model.named_modules():
        if not gdn_proto.module._structurally_eligible(layer) or not shared._can_fuse(layer):continue
        dtypes=shared._probe_projection_parity(layer)
        row={'module':name,'exact_narrow_dtypes':[str(x) for x in sorted(dtypes,key=str)]}
        rows.append(row)
        if mx.bfloat16 not in dtypes:continue
        parts=shared._proj_modules(layer)
        arrays=shared._concat_params(parts);mx.eval(arrays)
        container=copy.deepcopy(parts[0])
        container.weight,container.scales,container.biases=arrays
        bounds=[];lo=0
        for part in parts:
            hi=lo+part.weight.shape[0]
            bounds.append(hi)
            # Keep the stock prefill/wide path and original module API.
            part.weight=container.weight[lo:hi]
            part.scales=container.scales[lo:hi]
            part.biases=container.biases[lo:hi]
            lo=hi
        pack=types.SimpleNamespace(in_proj_fused=container,_rapid_gdn_bounds=bounds,_rapid_gdn_dtypes=dtypes)
        object.__setattr__(layer,'_study_projection_pack',pack)
        row['packed']=True
    RECEIPTS.append(rows)
    return sum(bool(x.get('packed')) for x in rows)
