import json
from pathlib import Path
import statistics
import time

import mlx.core as mx
from residual_norm import fused, stock

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round2')
rows = []
for n in [2048,2560,4096,5120]:
    for dtype in [mx.bfloat16,mx.float16]:
        checks = []
        for seed in range(8):
            x = (mx.random.normal((1,1,n),key=mx.random.key(110+seed)) * [0, .1, 1, 10][seed%4]).astype(dtype)
            r = mx.random.normal(x.shape,key=mx.random.key(210+seed)).astype(dtype)
            w = mx.random.normal((n,),key=mx.random.key(310+seed)).astype(dtype)
            a, b = stock(x,r,w,1e-6), fused(x,r,w,1e-6)
            mx.eval(a,b)
            checks.append({'seed':seed,'exact':all(bool(mx.array_equal(u,v).item()) for u,v in zip(a,b)),
                           'max_abs':[float(mx.max(mx.abs(u.astype(mx.float32)-v.astype(mx.float32))).item()) for u,v in zip(a,b)]})
        record = {'width':n,'dtype':str(dtype),'checks':checks,'all_exact':all(c['exact'] for c in checks)}
        if record['all_exact']:
            times={'stock':[],'fused':[]}
            fns={'stock':stock,'fused':fused}
            for fn in fns.values():
                for _ in range(5):mx.eval(fn(x,r,w,1e-6))
            for repeat in range(8):
                for name in (['stock','fused'] if repeat%2==0 else ['fused','stock']):
                    start=time.perf_counter()
                    for _ in range(40):mx.eval(fns[name](x,r,w,1e-6))
                    times[name].append((time.perf_counter()-start)/40)
            record['samples_s']=times
            record['median_s']={k:statistics.median(v) for k,v in times.items()}
        rows.append(record)
        (ROOT/'norm-probe.json').write_text(json.dumps(rows,indent=2))
        print(json.dumps(record),flush=True)
