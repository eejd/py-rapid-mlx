"""Private experiment: same exact recurrence probe, additional input width."""
import collections
import json
from pathlib import Path
import sys
import types

import rapid_mlx.qwen35_fused_gdn_decode as original

COUNTS = collections.Counter()
RECEIPTS = []
module = types.ModuleType('rapid_mlx._round2_gdn')
module.__package__ = 'rapid_mlx'
sys.modules[module.__name__] = module
source = Path(original.__file__).read_text()
assert source.count('and layer.hidden_size == 2048') == 1
source = source.replace('and layer.hidden_size == 2048', 'and layer.hidden_size == 2560')
exec(compile(source, '<private-width-qualification>', 'exec'), module.__dict__)
kernel = module.fused_gdn_decode

def observed_kernel(*args, **kwargs):
    COUNTS['kernel'] += 1
    return kernel(*args, **kwargs)

module.fused_gdn_decode = observed_kernel
eligible = module._eligible

def observed_eligible(layer, inputs, mask, cache):
    yes = eligible(layer, inputs, mask, cache)
    if inputs.shape[1] == 1:
        COUNTS['eligible' if yes else 'ineligible'] += 1
        if mask is not None: COUNTS['nonempty_mask'] += 1
        if cache is not None and getattr(cache, 'lengths', None) is not None: COUNTS['cache_lengths'] += 1
        if cache is not None and getattr(cache, 'left_padding', None) is not None: COUNTS['cache_left_padding'] += 1
    return yes

module._eligible = observed_eligible

def install(model):
    count = module.install_qwen35_fused_gdn_decode(model)
    RECEIPTS.append({'enrolled_layers': count, 'exact_probe_threadgroup_y': module._PROBED_THREADGROUP_Y})
    COUNTS.clear()  # Startup probe invocations are not serving activation.
    return count
