# Reduction adapted from MLX rms_norm.metal, Copyright (c) 2024 Apple Inc.
# MIT license; preserve the accompanying license.
import mlx.core as mx
from residual_norm import SOURCE, parameters

SOURCE = SOURCE.replace('float(T(float(x[row*N+col]) + float(r[row*N+col])))', 'float(x[row*N+col])')
needle = '''T value = T(float(x[row*N+col]) + float(r[row*N+col]));
            residual[row*N+col] = value;
            y[row*N+col] = T(float(w[col]) * float(T(float(value) * inverse[0])));'''
replacement = '''float value = float(x[row*N+col]);
            T normalized = T(float(w[col]) * float(T(value * inverse[0])));
            y[row*N+col] = T(float(normalized) + float(r[row*N+col]));'''
assert needle in SOURCE
SOURCE=SOURCE.replace(needle,replacement)
KERNEL=mx.fast.metal_kernel(name='study_postnorm_residual',input_names=['x','r','w','eps','axis'],output_names=['y'],source=SOURCE)

def fused(x,r,w,eps):
    n=x.shape[-1];nt=min(1024,((n+127)//128)*32);epsilon,axis=parameters(n,eps)
    return KERNEL(inputs=[x,r,w,epsilon,axis],template=[('T',x.dtype),('N',n),('NT',nt)],
                  grid=(x.size//n*nt,1,1),threadgroup=(nt,1,1),output_shapes=[x.shape],output_dtypes=[x.dtype])[0]

def stock(x,r,w,eps):
    return mx.fast.rms_norm(x,w,eps)+r
