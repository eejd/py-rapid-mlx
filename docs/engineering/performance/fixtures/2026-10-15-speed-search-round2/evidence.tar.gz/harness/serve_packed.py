import atexit
import json
import os
from pathlib import Path
import sys

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round2')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-round2-v1'
sys.path.insert(0, str(ROOT / 'src'))
variant = os.environ['STUDY_VARIANT']
assert variant in ('baseline', 'gdn', 'gdn_pack')
import gdn_proto
from rapid_mlx.engine.batched import BatchedEngine

if variant in ('gdn','gdn_pack'):
    original_start = BatchedEngine.start
    async def start(self):
        await original_start(self)
        model = self._model
        if variant == 'gdn_pack':
            import gdn_pack_proto
            self._model_load_executor.submit(gdn_pack_proto.install, model).result()
        self._model_load_executor.submit(gdn_proto.install, model).result()
    BatchedEngine.start = start

@atexit.register
def save():
    (ROOT / (os.environ['STUDY_RUN'] + '-instrumentation.json')).write_text(json.dumps({
        'variant': variant, 'gdn': dict(gdn_proto.COUNTS), 'installation': gdn_proto.RECEIPTS, 'packing': getattr(sys.modules.get('gdn_pack_proto'), 'RECEIPTS', [])}, indent=2))

from rapid_mlx.cli import cli_entrypoint
sys.argv = [sys.argv[0], 'serve', os.environ['STUDY_MODEL'], '--host', '127.0.0.1',
            '--port', '18647', '--served-model-name', 'decode-study', '--no-spec-decode',
            '--disable-prefix-cache', '--disable-disk-caches', '--disable-model-downloads',
            '--log-level', 'WARNING']
cli_entrypoint()
