import json
from pathlib import Path
import statistics
import time

import mlx.core as mx
from post_norm import stock,fused

ROOT=Path('/private/tmp/rapid-mlx-speed-search-round2')
rows=[]
for n in [2048,2560,4096,5120]:
    checks=[]
    for seed in range(8):
        x=(mx.random.normal((1,1,n),key=mx.random.key(101+seed))*[0,.1,1,10][seed%4]).astype(mx.bfloat16)
        r=mx.random.normal(x.shape,key=mx.random.key(201+seed)).astype(mx.bfloat16)
        w=mx.random.normal((n,),key=mx.random.key(301+seed)).astype(mx.bfloat16)
        a,b=stock(x,r,w,1e-6),fused(x,r,w,1e-6);mx.eval(a,b)
        checks.append({'seed':seed,'exact':bool(mx.array_equal(a,b).item()),'max_abs':float(mx.max(mx.abs(a.astype(mx.float32)-b.astype(mx.float32))).item())})
    row={'width':n,'checks':checks,'all_exact':all(x['exact'] for x in checks)}
    if row['all_exact']:
        fns={'stock':lambda a:stock(a,r,w,1e-6),'fused':lambda a:fused(a,r,w,1e-6),
             'stock_compiled':mx.compile(lambda a:stock(a,r,w,1e-6)),
             'fused_compiled':mx.compile(lambda a:fused(a,r,w,1e-6))}
        def chain(fn):
            out=x
            for _ in range(32):out=fn(out)
            return out
        reference=chain(fns['stock']);mx.eval(reference);exact={}
        for name,fn in fns.items():
            out=chain(fn);mx.eval(out);exact[name]=bool(mx.array_equal(reference,out).item())
        times={k:[] for k in fns if exact[k]}
        for k in times:
            for _ in range(3):mx.eval(chain(fns[k]))
        for repeat in range(10):
            for k in (list(times) if repeat%2==0 else list(reversed(times))):
                at=time.perf_counter()
                for _ in range(5):mx.eval(chain(fns[k]))
                times[k].append((time.perf_counter()-at)/5)
        row.update({'chain_exact':exact,'samples_s':times,'median_s':{k:statistics.median(v) for k,v in times.items()}})
    rows.append(row);(ROOT/'post-norm-probe.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
