import importlib.util
import json
import logging
from pathlib import Path
import sys
import time
import types

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round2')
sys.path.insert(0, str(ROOT / 'src'))
import rapid_mlx.qwen35_fused_gdn_decode as original

logging.basicConfig(level=logging.DEBUG)
rows = []
for name, value_heads, hidden in [('qwen4b', 32, 2560), ('qwen27b_geometry', 48, 5120)]:
    module = types.ModuleType('rapid_mlx._study_gdn_' + name)
    module.__package__ = 'rapid_mlx'
    sys.modules[module.__name__] = module
    source = Path(original.__file__).read_text()
    assert source.count('and layer.hidden_size == 2048') == 1
    source = source.replace('and layer.hidden_size == 2048', f'and layer.hidden_size == {hidden}')
    exec(compile(source, '<private-geometry-prototype>', 'exec'), module.__dict__)
    module._NUM_VALUE_HEADS = value_heads
    module._VALUE_DIM = value_heads * module._VALUE_HEAD_DIM
    module._CONV_DIM = 2 * module._KEY_DIM + module._VALUE_DIM
    for tg in [32, 16, 8, 4]:
        start = time.perf_counter()
        try:
            exact = module._probe_candidate(tg)
            error = None
        except Exception as exc:
            exact, error = False, repr(exc)
        row = {'geometry': name, 'value_heads': value_heads, 'hidden_size': hidden,
               'threadgroup_y': tg, 'eight_step_output_conv_fp32_state_exact': exact,
               'error': error, 'seconds': time.perf_counter() - start}
        rows.append(row)
        (ROOT / 'gdn-probe.json').write_text(json.dumps(rows, indent=2))
        print(json.dumps(row), flush=True)
