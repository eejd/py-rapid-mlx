import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round2')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-round2-v1'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(8 * 1024**2), b''): h.update(part)
    return h.hexdigest()

versions = {n: metadata.version(n) for n in ['mlx', 'mlx-lm', 'mlx-vlm', 'transformers', 'numpy', 'httpx', 'psutil', 'rapid-mlx']}
models = {}
for repo, expected in json.loads((ROOT / 'expected-models.json').read_text()).items():
    p = Path.home() / '.cache/huggingface/hub' / ('models--' + repo.replace('/', '--')) / 'snapshots' / expected['revision']
    files = {str(f.relative_to(p)): {'bytes': f.stat().st_size, 'sha256': digest(f)} for f in p.rglob('*') if f.is_file()}
    for n, value in expected['large_files'].items():
        assert files[n] == value, (repo, n)
    models[repo] = {'revision': expected['revision'], 'files': files}
dependencies = {}
for name, expected in json.loads((ROOT / 'official-dependency-files.json').read_text()).items():
    assert versions[name] == expected['version']
    distribution = metadata.distribution(name)
    failed = [n for n, value in expected['python_files'].items() if digest(Path(distribution.locate_file(n))) != value]
    assert not failed, (name, failed[:5])
    dependencies[name] = {'version': expected['version'], 'verified_python_files': len(expected['python_files']),
                          'official_wheel': expected['wheel'], 'official_wheel_sha256': expected['wheel_sha256']}
source_names = ['rapid_mlx/engine/batched.py', 'rapid_mlx/engine_core.py', 'rapid_mlx/scheduler.py',
                'rapid_mlx/mllm_scheduler.py', 'rapid_mlx/mllm_batch_generator.py', 'rapid_mlx/singleton_cache_fastpath.py', 'rapid_mlx/qwen35_fused_gdn_decode.py', 'rapid_mlx/gdn_in_proj_fusion.py', 'rapid_mlx/kernels/qwen4_fused_gdn_decode.py']
result = {'source_commit': '5c70e238f6068d373553c48d92786a5cf333d05b',
          'source_hashes': {n: digest(ROOT / 'src' / n) for n in source_names},
          'harness_sha256': {n: digest(ROOT / n) for n in ['gdn_proto.py', 'serve_gdn.py', 'gdn_pack_proto.py', 'serve_packed.py', 'run_http.py', 'run_long.py', 'run_packed.py', 'probe_gdn.py', 'probe_real_layers.py', 'residual_norm.py', 'probe_norm.py', 'probe_norm_chain.py', 'bench_gdn.py', 'post_norm.py', 'probe_post_norm.py']},
          'versions': versions, 'python': sys.version, 'platform': platform.platform(),
          'chip': subprocess.check_output(['sysctl', '-n', 'machdep.cpu.brand_string'], text=True).strip(),
          'memory_bytes': int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True)),
          'dependencies': dependencies, 'models': models,
          'mlx_core_sha256': digest(Path(importlib.util.find_spec('mlx.core').origin)),
          'limitation': 'Source checkout through PYTHONPATH, not a packaged release qualification. One M4 only; no Qwen27B/TensorFold/cross-chip speed claim.'}
(ROOT / 'metadata.json').write_text(json.dumps(result, indent=2))
print('Source, model weights and official dependency Python files verified', flush=True)
