"""Execution-only probes. Component timings are not serving speedup claims."""
import hashlib
import json
import os
from pathlib import Path
import statistics
import sys
import time

mode = sys.argv[1] if len(sys.argv) > 1 else 'baseline'
assert mode in ('baseline', 'd512')
if mode == 'd512':
    os.environ['MLX_SDPA_D512_MIN_KL'] = '0'

import mlx.core as mx
from mlx_lm.models.cache import KVCache
import numpy as np

ROOT = Path('/private/tmp/rapid-mlx-m4-decode-study')
assert (ROOT / '.task-owner').read_text() == 'vector-m4-decode-study-v1'
mx.random.seed(131)
attention = []
shapes = []
for p in ROOT.glob('*-baseline-instrumentation.json'):
    for row in json.loads(p.read_text())['shapes']:
        geometry = (row['q'][1], row['k'][1], row['q'][-1], row['v'][-1])
        if geometry not in shapes:
            shapes.append(geometry)
assert shapes, 'First complete the actual serving shape capture'
for hq, hk, dk, dv in shapes:
    for length in [1024, 8192, 16384, 32768]:
        q = mx.random.normal((1, hq, 1, dk)).astype(mx.bfloat16)
        # Sliced capacity mirrors a live growing cache, rather than a compact tensor.
        kb = mx.random.normal((1, hk, length + 128, dk)).astype(mx.bfloat16)
        vb = mx.random.normal((1, hk, length + 128, dv)).astype(mx.bfloat16)
        k, v = kb[:, :, :length], vb[:, :, :length]
        mx.eval(q, k, v)
        def fn(kind):
            kk, vv = (mx.contiguous(k), mx.contiguous(v)) if kind == 'compact' else (k, v)
            return mx.fast.scaled_dot_product_attention(q, kk, vv, scale=dk ** -.5,
                                                       force_fused=kind == 'force_fused')
        reference = fn('native'); mx.eval(reference)
        np.save(ROOT / f'reference-{mode}-{hq}-{hk}-{dk}-{dv}-{length}.npy', np.asarray(reference.astype(mx.float32)))
        samples = {x: [] for x in ['native', 'compact', 'force_fused']}
        errors = {}
        unavailable = {}
        for kind in list(samples):
            try:
                out = fn(kind); mx.eval(out)
            except ValueError as exc:
                unavailable[kind] = str(exc)
                del samples[kind]
                continue
            error = float(mx.max(mx.abs(out.astype(mx.float32) - reference.astype(mx.float32))).item())
            errors[kind] = error
            assert bool(mx.allclose(out, reference, rtol=.002, atol=.002).item()), (kind, error)
            for _ in range(5): mx.eval(fn(kind))
        for repeat in range(6):
            order = list(samples) if repeat % 2 == 0 else list(reversed(samples))
            for kind in order:
                start = time.perf_counter()
                for _ in range(20): mx.eval(fn(kind))
                samples[kind].append((time.perf_counter() - start) / 20)
        row = {'geometry': [hq, hk, dk, dv], 'context': length, 'samples_s': samples,
               'median_s': {k: statistics.median(v) for k, v in samples.items()},
               'max_abs_error': errors, 'unavailable': unavailable,
               'dtype': 'bfloat16', 'allclose_rtol': .002, 'allclose_atol': .002}
        attention.append(row)
        (ROOT / ('attention-components-' + mode + '.json')).write_text(json.dumps(attention, indent=2))
        print('ATTENTION', json.dumps(row), flush=True)
        del q, k, v, kb, vb, reference, out
        mx.clear_cache()

if mode != 'baseline':
    print('Attention mode complete', mode, flush=True)
    raise SystemExit(0)
growth = []
for h, d in sorted({(x[1], x[2]) for x in shapes}):
    for length in [8192, 16384]:
        for repeat in range(4):
            for step in ([256, 2048] if repeat % 2 == 0 else [2048, 256]):
                cache = KVCache(); cache.step = step
                cache.keys = mx.zeros((1, h, length, d), mx.bfloat16)
                cache.values = mx.zeros((1, h, length, d), mx.bfloat16)
                cache.offset = length
                token = mx.ones((1, h, 1, d), mx.bfloat16)
                mx.eval(cache.state, token)
                timings, boundaries = [], []
                for index in range(512):
                    capacity = cache.keys.shape[-2]
                    start = time.perf_counter()
                    out = cache.update_and_fetch(token, token)
                    mx.eval(out)
                    timings.append(time.perf_counter() - start)
                    if cache.keys.shape[-2] != capacity: boundaries.append(index)
                assert cache.offset == length + 512
                assert bool(mx.all(cache.keys[:, :, :length] == 0).item())
                assert bool(mx.all(cache.keys[:, :, length:cache.offset] == 1).item())
                digest = hashlib.sha256(np.asarray(cache.keys[:, :, :cache.offset].astype(mx.float32)).tobytes()).hexdigest()
                row = {'heads': h, 'dimension': d, 'context': length, 'step': step, 'repeat': repeat,
                       'total_s': sum(timings), 'p50_s': statistics.median(timings),
                       'p99_s': float(np.percentile(timings, 99)), 'max_s': max(timings),
                       'growth_indices': boundaries, 'growth_s': [timings[i] for i in boundaries],
                       'capacity_bytes': cache.keys.nbytes + cache.values.nbytes, 'valid_keys_sha256': digest}
                growth.append(row)
                (ROOT / 'cache-growth-components.json').write_text(json.dumps(growth, indent=2))
                print('GROWTH', json.dumps(row), flush=True)
                del cache, out, token
                mx.clear_cache()
print('Component probes complete', flush=True)
