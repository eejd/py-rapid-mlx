import atexit
import collections
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys

if os.environ.get('STUDY_VARIANT') in ('d512', 'd512_nomask'):
    os.environ['MLX_SDPA_D512_MIN_KL'] = '0'

import mlx.core as mx
import mlx_lm.models.cache as lm_cache
import mlx_vlm.models.cache as vlm_cache

ROOT = Path('/private/tmp/rapid-mlx-m4-decode-study')
assert (ROOT / '.task-owner').read_text() == 'vector-m4-decode-study-v1'
run = os.environ['STUDY_RUN']
variant = os.environ.get('STUDY_VARIANT', 'baseline')
assert variant in ('baseline', 'slab2048', 'd512', 'd512_nomask')
stats = collections.Counter()
shapes = {}
mask_checks = {}
original = mx.fast.scaled_dot_product_attention

def observed(q, k, v, **kwargs):
    if q.shape[-2] == 1:
        mask = kwargs.get('mask')
        row = {'q': list(q.shape), 'k': list(k.shape), 'v': list(v.shape),
               'dtype': str(q.dtype), 'mask': mask if isinstance(mask, str) or mask is None else list(mask.shape),
               'sinks': kwargs.get('sinks') is not None}
        # Bound observations to context buckets; don't retain lazy arrays.
        key = (q.shape[1], k.shape[1], q.shape[-1], v.shape[-1], k.shape[-2] // 1024, str(row['mask']))
        shapes.setdefault(str(key), row)
        stats['decode_sdpa_calls'] += 1
        if q.shape[-1] == 512 and mask is not None:
            assert q.shape[0] == 1 and list(mask.shape) == [1, 1, 1, k.shape[-2]]
            assert mask.dtype == mx.bool_
            bucket = k.shape[-2] // 1024
            if bucket not in mask_checks:
                valid = bool(mx.all(mask).item())
                mask_checks[bucket] = {'context': k.shape[-2], 'all_true': valid}
                assert valid, 'This benchmark-only candidate requires unpadded full attention'
            if variant == 'd512_nomask':
                kwargs['mask'] = None
                stats['mask_removed_calls'] += 1
    return original(q, k, v, **kwargs)

mx.fast.scaled_dot_product_attention = observed
cache_source_hashes = {}
def observe_cache(cls):
    original_update = cls.update_and_fetch
    key = cls.__module__ + '.' + cls.__name__
    cache_source_hashes[key] = hashlib.sha256(inspect.getsource(original_update).encode()).hexdigest()
    if variant == 'slab2048':
        cls.step = 2048
    def update(self, keys, values):
        old = None if self.keys is None else self.keys.shape[-2]
        out = original_update(self, keys, values)
        if keys.shape[-2] == 1:
            stats['decode_cache_' + key] += 1
            if old != self.keys.shape[-2]:
                stats['decode_growth_' + key] += 1
        return out
    cls.update_and_fetch = update

for cls in {lm_cache.KVCache, lm_cache.BatchKVCache, vlm_cache.KVCache, vlm_cache.BatchKVCache}:
    observe_cache(cls)

@atexit.register
def save():
    (ROOT / (run + '-instrumentation.json')).write_text(json.dumps({
        'variant': variant, 'stats': dict(stats), 'shapes': list(shapes.values()),
        'cache_source_hashes': cache_source_hashes, 'mask_checks': mask_checks,
        'active_memory': mx.get_active_memory(), 'peak_memory': mx.get_peak_memory(),
    }, indent=2))

from rapid_mlx.cli import cli_entrypoint

sys.argv = [sys.argv[0], 'serve', os.environ['STUDY_MODEL'], '--host', '127.0.0.1',
            '--port', '18647', '--served-model-name', 'decode-study', '--no-spec-decode',
            '--disable-prefix-cache', '--disable-disk-caches', '--disable-model-downloads',
            '--log-level', 'WARNING']
cli_entrypoint()
