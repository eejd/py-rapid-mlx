import atexit
import collections
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys

import mlx.core as mx
from mlx_lm.models.cache import KVCache, BatchKVCache

ROOT = Path('/private/tmp/rapid-mlx-m4-decode-study')
assert (ROOT / '.task-owner').read_text() == 'vector-m4-decode-study-v1'
run = os.environ['STUDY_RUN']
variant = os.environ.get('STUDY_VARIANT', 'baseline')
assert variant in ('baseline', 'slab2048')
if variant == 'slab2048':
    KVCache.step = BatchKVCache.step = 2048
stats = collections.Counter()
shapes = {}
original = mx.fast.scaled_dot_product_attention

def observed(q, k, v, **kwargs):
    if q.shape[-2] == 1:
        mask = kwargs.get('mask')
        row = {'q': list(q.shape), 'k': list(k.shape), 'v': list(v.shape),
               'dtype': str(q.dtype), 'mask': mask if isinstance(mask, str) or mask is None else list(mask.shape),
               'sinks': kwargs.get('sinks') is not None}
        # Bound observations to context buckets; don't retain lazy arrays.
        key = (q.shape[1], k.shape[1], q.shape[-1], v.shape[-1], k.shape[-2] // 1024, str(row['mask']))
        shapes.setdefault(str(key), row)
        stats['decode_sdpa_calls'] += 1
    return original(q, k, v, **kwargs)

mx.fast.scaled_dot_product_attention = observed
original_update = KVCache.update_and_fetch

def update(self, keys, values):
    old = None if self.keys is None else self.keys.shape[-2]
    out = original_update(self, keys, values)
    if keys.shape[-2] == 1:
        stats['decode_cache_' + type(self).__name__] += 1
        if old != self.keys.shape[-2]:
            stats['decode_growth_' + type(self).__name__] += 1
    return out

KVCache.update_and_fetch = update

@atexit.register
def save():
    (ROOT / (run + '-instrumentation.json')).write_text(json.dumps({
        'variant': variant, 'stats': dict(stats), 'shapes': list(shapes.values()),
        'kv_source_sha256': hashlib.sha256(inspect.getsource(original_update).encode()).hexdigest(),
        'active_memory': mx.get_active_memory(), 'peak_memory': mx.get_peak_memory(),
    }, indent=2))

from rapid_mlx.cli import cli_entrypoint

sys.argv = [sys.argv[0], 'serve', os.environ['STUDY_MODEL'], '--host', '127.0.0.1',
            '--port', '18647', '--served-model-name', 'decode-study', '--no-spec-decode',
            '--disable-prefix-cache', '--disable-disk-caches', '--disable-model-downloads',
            '--log-level', 'WARNING']
cli_entrypoint()
