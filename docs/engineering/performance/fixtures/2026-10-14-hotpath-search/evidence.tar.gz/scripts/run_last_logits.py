import base64
import io
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time

import httpx
import psutil
from PIL import Image

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
rows = []
for run, variant in enumerate(('baseline', 'last_logits', 'last_logits', 'baseline')):
    env = dict(os.environ, PYTHONPATH=str(ROOT/'src'), HOTPATH_VARIANT=variant,
               HOTPATH_RUN=str(run), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    samples, stop = [], threading.Event()
    with (ROOT/f'last-logits-server-{run}.log').open('w') as log:
        proc = subprocess.Popen([sys.executable, str(ROOT/'serve_last_logits.py')],
            cwd=ROOT/'src', env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (ROOT/'active-pgid').write_text(str(proc.pid))
        def monitor():
            while not stop.wait(1):
                try:
                    foreign = []
                    for other in psutil.process_iter(['pid', 'name', 'memory_info', 'cmdline']):
                        d = other.info
                        if d['pid'] not in (os.getpid(), proc.pid) and 'python' in (d['name'] or '').lower() and d['memory_info'].rss > 512*1024**2:
                            if not any(str(ROOT) in str(a) for a in (d['cmdline'] or [])):
                                foreign.append({'pid': d['pid'], 'rss': d['memory_info'].rss})
                    samples.append({'rss': psutil.Process(proc.pid).memory_info().rss,
                                    'swap': psutil.swap_memory().used, 'foreign': foreign})
                except psutil.Error:
                    pass
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        try:
            with httpx.Client(base_url='http://127.0.0.1:18646', timeout=300, trust_env=False) as c:
                deadline = time.monotonic()+300
                while True:
                    if proc.poll() is not None:
                        raise RuntimeError('server exited')
                    try:
                        if c.get('/health/ready').status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                    assert time.monotonic() < deadline
                    time.sleep(.5)
                schedule = [(True, n) for n in (16, 64, 192, 'image')]
                for repeat in range(3):
                    cases = (16, 64, 192, 'image') if repeat % 2 == 0 else ('image', 192, 64, 16)
                    schedule.extend((False, n) for n in cases)
                for index, (warmup, case) in enumerate(schedule):
                    if case == 'image':
                        buf = io.BytesIO()
                        image = Image.new('RGB', (224, 224), (255, 0, 0))
                        image.putpixel((0, 0), (255, index, index))
                        image.save(buf, format='PNG')
                        url = 'data:image/png;base64,'+base64.b64encode(buf.getvalue()).decode()
                        content = [{'type': 'text', 'text': 'What color is this image? Reply with one English color word.'},
                                   {'type': 'image_url', 'image_url': {'url': url}}]
                    else:
                        content = ('Access code: 7319.\n' + ''.join(f'Entry {n}: apples, pears, oranges.\n' for n in range(case))
                                   + 'The access code is 7319. Reply with the four-digit code only.')
                    body = {'model': 'hotpath', 'messages': [{'role': 'user', 'content': content}],
                            'temperature': 0, 'enable_thinking': False, 'max_tokens': 16,
                            'stream': True, 'stream_options': {'include_usage': True}}
                    at = time.perf_counter_ns()
                    first, usage, done, finish, rid, pieces = None, None, False, None, None, []
                    with c.stream('POST', '/v1/chat/completions', json=body) as response:
                        response.raise_for_status()
                        for line in response.iter_lines():
                            if not line.startswith('data:'):
                                continue
                            payload = line[5:].strip()
                            if payload == '[DONE]':
                                done = True
                                continue
                            d = json.loads(payload)
                            rid = d.get('id', rid)
                            usage = d.get('usage') or usage
                            for choice in d.get('choices', []):
                                text = choice.get('delta', {}).get('content') or ''
                                if text:
                                    first = first or time.perf_counter_ns()
                                    pieces.append(text)
                                finish = choice.get('finish_reason') or finish
                    end = time.perf_counter_ns()
                    text = ''.join(pieces).strip()
                    assert first and usage and done and finish and usage['completion_tokens'] > 0
                    correct = bool(re.search(r'\bred\b', text, re.I)) if case == 'image' else text == '7319'
                    assert correct, (variant, case, text)
                    assert (usage.get('prompt_tokens_details') or {}).get('cached_tokens', 0) == 0
                    row = {'run': run, 'variant': variant, 'index': index, 'warmup': warmup,
                           'case': case, 'text': text, 'request_id': rid, 'usage': usage,
                           'ttft_s': (first-at)/1e9, 'total_s': (end-at)/1e9, 'correct': correct}
                    rows.append(row)
                    (ROOT/'last-logits-trials.json').write_text(json.dumps(rows, indent=2))
                    print(json.dumps(row), flush=True)
        finally:
            stop.set()
            thread.join(timeout=3)
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=15)
            (ROOT/'active-pgid').unlink(missing_ok=True)
            (ROOT/f'last-logits-host-{run}.json').write_text(json.dumps({'samples': samples, 'exit': proc.returncode}))
    assert proc.returncode == 0
