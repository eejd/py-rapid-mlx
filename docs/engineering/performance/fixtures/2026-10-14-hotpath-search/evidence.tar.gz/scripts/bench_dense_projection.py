"""Exactness-first merged dense gate/up probe using immutable real weights."""
import importlib
import json
from pathlib import Path
import statistics
import time

from rapid_mlx import _mlx_compat
_mlx_compat.install()
import mlx.core as mx

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
results = []
for model, repo, revision, module, activation_name in (
    ('qwen', 'mlx-community/Qwen3.5-4B-MLX-4bit', '32f3e8ecf65426fc3306969496342d504bfa13f3', 'mlx_vlm.models.qwen3_5.language', 'swiglu'),
    ('gemma', 'mlx-community/gemma-4-e2b-it-4bit', '238767527555cb75a05732a84dff5d6ba0dd6809', 'mlx_vlm.models.gemma4.language', 'geglu'),
):
    snapshot = Path.home()/'.cache/huggingface/hub'/('models--'+repo.replace('/', '--'))/'snapshots'/revision
    config = json.loads((snapshot/'config.json').read_text())
    q = config.get('quantization') or config['quantization_config']
    assert q['bits'] == 4 and q['group_size'] == 64 and q.get('mode', 'affine') == 'affine'
    weights = {}
    for file in sorted(snapshot.glob('*.safetensors')):
        weights.update(mx.load(str(file)))
    prefixes = sorted(k[:-len('.gate_proj.weight')] for k in weights if k.endswith('.mlp.gate_proj.weight') and 'language_model' in k)
    assert len(prefixes) >= 3
    selected = [prefixes[0], prefixes[len(prefixes)//2], prefixes[-1]]
    activation = getattr(importlib.import_module(module), activation_name)
    for prefix in selected:
        gate, up, down = [tuple(weights[prefix+'.'+name+'.'+suffix] for suffix in ('weight', 'scales', 'biases'))
                          for name in ('gate_proj', 'up_proj', 'down_proj')]
        assert all(a.shape == b.shape and a.dtype == b.dtype for a,b in zip(gate, up))
        merged = tuple(mx.concatenate([a,b], axis=0) for a,b in zip(gate, up))
        mx.eval(merged)
        def linear(x, arrays):
            return mx.quantized_matmul(x, *arrays, transpose=True, group_size=64, bits=4, mode='affine')
        def baseline(x):
            return linear(activation(linear(x, gate), linear(x, up)), down)
        def fused(x):
            g, u = mx.split(linear(x, merged), 2, axis=-1)
            return linear(activation(g, u), down)
        hidden = gate[0].shape[-1]*8
        for tokens in (1, 8, 128):
            mx.random.seed(123)
            x = (mx.random.normal((1, tokens, hidden))*.1).astype(mx.bfloat16)
            expected, actual = baseline(x), fused(x)
            mx.eval(expected, actual)
            exact = bool(mx.array_equal(expected, actual).item())
            error = float(mx.max(mx.abs(expected.astype(mx.float32)-actual.astype(mx.float32))).item())
            row = {'model': model, 'layer': prefix, 'tokens': tokens, 'exact': exact, 'max_abs_error': error,
                   'dtype': str(x.dtype), 'baseline_ns': [], 'fused_ns': []}
            if exact:
                for _ in range(5):
                    mx.eval(baseline(x))
                    mx.eval(fused(x))
                for pair in range(6):
                    for name, fn in ((('baseline', baseline), ('fused', fused)) if pair%2 == 0 else (('fused', fused), ('baseline', baseline))):
                        started = time.perf_counter_ns()
                        for _ in range(20):
                            mx.eval(fn(x))
                        row[name+'_ns'].append((time.perf_counter_ns()-started)/20)
                row['median_speed_ratio'] = statistics.median(row['baseline_ns'])/statistics.median(row['fused_ns'])
            results.append(row)
            (ROOT/'dense-projection-results.json').write_text(json.dumps(results, indent=2))
            print(json.dumps({k:v for k,v in row.items() if not k.endswith('_ns')}), flush=True)
    del weights
    mx.clear_cache()
