"""Test the dependency's existing last-position projection contract."""
import atexit
import json
import os
from pathlib import Path
import sys

import mlx.core as mx
from rapid_mlx import mllm_batch_generator as bg
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
variant = os.environ['HOTPATH_VARIANT']
assert variant in ('baseline', 'last_logits')
events = []
original_init = bg.MLLMBatchGenerator.__init__
def init(self, *args, **kwargs):
    original_init(self, *args, **kwargs)
    model = self.model
    assert type(model).__module__ == 'mlx_vlm.models.gemma4.gemma4'
    class ObserveProjection:
        def __getattr__(self, name):
            return getattr(model, name)
        def __call__(self, input_ids, *args, **kwargs):
            if variant == 'last_logits':
                kwargs['logits_to_keep'] = 1
            output = model(input_ids, *args, **kwargs)
            events.append({'input_shape': list(input_ids.shape),
                           'logits_shape': list(output.logits.shape),
                           'media': kwargs.get('pixel_values') is not None})
            return output
    self.model = ObserveProjection()
bg.MLLMBatchGenerator.__init__ = init

original_process = bg.MLLMBatchGenerator._process_prompts
def process(self, requests):
    mx.reset_peak_memory()
    result = original_process(self, requests)
    events.append({'request_ids': [r.request_id for r in requests],
                   'prefill_peak_bytes': mx.get_peak_memory(),
                   'prefill_active_bytes': mx.get_active_memory(),
                   'prefill_cached_bytes': mx.get_cache_memory()})
    return result
bg.MLLMBatchGenerator._process_prompts = process

@atexit.register
def save():
    (ROOT / ('e4b-last-logits-probe-' + os.environ['HOTPATH_RUN'] + '.json')).write_text(
        json.dumps({'variant': variant, 'events': events}, indent=2))

sys.argv = [sys.argv[0], 'serve', (ROOT/'gemma-e4b-model-path').read_text(),
            '--host', '127.0.0.1', '--port', '18646', '--served-model-name', 'hotpath',
            '--no-spec-decode', '--disable-prefix-cache', '--disable-disk-caches',
            '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
