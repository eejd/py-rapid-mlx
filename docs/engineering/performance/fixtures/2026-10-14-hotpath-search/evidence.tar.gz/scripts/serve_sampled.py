"""Reuse the existing fused sampler in the isolated MLLM factory only."""
import atexit
import json
import os
from pathlib import Path
import sys

from rapid_mlx import mllm_batch_generator as bg
from rapid_mlx._sampler_fast_path import is_fused_top_p_eligible, make_fused_top_p_temp_sampler
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
variant = os.environ['HOTPATH_VARIANT']
model_key = os.environ['HOTPATH_MODEL']
assert variant in ('baseline', 'fused') and model_key in ('qwen', 'gemma')
receipt = {'variant': variant, 'model': model_key, 'fused_factory_calls': 0,
           'fused_sample_calls': 0, 'stock_factory_calls': 0}
original_factory = bg.make_sampler
def factory(*args, **kwargs):
    temp, top_p = kwargs.get('temp', 0), kwargs.get('top_p', 0)
    min_p, top_k = kwargs.get('min_p', 0), kwargs.get('top_k', 0)
    allowed = not args and not (set(kwargs) - {'temp', 'top_p', 'min_p', 'top_k'})
    if variant == 'fused' and allowed and is_fused_top_p_eligible(
        temperature=temp, top_p=top_p, min_p=min_p, top_k=top_k):
        receipt['fused_factory_calls'] += 1
        sampler = make_fused_top_p_temp_sampler(temp, top_p, top_k)
        def observed(logprobs):
            receipt['fused_sample_calls'] += 1
            return sampler(logprobs)
        return observed
    receipt['stock_factory_calls'] += 1
    return original_factory(*args, **kwargs)
bg.make_sampler = factory

@atexit.register
def save():
    (ROOT / ('sampled-probe-' + os.environ['HOTPATH_RUN'] + '.json')).write_text(json.dumps(receipt, indent=2))

model = ((ROOT / 'gemma-model-path').read_text() if model_key == 'gemma' else
         str(Path.home() / '.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3'))
sys.argv = [sys.argv[0], 'serve', model, '--host', '127.0.0.1', '--port', '18646',
            '--served-model-name', 'hotpath', '--no-spec-decode',
            '--disable-disk-caches', '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
