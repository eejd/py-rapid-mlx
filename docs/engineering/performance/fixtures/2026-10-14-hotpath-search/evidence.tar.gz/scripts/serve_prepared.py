"""Measure duplicate host work; reuse already encoded text only in an isolated prototype."""
import array
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import mlx.core as mx
from rapid_mlx.engine.batched import BatchedEngine
from rapid_mlx.mllm_scheduler import MLLMScheduler
from rapid_mlx.mllm_batch_generator import MLLMBatchGenerator
from rapid_mlx.scheduler import Scheduler
from rapid_mlx.server import app
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
variant = os.environ['HOTPATH_VARIANT']
assert variant in ('baseline', 'reuse')
stats = {name: {'calls': 0, 'cpu_ns': 0, 'wall_ns': 0} for name in (
    'render', 'boundary', 'native_encode', 'mllm_preprocess', 'hash_observer')}
events, selections = [], []
reused = 0

def measure(owner, key, name):
    original = getattr(owner, key)
    def call(*args, **kwargs):
        wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
        try:
            return original(*args, **kwargs)
        finally:
            stats[name]['calls'] += 1
            stats[name]['cpu_ns'] += time.thread_time_ns()-cpu
            stats[name]['wall_ns'] += time.perf_counter_ns()-wall
    setattr(owner, key, call)
measure(BatchedEngine, '_apply_chat_template', 'render')
measure(BatchedEngine, '_compute_prefix_boundary', 'boundary')
measure(Scheduler, '_encode_prompt_string', 'native_encode')

original_start = BatchedEngine._start_mllm
async def start(self):
    await original_start(self)
    assert self._mllm_dense_singleton_fastpath and self._engine is not None
    tok = self.tokenizer
    backend = tok.backend_tokenizer
    post = None if backend.post_processor is None else json.loads(backend.post_processor.__getstate__())
    assert tok.bos_token is None
    assert post == {'type':'ByteLevel', 'add_prefix_space':False, 'trim_offsets':False, 'use_regex':False}
    self._mllm_scheduler._research_encoder = self.encode_prompt_text
BatchedEngine._start_mllm = start

original_add = MLLMScheduler.add_request_async
async def add(self, *args, **kwargs):
    global reused
    prompt = kwargs.get('prompt')
    if variant == 'reuse' and isinstance(prompt, str) and not kwargs.get('images') and not kwargs.get('videos'):
        encoded = self._research_encoder(prompt)
        if encoded is not None:
            kwargs['prompt'] = encoded
            reused += 1
    return await original_add(self, *args, **kwargs)
MLLMScheduler.add_request_async = add

original_preprocess = MLLMBatchGenerator._preprocess_request
def preprocess(self, request):
    wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
    was_ids = isinstance(request.prompt, list)
    original_preprocess(self, request)
    if variant == 'reuse' and was_ids:
        # Preserve the all-valid mask from the original plain-text processor.
        request.attention_mask = mx.ones_like(request.input_ids)
    stats['mllm_preprocess']['calls'] += 1
    stats['mllm_preprocess']['cpu_ns'] += time.thread_time_ns()-cpu
    stats['mllm_preprocess']['wall_ns'] += time.perf_counter_ns()-wall
    wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
    ids = array.array('I', request.input_ids.reshape(-1).tolist())
    mask = array.array('I', request.attention_mask.reshape(-1).tolist())
    assert sys.byteorder == 'little' and ids.itemsize == 4
    events.append({'request_id': request.request_id, 'was_ids': was_ids, 'tokens': len(ids),
                   'ids_sha256': hashlib.sha256(ids.tobytes()).hexdigest(),
                   'mask_sha256': hashlib.sha256(mask.tobytes()).hexdigest()})
    stats['hash_observer']['calls'] += 1
    stats['hash_observer']['cpu_ns'] += time.thread_time_ns()-cpu
    stats['hash_observer']['wall_ns'] += time.perf_counter_ns()-wall
MLLMBatchGenerator._preprocess_request = preprocess

original_select = BatchedEngine._select_mllm_request_path
def select(self, *args, **kwargs):
    result = original_select(self, *args, **kwargs)
    selections.append(bool(result))
    return result
BatchedEngine._select_mllm_request_path = select

@app.get('/__research/stats')
async def snapshot():
    return {'stats': {k: dict(v) for k,v in stats.items()}, 'events': list(events),
            'selections': list(selections), 'reused': reused}

model = str(Path.home()/'.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3')
sys.argv = [sys.argv[0], 'serve', model, '--host', '127.0.0.1', '--port', '18646',
            '--served-model-name', 'hotpath', '--no-spec-decode', '--disable-disk-caches',
            '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
