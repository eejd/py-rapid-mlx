"""Offline receipt verification and independent recomputation of reported medians."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import tarfile

parser = argparse.ArgumentParser()
parser.add_argument('archive', type=Path)
parser.add_argument('manifest', type=Path)
parser.add_argument('--source-dir', type=Path)
args = parser.parse_args()
manifest = json.loads(args.manifest.read_text())
assert hashlib.sha256(args.archive.read_bytes()).hexdigest() == manifest['sha256']
assert args.archive.stat().st_size == manifest['bytes']
members = {}
with tarfile.open(args.archive, 'r:gz') as archive:
    for item in archive.getmembers():
        assert item.isfile() and not item.name.startswith('/') and '..' not in Path(item.name).parts
        assert item.name not in members
        data = archive.extractfile(item).read()
        expected = manifest['members'][item.name]
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
        members[item.name] = data
assert set(members) == set(manifest['members'])
assert not any('/routes.json' in name or 'serve_route.py' in name for name in members)
def read(name):
    return json.loads(members[name])
def median(rows, field):
    return statistics.median(row[field] for row in rows)
base = '6d617f51cea61f9fa1cdd07a4dea11f66e04c355'
a, b = read('worker-a/metadata.json'), read('worker-b/metadata.json')
assert a['source'] == b['source'] == base
assert a['source_hashes'] == b['source_hashes']
if args.source_dir:
    for name, digest in a['source_hashes'].items():
        assert hashlib.sha256((args.source_dir/name).read_bytes()).hexdigest() == digest, name
repo = 'mlx-community/gemma-4-e2b-it-4bit'
assert a['models'][repo] == b['models'][repo]
complete = read('worker-a/metadata-all-models.json')
assert complete['source_hashes'] == a['source_hashes']
official = read('worker-a/official-model-digests.json')
assert len(official) == 6
for row in official:
    assert row['expected_sha256'] == row['actual_sha256']
    assert complete['models'][row['repo']]['files'][row['file']]['sha256'] == row['actual_sha256']
provenance = read('worker-a/dependency-provenance.json')
assert sum(p['python_files_compared'] for p in provenance['packages'].values())==1616
for package in provenance['packages'].values():
    assert package['mismatches']==0
    assert package['official_source_map_sha256']==package['worker_a_source_map_sha256']==package['worker_b_source_map_sha256']
for file in provenance['critical_files'].values():
    assert file['official']==file['worker_a']==file['worker_b']

summary = {'source_hashes_verified': len(a['source_hashes']), 'official_large_file_hashes': len(official), 'last_position': {}}
for worker, prefix, label in (('worker-a', 'last-logits', 'e2b-worker-a'),
                              ('worker-b', 'last-logits', 'e2b-worker-b'),
                              ('worker-a', 'e4b-last-logits', 'e4b-worker-a')):
    rows = read(worker+'/'+prefix+'-trials.json')
    assert len(rows) == 64 and sum(not r['warmup'] for r in rows) == 48
    assert {r['run'] for r in rows} == {0,1,2,3}
    cases = {}
    for case, tokens in ((16,220),(64,796),(192,2424),('image',280)):
        selected = [r for r in rows if r['case'] == case and not r['warmup']]
        assert len(selected) == 12
        for row in selected:
            assert row['correct'] and row['usage']['prompt_tokens'] == tokens
            assert row['usage']['completion_tokens'] > 0
            assert (row['usage'].get('prompt_tokens_details') or {}).get('cached_tokens',0) == 0
            assert 0 < row['ttft_s'] <= row['total_s']
            assert row['text'] == ('Red' if case == 'image' else '7319')
        values = [median([r for r in selected if r['variant'] == v], 'ttft_s') for v in ('baseline','last_logits')]
        cases[str(case)] = {'baseline_s': values[0], 'candidate_s': values[1], 'change_pct':100*(values[1]/values[0]-1)}
    for run in range(4):
        probe = read(worker+'/'+prefix+f'-probe-{run}.json')
        peaks = [event for event in probe['events'] if 'prefill_peak_bytes' in event]
        assert len(peaks) == 16
        assert {r['request_id'] for r in rows if r['run']==run} == {r['request_ids'][0] for r in peaks}
        shapes = [event['logits_shape'] for event in probe['events'] if 'logits_shape' in event]
        if run in (1,2):
            assert shapes and all(shape == [1,1,262144] for shape in shapes)
        else:
            assert all([1,n,262144] in shapes for n in (220,796,280))
    summary['last_position'][label] = cases

routing = read('worker-a/gemma-balanced.json')
assert len(routing)==20 and sum(r['case']!='warmup' for r in routing)==16
for case in ('solo_before','solo_after','active','waiter'):
    assert len({r['text_sha256'] for r in routing if r['case']==case}) == 1
for run in range(4):
    active = next(r for r in routing if r['run']==run and r['case']=='active')
    waiter = next(r for r in routing if r['run']==run and r['case']=='waiter')
    assert active['first_ns'] < waiter['started_ns'] < active['ended_ns']
    assert (waiter['first_ns'] < active['ended_ns']) == (waiter['variant']=='native_prototype')
summary['arrival'] = {v: {
    'waiter_ttft_s': median([r for r in routing if r['variant']==v and r['case']=='waiter'],'ttft_s'),
    'singleton_decode_s': median([r for r in routing if r['variant']==v and r['case'].startswith('solo')],'decode_s'),
    'active_total_s': median([r for r in routing if r['variant']==v and r['case']=='active'],'total_s')}
    for v in ('baseline','native_prototype')}
for run in (1,2):
    probe = read(f'worker-a/gemma-probe-native_prototype-balanced-{run}.json')
    installed = [r for r in probe if r.get('native_engine_started')]
    assert len(installed)==1 and installed[0]['shared_language_identity']
    assert installed[0]['active_before'] == installed[0]['active_after']
    assert all(not r['mllm'] for r in probe if 'mllm' in r)

for filename, expected in (('gemma-quality.json',28),('last-logits-quality.json',56)):
    rows = read('worker-a/'+filename)
    assert len(rows)==expected and all(r['pass'] for r in rows)
    for row in rows:
        if row['check']=='logprobs':
            assert row['values'] and all(math.isfinite(t['logprob']) and t['logprob']<=0 for t in row['values'])

rows = read('worker-a/trials.json')
assert len(rows)==24 and sum(not r['warmup'] for r in rows)==18
assert all(r['usage']['completion_tokens']==r['budget'] for r in rows)
for budget in (32,512,2048):
    assert len({r['text_sha256'] for r in rows if r['budget']==budget})==1
for filename, variants in (('sampled-trials.json',('baseline','fused')),('eager-trials.json',('baseline','eager'))):
    rows = read('worker-a/'+filename)
    assert len(rows)==32 and sum(not r['warmup'] for r in rows)==24
    assert all(r['usage']['completion_tokens']==r['budget'] for r in rows)
    summary[filename] = {}
    for model in ('qwen','gemma'):
        measured = [r for r in rows if r['model']==model and not r['warmup']]
        assert all(sum(r['variant']==v for r in measured)==6 for v in variants)
        summary[filename][model] = {v: median([r for r in measured if r['variant']==v], 'decode_s') for v in variants}
        if filename=='eager-trials.json':
            assert len({r['text_sha256'] for r in measured})==1
for run in (1,2,5,6):
    assert read(f'worker-a/sampled-probe-{run}.json')['fused_sample_calls']>1000
    assert read(f'worker-a/eager-probe-{run}.json')['submit_calls']>1000

dense = read('worker-a/dense-projection-results.json')
assert len(dense)==18 and all(r['exact'] and r['max_abs_error']==0 for r in dense)
qkv = read('worker-a/qkv-projection-results.json')
assert len(qkv)==18 and all(r['exact'] for r in qkv if r['tokens']!=128)
assert all(not r['exact'] and r['max_abs_error']>0 for r in qkv if r['tokens']==128)
contract = read('worker-a/compiled-contract.json')
assert contract['gdn_numerical_tags']==0 and contract['attention_numerical_tags']==0
assert read('worker-a/compiled-disposition.json')['performance_comparison_valid'] is False

prepared = read('worker-a/prepared-trials.json')
assert len(prepared)==48 and sum(not r['cold'] for r in prepared)==36
summary['prepared'] = {}
for size in (128,512,2048):
    for turn in range(4):
        subset = [r for r in prepared if r['records']==size and r['turn']==turn]
        assert len(subset)==4
        assert len({(r['input']['ids_sha256'],r['input']['mask_sha256']) for r in subset})==1
        assert len({json.dumps(r['usage'],sort_keys=True) for r in subset})==1
        for row in subset:
            assert row['done'] and row['finish_reason']=='stop' and row['text']=='7319'
            assert row['reused']==int(row['variant']=='reuse')
            assert row['input']['was_ids']==(row['variant']=='reuse')
    summary['prepared'][str(size)] = {}
    for variant in ('baseline','reuse'):
        selected = [r for r in prepared if r['records']==size and r['variant']==variant and not r['cold']]
        summary['prepared'][str(size)][variant] = {
            'warm_ttft_s': median(selected,'ttft_s'),
            'preprocess_cpu_ms': statistics.median(r['host_cpu_ns']['mllm_preprocess'] for r in selected)/1e6,
            'tokens_min': min(r['usage']['prompt_tokens'] for r in selected),
            'tokens_max': max(r['usage']['prompt_tokens'] for r in selected)}

host_files, samples, swap_by_worker = 0, [], {}
for name in members:
    if name.endswith('.json') and ('/host-' in name or '-host-' in name):
        d = read(name)
        assert d['exit']==0 and d['samples']
        assert all(not r['foreign'] for r in d['samples'])
        samples.extend(d['samples'])
        swap_by_worker.setdefault(name.split('/')[0], set()).update(r['swap'] for r in d['samples'])
        host_files += 1
assert swap_by_worker == {'worker-a': {195493888}, 'worker-b': {512032768}}
summary['host_files'] = host_files
summary['host_samples'] = len(samples)
summary['swap_bytes_by_worker'] = {k: sorted(v) for k,v in swap_by_worker.items()}
summary['validated_members'] = len(members)
summary['archive_sha256'] = manifest['sha256']
print(json.dumps(summary, indent=2))
