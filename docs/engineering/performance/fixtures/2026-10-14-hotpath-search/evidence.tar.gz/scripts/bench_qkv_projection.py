"""Exactness-first merged attention Q/K/V probe using immutable real weights."""
import json
from pathlib import Path
import statistics
import time

from rapid_mlx import _mlx_compat
_mlx_compat.install()
import mlx.core as mx

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
results = []
for model, repo, revision in (
    ('qwen', 'mlx-community/Qwen3.5-4B-MLX-4bit', '32f3e8ecf65426fc3306969496342d504bfa13f3'),
    ('gemma', 'mlx-community/gemma-4-e2b-it-4bit', '238767527555cb75a05732a84dff5d6ba0dd6809'),
):
    snapshot = Path.home()/'.cache/huggingface/hub'/('models--'+repo.replace('/', '--'))/'snapshots'/revision
    config = json.loads((snapshot/'config.json').read_text())
    q = config.get('quantization') or config['quantization_config']
    assert q['bits'] == 4 and q['group_size'] == 64 and q.get('mode', 'affine') == 'affine'
    weights = {}
    for file in sorted(snapshot.glob('*.safetensors')):
        weights.update(mx.load(str(file)))
    prefixes = sorted(k[:-len('.q_proj.weight')] for k in weights
        if k.endswith('.q_proj.weight') and 'language_model' in k
        and k.replace('.q_proj.weight', '.k_proj.weight') in weights
        and k.replace('.q_proj.weight', '.v_proj.weight') in weights)
    assert len(prefixes) >= 3
    for prefix in (prefixes[0], prefixes[len(prefixes)//2], prefixes[-1]):
        arrays = [tuple(weights[prefix+'.'+name+'.'+suffix] for suffix in ('weight', 'scales', 'biases'))
                  for name in ('q_proj', 'k_proj', 'v_proj')]
        merged = tuple(mx.concatenate([a[i] for a in arrays], axis=0) for i in range(3))
        mx.eval(merged)
        widths = [a[0].shape[0] for a in arrays]
        cuts = [widths[0], widths[0]+widths[1]]
        def linear(x, packed):
            return mx.quantized_matmul(x, *packed, transpose=True, group_size=64, bits=4, mode='affine')
        def baseline(x):
            return [linear(x, a) for a in arrays]
        def fused(x):
            return mx.split(linear(x, merged), cuts, axis=-1)
        for tokens in (1, 8, 128):
            mx.random.seed(123)
            x = (mx.random.normal((1, tokens, arrays[0][0].shape[-1]*8))*.1).astype(mx.bfloat16)
            expected, actual = baseline(x), fused(x)
            mx.eval(expected, actual)
            exact = all(bool(mx.array_equal(a,b).item()) for a,b in zip(expected, actual))
            errors = [float(mx.max(mx.abs(a.astype(mx.float32)-b.astype(mx.float32))).item()) for a,b in zip(expected, actual)]
            row = {'model': model, 'layer': prefix, 'tokens': tokens, 'widths': widths,
                   'exact': exact, 'max_abs_error': max(errors), 'baseline_ns': [], 'fused_ns': []}
            if exact:
                for _ in range(5):
                    mx.eval(baseline(x))
                    mx.eval(fused(x))
                for pair in range(6):
                    for name, fn in ((('baseline', baseline), ('fused', fused)) if pair%2 == 0 else (('fused', fused), ('baseline', baseline))):
                        started = time.perf_counter_ns()
                        for _ in range(20):
                            mx.eval(fn(x))
                        row[name+'_ns'].append((time.perf_counter_ns()-started)/20)
                row['median_speed_ratio'] = statistics.median(row['baseline_ns'])/statistics.median(row['fused_ns'])
            results.append(row)
            (ROOT/'qkv-projection-results.json').write_text(json.dumps(results, indent=2))
            print(json.dumps({k:v for k,v in row.items() if not k.endswith('_ns')}), flush=True)
    del weights
    mx.clear_cache()
