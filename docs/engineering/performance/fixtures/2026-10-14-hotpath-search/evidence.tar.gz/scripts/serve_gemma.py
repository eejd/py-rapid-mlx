"""Observe the unmodified routing policy for a second model architecture."""
import atexit
import json
import os
from pathlib import Path
import sys
import time

from rapid_mlx.engine import batched
from rapid_mlx.engine.batched import BatchedEngine
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
receipts = []
variant = os.environ.get('HOTPATH_ROUTE', 'baseline')
assert variant in ('baseline', 'native_prototype')
if variant == 'native_prototype':
    from rapid_mlx.models.gemma4_text import Gemma4TextWrapper
    import mlx.core as mx
    # Reuse the existing wrapper and shared-executor startup mechanism. This
    # is an exploratory architecture enrollment, not production qualification.
    batched.Qwen36NativeCacheTextWrapper = Gemma4TextWrapper
    def eligible(language_model, *, config_model_type, arrays_cache_compat,
                 spec_decode, no_hybrid=False):
        assert config_model_type == 'gemma4' and spec_decode == 'none' and not no_hybrid
        receipts.append({'eligibility': config_model_type,
                         'cache_types': [type(c).__module__ + '.' + type(c).__name__
                                         for c in language_model.make_cache()]})
        return True
    batched._should_start_qwen36_native_text_cache = eligible
    original_start = BatchedEngine._start_qwen36_native_text_engine
    async def start(self, language_model):
        before = self._model_load_executor.submit(mx.get_active_memory).result()
        await original_start(self, language_model)
        assert self._mllm_native_text_engine and self._engine is not None
        wrapper = self._engine.engine.model
        assert wrapper.language_model is language_model
        after = self._model_load_executor.submit(mx.get_active_memory).result()
        receipts.append({'native_engine_started': True, 'shared_language_identity': True,
                         'active_before': before, 'active_after': after})
    BatchedEngine._start_qwen36_native_text_engine = start
original = BatchedEngine._select_mllm_request_path
def select(self, images, videos, admission_token):
    result = original(self, images, videos, admission_token)
    receipts.append({'at_ns': time.perf_counter_ns(), 'mllm': result,
                     'media': bool(images or videos),
                     'native_engine_present': self._engine is not None})
    return result
BatchedEngine._select_mllm_request_path = select

@atexit.register
def save():
    (ROOT / ('gemma-probe-' + variant + '-' + os.environ['HOTPATH_RUN'] + '.json')).write_text(json.dumps(receipts, indent=2))

sys.argv = [sys.argv[0], 'serve', (ROOT / 'gemma-model-path').read_text(),
            '--host', '127.0.0.1', '--port', '18646', '--served-model-name', 'hotpath',
            '--no-spec-decode', '--disable-disk-caches', '--disable-model-downloads',
            '--log-level', 'WARNING']
cli_entrypoint()
