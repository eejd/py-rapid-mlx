"""Preflight the replay numerical prerequisites without serving any request."""
import asyncio
import json
from pathlib import Path

from rapid_mlx.engine.batched import BatchedEngine
from rapid_mlx.scheduler import SchedulerConfig
from rapid_mlx import compiled_decode

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
async def main():
    model = str(Path.home()/'.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3')
    engine = BatchedEngine(model, force_text=True, no_spec_decode=True,
                           scheduler_config=SchedulerConfig(spec_decode='none', kv_cache_dtype='bf16'))
    try:
        await engine.start()
        modules = [m for _,m in engine._model.named_modules()]
        gdn = sum(bool(getattr(m, '_rapid_qwen35_fused_gdn_decode', False)) for m in modules)
        attention = sum(bool(getattr(m, '_rapid_compiled_gate_precision', False)) for m in modules)
        result = {'snapshot': '32f3e8ecf65426fc3306969496342d504bfa13f3',
                  'gdn_numerical_tags': gdn, 'attention_numerical_tags': attention,
                  'dense_probe_requires_gdn_tags': 24, 'dense_probe_requires_attention_tags': 8,
                  'existing_enrollment_reason': compiled_decode.model_qualification_reason(engine._model, model),
                  'no_completion_request_sent': True}
        (ROOT/'compiled-contract.json').write_text(json.dumps(result, indent=2))
        print(json.dumps(result), flush=True)
    finally:
        await engine.stop()
asyncio.run(main())
