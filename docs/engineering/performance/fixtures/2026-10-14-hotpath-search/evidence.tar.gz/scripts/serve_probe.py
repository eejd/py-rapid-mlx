"""Isolated experimental server. Never a serving patch or logprobs qualification."""
import atexit
import collections
import inspect
import json
import os
from pathlib import Path
import sys
import textwrap
import time

import mlx.core as mx
from rapid_mlx import mllm_batch_generator as bg
from rapid_mlx.mllm_scheduler import MLLMScheduler
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
variant = os.environ['HOTPATH_VARIANT']
assert variant in ('baseline', 'sparse_clear', 'greedy_no_distribution')
stats = collections.defaultdict(lambda: {'calls': 0, 'wall_ns': 0, 'cpu_ns': 0})
samples = []

def instrument(owner, key, name):
    original = getattr(owner, key)
    def observed(*args, **kwargs):
        wall, cpu = time.perf_counter_ns(), time.thread_time_ns()
        try:
            return original(*args, **kwargs)
        finally:
            state = stats[name]
            state['calls'] += 1
            state['wall_ns'] += time.perf_counter_ns() - wall
            state['cpu_ns'] += time.thread_time_ns() - cpu
    setattr(owner, key, observed)

if variant == 'sparse_clear':
    original_init = MLLMScheduler.__init__
    def init(self, *args, **kwargs):
        original_init(self, *args, **kwargs)
        self._clear_cache_interval = 10**9
    MLLMScheduler.__init__ = init

if variant == 'greedy_no_distribution':
    # Experimental upper bound only: this private server accepts only the
    # harness's greedy/no-logprobs requests. Dummy distributions are invalid
    # for public logprobs consumers. Production needs explicit demand plumbing.
    source = textwrap.dedent(inspect.getsource(bg.MLLMBatchGenerator._step))
    needle = 'logprobs = logits - mx.logsumexp(logits, axis=-1, keepdims=True)'
    assert source.count(needle) == 1
    source = source.replace(needle, 'assert requests and all(r.temperature == 0 for r in requests)\n    logprobs = logits')
    assert source.count('return sampled, list(logprobs)') == 1
    source = source.replace('return sampled, list(logprobs)', 'return sampled, [mx.zeros((1,)) for _ in requests]')
    namespace = {}
    exec(compile(source, '<isolated-greedy-prototype>', 'exec'), bg.__dict__, namespace)
    bg.MLLMBatchGenerator._step = namespace['_step']

instrument(mx, 'clear_cache', 'clear_cache')
instrument(bg.MLLMBatchGenerator, '_step', 'decode_graph')
instrument(bg.MLLMBatchGenerator, '_next', 'batch_next')
instrument(MLLMScheduler, '_process_batch_responses', 'responses')
original_step = MLLMScheduler.step
def step(self, *args, **kwargs):
    result = original_step(self, *args, **kwargs)
    if self._step_count % 128 == 0:
        samples.append({'step': self._step_count, 'active': mx.get_active_memory(),
                        'cached': mx.get_cache_memory(), 'peak': mx.get_peak_memory()})
    return result
MLLMScheduler.step = step

@atexit.register
def save():
    (ROOT / ('probe-' + os.environ['HOTPATH_RUN'] + '.json')).write_text(
        json.dumps({'variant': variant, 'stats': dict(stats), 'memory': samples}, indent=2))

model = str(Path.home() / '.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3')
sys.argv = [sys.argv[0], 'serve', model, '--host', '127.0.0.1', '--port', '18646',
            '--served-model-name', 'hotpath', '--no-spec-decode',
            '--disable-disk-caches', '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
