"""Real HTTP correctness/lifecycle probes for experimental shared Gemma routing."""
import asyncio
import base64
import io
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

import httpx
from PIL import Image

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
results = []
code_prompt = ('Write Python source only. Define 1000 functions named square_0001 through square_1000. '
               'Each takes x and returns x*x. No loops or abbreviation. Keep writing until the limit.')

def record(variant, name, passed, **details):
    row = {'variant': variant, 'check': name, 'pass': bool(passed), **details}
    results.append(row)
    (ROOT / 'gemma-quality.json').write_text(json.dumps(results, indent=2))
    print(json.dumps(row), flush=True)

async def checks(variant, proc):
    async with httpx.AsyncClient(base_url='http://127.0.0.1:18646', timeout=300, trust_env=False) as c:
        deadline = time.monotonic()+300
        while True:
            if proc.poll() is not None:
                raise RuntimeError('server exited')
            try:
                if (await c.get('/health/ready')).status_code == 200:
                    break
            except httpx.HTTPError:
                pass
            assert time.monotonic() < deadline
            await asyncio.sleep(.5)

        async def chat(messages, **kwargs):
            if isinstance(messages, str):
                messages = [{'role': 'user', 'content': messages}]
            body = {'model': 'hotpath', 'messages': messages, 'max_tokens': 32,
                    'temperature': 0, 'enable_thinking': False, **kwargs}
            response = await c.post('/v1/chat/completions', json=body)
            response.raise_for_status()
            d = response.json()
            assert d['usage']['completion_tokens'] > 0
            return d['choices'][0]['message'].get('content') or '', d

        for name, prompt, expected in (
            ('arithmetic', 'What is 7 times 8? Reply with only the integer.', '56'),
            ('repeat_arithmetic', 'What is 7 times 8? Reply with only the integer.', '56'),
            ('long_retrieval', 'Access code: 7319.\n' + ('A ledger row records apples and oranges.\n' * 700)
             + 'What is the access code stated at the start? Reply with the four digits only.', '7319'),
        ):
            text, data = await chat(prompt)
            record(variant, name, text.strip() == expected, text=text, usage=data['usage'])

        text, data = await chat([
            {'role': 'user', 'content': 'My access code is 7319.'},
            {'role': 'assistant', 'content': 'Understood.'},
            {'role': 'user', 'content': 'What is my access code? Reply with four digits only.'}])
        record(variant, 'multiturn', text.strip() == '7319', text=text, usage=data['usage'])

        text, data = await chat('Reply exactly with {"answer":56} and no other text.')
        try:
            parsed = json.loads(re.sub(r'^```(?:json)?\s*|\s*```$', '', text.strip()))
        except ValueError:
            parsed = None
        record(variant, 'json', parsed == {'answer': 56}, text=text)

        text, data = await chat('Count from one to ten.', max_tokens=5, logprobs=True, top_logprobs=3)
        tokens = ((data['choices'][0].get('logprobs') or {}).get('content') or [])
        valid = bool(tokens) and all(math.isfinite(t['logprob']) and t['logprob'] <= 0 for t in tokens)
        record(variant, 'logprobs', valid, token_count=len(tokens), values=tokens)

        a, _ = await chat(code_prompt, max_tokens=64, temperature=.7, top_p=.9, seed=123)
        b, _ = await chat(code_prompt, max_tokens=64, temperature=.7, top_p=.9, seed=123)
        record(variant, 'seeded_repeat', a == b, first=a, second=b)

        rid, chunks = None, 0
        body = {'model': 'hotpath', 'messages': [{'role': 'user', 'content': code_prompt}],
                'max_tokens': 2048, 'temperature': 0, 'enable_thinking': False, 'stream': True}
        async with c.stream('POST', '/v1/chat/completions', json=body) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.startswith('data:') or line[5:].strip() == '[DONE]':
                    continue
                d = json.loads(line[5:])
                rid = d.get('id', rid)
                for choice in d.get('choices', []):
                    chunks += bool(choice.get('delta', {}).get('content'))
                if chunks >= 4:
                    accepted = await c.post(f'/v1/requests/{rid}/cancel')
                    record(variant, 'cancel_accepted', accepted.status_code == 200, status=accepted.status_code)
                    break
        assert rid and chunks >= 4
        deadline = time.monotonic()+15
        while time.monotonic() < deadline:
            status = (await c.get('/v1/status')).json()
            if status.get('num_running', 0) == status.get('num_waiting', 0) == 0:
                break
            await asyncio.sleep(.1)
        else:
            raise RuntimeError('scheduler did not drain')
        duplicate = await c.post(f'/v1/requests/{rid}/cancel')
        record(variant, 'cancel_drained_and_duplicate', duplicate.status_code == 404, status=duplicate.status_code)
        text, _ = await chat('What is 7 times 8? Reply with only the integer.')
        record(variant, 'cancel_recovery', text.strip() == '56', text=text)

        buf = io.BytesIO()
        Image.new('RGB', (224, 224), (255, 0, 0)).save(buf, format='PNG')
        url = 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()
        media = [{'role': 'user', 'content': [
            {'type': 'text', 'text': 'What color is this image? Reply with one English color word.'},
            {'type': 'image_url', 'image_url': {'url': url}}]}]
        (image_text, _), (text, _) = await asyncio.gather(
            chat(media, max_tokens=16), chat('What is 7 times 8? Reply with only the integer.'))
        record(variant, 'concurrent_media_text', bool(re.search(r'\bred\b', image_text, re.I)) and text.strip() == '56',
               image_text=image_text, text=text)
        text, _ = await chat('What is 7 times 8? Reply with only the integer.')
        record(variant, 'post_media_recovery', text.strip() == '56', text=text)
        record(variant, 'ready', (await c.get('/health/ready')).status_code == 200)

for index, variant in enumerate(('baseline', 'native_prototype')):
    env = dict(os.environ, PYTHONPATH=str(ROOT/'src'), HOTPATH_ROUTE=variant,
               HOTPATH_RUN='quality-'+str(index), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               RAPID_MLX_TELEMETRY='0')
    with (ROOT / f'gemma-quality-server-{index}.log').open('w') as log:
        proc = subprocess.Popen([sys.executable, str(ROOT/'serve_gemma.py')], cwd=ROOT/'src', env=env,
                                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (ROOT/'active-pgid').write_text(str(proc.pid))
        try:
            asyncio.run(checks(variant, proc))
        except Exception as exc:
            record(variant, 'harness_exception', False, error_type=type(exc).__name__, error=str(exc))
        finally:
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGTERM)
                proc.wait(timeout=15)
            (ROOT/'active-pgid').unlink(missing_ok=True)
            record(variant, 'clean_exit', proc.returncode == 0, code=proc.returncode)

raise SystemExit(0 if all(x['pass'] for x in results) else 1)
