"""Qualified-shape research of earlier decoder-layer submission, no source edits."""
import atexit
import json
import os
from pathlib import Path
import sys

import mlx.core as mx
from rapid_mlx import mllm_batch_generator as bg
from rapid_mlx.cli import cli_entrypoint

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
variant, model_key = os.environ['HOTPATH_VARIANT'], os.environ['HOTPATH_MODEL']
assert variant in ('baseline', 'eager') and model_key in ('qwen', 'gemma')
receipt = {'variant': variant, 'model': model_key, 'submit_calls': 0, 'layer_classes': []}
original_init = bg.MLLMBatchGenerator.__init__
def init(self, *args, **kwargs):
    original_init(self, *args, **kwargs)
    patched = set()
    for layer in self.language_model.layers:
        cls = type(layer)
        if cls in patched:
            continue
        patched.add(cls)
        receipt['layer_classes'].append(cls.__module__+'.'+cls.__name__)
        original = cls.__call__
        def wrap(original):
            def call(self, *args, **kwargs):
                out = original(self, *args, **kwargs)
                hidden = out[0] if isinstance(out, tuple) else out
                shape = getattr(hidden, 'shape', ())
                if variant == 'eager' and len(shape) == 3 and shape[0]*shape[1] <= 8:
                    mx.async_eval(hidden)
                    receipt['submit_calls'] += 1
                return out
            return call
        cls.__call__ = wrap(original)
bg.MLLMBatchGenerator.__init__ = init

@atexit.register
def save():
    (ROOT/('eager-probe-'+os.environ['HOTPATH_RUN']+'.json')).write_text(json.dumps(receipt, indent=2))

model = ((ROOT/'gemma-model-path').read_text() if model_key == 'gemma' else
         str(Path.home()/'.cache/huggingface/hub/models--mlx-community--Qwen3.5-4B-MLX-4bit/snapshots/32f3e8ecf65426fc3306969496342d504bfa13f3'))
sys.argv = [sys.argv[0], 'serve', model, '--host', '127.0.0.1', '--port', '18646',
            '--served-model-name', 'hotpath', '--no-spec-decode', '--disable-disk-caches',
            '--disable-model-downloads', '--log-level', 'WARNING']
cli_entrypoint()
