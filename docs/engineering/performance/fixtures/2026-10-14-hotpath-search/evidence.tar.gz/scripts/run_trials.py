import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import httpx
import psutil

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
assert (ROOT / '.task-owner').read_text() == 'rapid-hotpath-m4-20261014-v1'
rows = []
prompt = ('Write Python source code only. Define 1000 small functions named square_0001 through '
          'square_1000. Each function takes x, assigns result = x * x, and returns result. '
          'Put each function on separate lines. Do not use a loop or abbreviate the functions. '
          'Keep writing functions until the output limit. Start with def square_0001(x):')
order = ['baseline', 'sparse_clear', 'greedy_no_distribution',
         'greedy_no_distribution', 'sparse_clear', 'baseline']

for run, variant in enumerate(order):
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'), HOTPATH_VARIANT=variant,
               HOTPATH_RUN=str(run), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    host_samples = []
    stop = threading.Event()
    log = (ROOT / f'server-{run}.log').open('w')
    proc = subprocess.Popen([sys.executable, str(ROOT / 'serve_probe.py')],
                            cwd=ROOT / 'src', env=env, stdout=log,
                            stderr=subprocess.STDOUT, start_new_session=True)
    (ROOT / 'active-pgid').write_text(str(proc.pid))
    def monitor():
        while not stop.wait(1):
            try:
                foreign = []
                for other in psutil.process_iter(['pid', 'name', 'memory_info']):
                    item = other.info
                    if item['pid'] not in (os.getpid(), proc.pid) and 'python' in (item['name'] or '').lower() and item['memory_info'].rss > 512*1024**2:
                        foreign.append({'pid': item['pid'], 'rss': item['memory_info'].rss})
                host_samples.append({'rss': psutil.Process(proc.pid).memory_info().rss,
                                     'swap': psutil.swap_memory().used, 'foreign': foreign})
            except psutil.Error:
                pass
    thread = threading.Thread(target=monitor, daemon=True)
    thread.start()
    try:
        with httpx.Client(base_url='http://127.0.0.1:18646', timeout=300, trust_env=False) as client:
            deadline = time.monotonic() + 300
            while True:
                if proc.poll() is not None:
                    raise RuntimeError(f'server {run} exited: see log')
                try:
                    if client.get('/health/ready').status_code == 200:
                        break
                except httpx.HTTPError:
                    pass
                if time.monotonic() > deadline:
                    raise TimeoutError('readiness')
                time.sleep(.5)
            for index, n in enumerate((32, 512, 2048, 512)):
                before = psutil.Process(proc.pid).cpu_times()
                at = time.perf_counter_ns()
                first = None
                usage = None
                done = False
                finish = None
                text = []
                body = {'model': 'hotpath', 'messages': [{'role': 'user', 'content': prompt}],
                        'max_tokens': n, 'temperature': 0, 'enable_thinking': False,
                        'logprobs': False, 'stream': True, 'stream_options': {'include_usage': True}}
                with client.stream('POST', '/v1/chat/completions', json=body) as response:
                    response.raise_for_status()
                    for line in response.iter_lines():
                        if not line.startswith('data:'):
                            continue
                        payload = line[5:].strip()
                        if payload == '[DONE]':
                            done = True
                            continue
                        event = json.loads(payload)
                        if event.get('usage'):
                            usage = event['usage']
                        for choice in event.get('choices', []):
                            content = choice.get('delta', {}).get('content') or ''
                            if content:
                                first = first or time.perf_counter_ns()
                                text.append(content)
                            finish = choice.get('finish_reason') or finish
                end = time.perf_counter_ns()
                after = psutil.Process(proc.pid).cpu_times()
                assert done and first and usage and finish == 'length'
                assert usage['completion_tokens'] == n
                row = {'run': run, 'variant': variant, 'index': index, 'warmup': index == 0,
                       'budget': n, 'usage': usage, 'ttft_s': (first-at)/1e9,
                       'decode_s': (end-first)/1e9, 'total_s': (end-at)/1e9,
                       'cpu_s': after.user+after.system-before.user-before.system,
                       'text_sha256': hashlib.sha256(''.join(text).encode()).hexdigest()}
                rows.append(row)
                (ROOT / 'trials.json').write_text(json.dumps(rows, indent=2))
                print(json.dumps(row), flush=True)
    finally:
        stop.set()
        thread.join(timeout=3)
        proc.send_signal(signal.SIGINT)
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            proc.wait(timeout=15)
        (ROOT / 'active-pgid').unlink(missing_ok=True)
        log.close()
        (ROOT / f'host-{run}.json').write_text(json.dumps({'samples': host_samples, 'exit': proc.returncode}))
    assert proc.returncode == 0

for n in (512, 2048):
    assert len({r['text_sha256'] for r in rows if r['budget'] == n}) == 1
print('Exact visible output equality passed for both budgets and all variants.', flush=True)
