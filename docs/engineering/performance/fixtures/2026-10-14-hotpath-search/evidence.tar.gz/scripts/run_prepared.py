import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import httpx

ROOT = Path('/private/tmp/rapid-mlx-hotpath-search')
rows = []
for run, variant in enumerate(('baseline', 'reuse', 'reuse', 'baseline')):
    env = dict(os.environ, PYTHONPATH=str(ROOT/'src'), HOTPATH_VARIANT=variant,
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    with (ROOT/f'prepared-server-{run}.log').open('w') as log:
        proc = subprocess.Popen([sys.executable, str(ROOT/'serve_prepared.py')],
            cwd=ROOT/'src', env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        (ROOT/'active-pgid').write_text(str(proc.pid))
        try:
            with httpx.Client(base_url='http://127.0.0.1:18646', timeout=300, trust_env=False) as c:
                deadline = time.monotonic()+300
                while True:
                    if proc.poll() is not None:
                        raise RuntimeError('server exited')
                    try:
                        if c.get('/health/ready').status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                    assert time.monotonic() < deadline
                    time.sleep(.5)
                for size in (128, 512, 2048):
                    c.post('/v1/cache/clear').raise_for_status()
                    messages = [{'role':'user', 'content': f'Session {size}. Access code: 7319.\n'
                        + ''.join(f'Entry {n}: apples, pears, oranges.\n' for n in range(size))
                        + 'The access code is 7319. Reply with the four-digit code only.'}]
                    for turn in range(4):
                        if turn:
                            messages += [{'role':'assistant','content':'7319'},
                                         {'role':'user','content':f'Turn {turn}. Repeat the access code. Reply with four digits only.'}]
                        before = c.get('/__research/stats').raise_for_status().json()
                        body = {'model':'hotpath', 'messages':messages, 'max_tokens':16,
                                'temperature':0, 'enable_thinking':False, 'stream':True,
                                'stream_options':{'include_usage':True}}
                        at = time.perf_counter_ns()
                        first, usage, done, finish, rid, pieces = None, None, False, None, None, []
                        with c.stream('POST','/v1/chat/completions',json=body) as response:
                            response.raise_for_status()
                            for line in response.iter_lines():
                                if not line.startswith('data:'):
                                    continue
                                payload = line[5:].strip()
                                if payload == '[DONE]':
                                    done = True
                                    continue
                                d = json.loads(payload)
                                rid = d.get('id',rid)
                                usage = d.get('usage') or usage
                                for choice in d.get('choices',[]):
                                    text = choice.get('delta',{}).get('content') or ''
                                    if text:
                                        first = first or time.perf_counter_ns()
                                        pieces.append(text)
                                    finish = choice.get('finish_reason') or finish
                        end = time.perf_counter_ns()
                        text = ''.join(pieces).strip()
                        assert done and first and usage and finish and text == '7319', (variant,size,turn,text)
                        after = c.get('/__research/stats').raise_for_status().json()
                        new_events = after['events'][len(before['events']):]
                        selected = after['selections'][len(before['selections']):]
                        assert len(new_events)==1 and selected==[True], (new_events,selected)
                        cpu = {k: after['stats'][k]['cpu_ns']-v['cpu_ns'] for k,v in before['stats'].items()}
                        row = {'run':run,'variant':variant,'records':size,'turn':turn,'cold':turn==0,
                               'request_id':rid,'usage':usage,'text':text,'done':done,'finish_reason':finish,
                               'ttft_s':(first-at)/1e9,'total_s':(end-at)/1e9,'host_cpu_ns':cpu,
                               'input':new_events[0],'reused':after['reused']-before['reused']}
                        rows.append(row)
                        (ROOT/'prepared-trials.json').write_text(json.dumps(rows,indent=2))
                        print(json.dumps(row),flush=True)
        finally:
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                try:
                    proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:
                        proc.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid,signal.SIGKILL)
                        proc.wait(timeout=10)
            (ROOT/'active-pgid').unlink(missing_ok=True)
    assert proc.returncode==0
for size in (128,512,2048):
    for turn in range(4):
        subset=[x for x in rows if x['records']==size and x['turn']==turn]
        assert len({(x['input']['ids_sha256'],x['input']['mask_sha256']) for x in subset})==1
        assert len({json.dumps(x['usage'],sort_keys=True) for x in subset})==1
print('Prepared input reuse: all token/mask hashes, usage, cache counts and answers match.',flush=True)
