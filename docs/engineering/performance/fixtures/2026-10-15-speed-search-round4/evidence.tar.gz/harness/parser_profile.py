"""CPU-only parser screening; never represents an inference speedup."""
import cProfile
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT=Path('/private/tmp/rapid-mlx-speed-search-round4')
sys.path.insert(0,str(ROOT/'worktree'))
from rapid_mlx.tool_parsers.gemma4_tool_parser import Gemma4ToolParser
from rapid_mlx.tool_parsers.hermes_tool_parser import HermesToolParser
from rapid_mlx.tool_parsers.qwen3coder_tool_parser import Qwen3CoderToolParser
from rapid_mlx.tool_parsers.qwen_tool_parser import QwenToolParser

request={'tools':[{'type':'function','function':{'name':'write_file','parameters':{'type':'object','properties':{'path':{'type':'string'},'content':{'type':'string'}}}}}]}
rows=[]
for size in [1024,4096,16384,32768]:
    payload=("def f():\n    return {'x': 42}\n"*((size//29)+2))[:size]+'END'
    arguments={'path':'src/test.py','content':payload}
    json_wire='<tool_call>'+json.dumps({'name':'write_file','arguments':arguments})+'</tool_call>'
    xml_wire='<tool_call><function=write_file><parameter=path>"src/test.py"</parameter><parameter=content>'+json.dumps(payload)+'</parameter></function></tool_call>'
    stripped='call:write_file{path:<|"|>src/test.py<|"|>,content:<|"|>'+payload+'<|"|>}'
    for label,cls,wire in [('qwen_json',QwenToolParser,json_wire),('hermes_json',HermesToolParser,json_wire),
                           ('gemma_raw',Gemma4ToolParser,'<|tool_call>'+stripped+'<tool_call|>'),
                           ('gemma_stripped',Gemma4ToolParser,stripped)]:
        trials=[];peaks=[];call_count=None;digest=None
        for repeat in range(2):
            parser=cls();previous='';results=[];times=[]
            at=time.process_time()
            for pos in range(0,len(wire),8):
                delta=wire[pos:pos+8];current=previous+delta
                before=time.process_time()
                out=parser.extract_tool_calls_streaming(previous,current,delta,request=request)
                times.append(time.process_time()-before)
                if out:results.append(out)
                previous=current
            elapsed=time.process_time()-at
            fragments={}
            for result in results:
                for call in result.get('tool_calls',[]):
                    function=call.get('function',{});idx=call['index']
                    entry=fragments.setdefault(idx,{'name':'','arguments':''})
                    entry['name']+=function.get('name') or ''
                    entry['arguments']+=function.get('arguments') or ''
            assert len(fragments)==1,(label,size,fragments)
            parsed=fragments[0];assert parsed['name']=='write_file',(label,parsed['name'])
            assert json.loads(parsed['arguments'])==arguments,(label,size)
            digest=hashlib.sha256(json.dumps(arguments,sort_keys=True).encode()).hexdigest()
            trials.append(elapsed);peaks.append(max(times));call_count=len(times)
        row={'parser':label,'payload_bytes':len(payload.encode()),'wire_bytes':len(wire.encode()),'chunk_bytes':8,'calls':call_count,
             'cpu_samples_s':trials,'median_cpu_s':statistics.median(trials),'max_call_cpu_s':max(peaks),'semantic_sha256':digest}
        rows.append(row);(ROOT/'parser-profile.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
