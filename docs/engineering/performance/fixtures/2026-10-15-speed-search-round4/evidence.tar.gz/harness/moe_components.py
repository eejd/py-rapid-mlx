"""Screen existing expert projection fusion and forced sorting; no model claim."""
import gc
import json
from pathlib import Path
import statistics
import sys
import time

ROOT=Path('/private/tmp/rapid-mlx-speed-search-round4')
assert (ROOT/'.task-owner').read_text()=='vector-speed-search-round4-v1'
sys.path.insert(0,str(ROOT/'src'))
import mlx.core as mx
import mlx.nn as nn
import mlx_lm.models.switch_layers as lm
from mlx_vlm.models.gemma4.language import GeGLU
from rapid_mlx.moe_fusion import fuse_gate_up

def linear(cls, arrays):
    out=cls.__new__(cls);nn.Module.__init__(out)
    out.weight,out.scales,out.biases=arrays
    out.group_size=64;out.bits=4;out.mode='affine';out.eval()
    return out

def build(family, weights, activation):
    out=family.SwitchGLU.__new__(family.SwitchGLU);nn.Module.__init__(out)
    out.gate_proj=linear(family.QuantizedSwitchLinear,weights[0])
    out.up_proj=linear(family.QuantizedSwitchLinear,weights[1])
    out.down_proj=linear(family.QuantizedSwitchLinear,weights[2])
    out.activation=activation;out.eval()
    return out

results=[]
for name,width,intermediate,experts,family,activation in [
    ('gemma_moe_shape',2816,2112,128,lm,GeGLU()),
    ('qwen_moe_shape',2048,512,256,lm,lm.SwiGLU()),
]:
    weights=[]
    for seed,(output,input_) in enumerate([(intermediate,width),(intermediate,width),(width,intermediate)]):
        dense=(mx.random.normal((experts,output,input_),key=mx.random.key(201+seed))*.02).astype(mx.bfloat16)
        quant=mx.quantize(dense,group_size=64,bits=4);mx.eval(quant)
        weights.append(quant);del dense;mx.clear_cache()
    stock=build(family,weights,activation);packed=build(family,weights,activation)
    enrolled=fuse_gate_up(packed);assert enrolled==1
    assert packed.gate_up_proj.weight.shape[1]==2*intermediate
    for count in [1,4,16,128]:
        x=(mx.random.normal((1,count,width),key=mx.random.key(301))*.3).astype(mx.bfloat16)
        indices=mx.argpartition(mx.random.uniform(shape=(1,count,experts),key=mx.random.key(302)),kth=experts-8,axis=-1)[...,-8:]
        mx.eval(x,indices)
        def sorted_call(module):
            expanded=mx.expand_dims(x,(-2,-3))
            ordered,idx,inv=family._gather_sort(expanded,indices)
            merged=getattr(module,'gate_up_proj',None)
            if merged is None:
                gate=module.gate_proj(ordered,idx,sorted_indices=True)
                up=module.up_proj(ordered,idx,sorted_indices=True)
            else:
                gate,up=mx.split(merged(ordered,idx,sorted_indices=True),2,axis=-1)
            y=module.down_proj(module.activation(up,gate),idx,sorted_indices=True)
            return family._scatter_unsort(y,inv,indices.shape).squeeze(-2)
        funcs={'stock':lambda:stock(x,indices),'packed':lambda:packed(x,indices),
               'sorted_stock':lambda:sorted_call(stock),'sorted_packed':lambda:sorted_call(packed)}
        ref=funcs['stock']();mx.eval(ref);numerical={}
        for key,fn in funcs.items():
            out=fn();mx.eval(out)
            numerical[key]={'storage_equal':bool(mx.array_equal(ref.view(mx.uint16),out.view(mx.uint16)).item()),
                            'finite':bool(mx.all(mx.isfinite(out)).item()),
                            'max_abs':float(mx.max(mx.abs(ref.astype(mx.float32)-out.astype(mx.float32))).item())}
            for _ in range(3):mx.eval(fn())
        times={key:[] for key in funcs}
        for repeat in range(10):
            for key in (list(funcs) if repeat%2==0 else list(reversed(funcs))):
                at=time.perf_counter()
                for _ in range(4):mx.eval(funcs[key]())
                times[key].append((time.perf_counter()-at)/4)
        row={'shape':name,'width':width,'intermediate':intermediate,'experts':experts,'top_k':8,'rows':count,
             'existing_fusion_enrolled':enrolled,'numerical':numerical,'samples_s':times,
             'median_s':{k:statistics.median(v) for k,v in times.items()}}
        results.append(row);(ROOT/'moe-components.json').write_text(json.dumps(results,indent=2));print(json.dumps(row),flush=True)
    del weights,stock,packed,x,indices,ref,out;gc.collect();mx.clear_cache()
