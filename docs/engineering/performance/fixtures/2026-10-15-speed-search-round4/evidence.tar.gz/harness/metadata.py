from pathlib import Path
import hashlib,importlib.metadata as m,json,platform,sys,subprocess
r=Path('/private/tmp/rapid-mlx-speed-search-round4')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
versions={n:m.version(n) for n in ['mlx','mlx-lm','mlx-vlm','numpy','psutil']}
deps={}
for name,d in json.loads((r/'official-dependency-files.json').read_text()).items():
 assert versions[name]==d['version']
 dist=m.distribution(name)
 assert all(sha(Path(dist.locate_file(n)))==h for n,h in d['python_files'].items())
 deps[name]={'version':d['version'],'verified_python_files':len(d['python_files']),'official_wheel_sha256':d['wheel_sha256']}
result={'source_commit':'5c70e238f6068d373553c48d92786a5cf333d05b','source_hashes':{n:sha(r/'src'/n) for n in ['rapid_mlx/moe_fusion.py','rapid_mlx/engine/batched.py']},'harness_sha256':{'moe_components.py':sha(r/'moe_components.py')},'versions':versions,'dependencies':deps,'python':sys.version,'platform':platform.platform(),'chip':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':int(subprocess.check_output(['sysctl','-n','hw.memsize'],text=True)),'limitation':'Synthetic expert-layer geometry, no model loaded or HTTP performance claim.'}
(r/'metadata.json').write_text(json.dumps(result,indent=2));print('Official dependency and source/harness identities verified')
