"""Component screening only: no model-quality or HTTP speed claim."""
import gc
import json
from pathlib import Path
import statistics
import time

import mlx.core as mx

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round3')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-round3-v1'
rows = []
for width, output in [(2560, 10240), (10240, 2560), (2560, 2560), (5120, 17408)]:
    w = (mx.random.normal((output, width), key=mx.random.key(width + output)) * .02).astype(mx.bfloat16)
    q, scales, biases = mx.quantize(w, group_size=64, bits=4)
    mx.eval(q, scales, biases)
    del w
    dense = mx.dequantize(q, scales, biases, group_size=64, bits=4)
    mx.eval(dense)
    for count in [1, 128, 512, 2048]:
        x = (mx.random.normal((1, count, width), key=mx.random.key(count)) * .3).astype(mx.bfloat16)
        fns = {
            'quantized': lambda: mx.quantized_matmul(x, q, scales, biases, transpose=True, group_size=64, bits=4),
            'dequant_dense': lambda: x @ mx.dequantize(q, scales, biases, group_size=64, bits=4).T,
            'cached_dense': lambda: x @ dense.T,
        }
        reference = fns['quantized']()
        mx.eval(reference)
        numerical = {}
        for name, fn in fns.items():
            y = fn(); mx.eval(y)
            numerical[name] = {
                'finite': bool(mx.all(mx.isfinite(y)).item()),
                'exact': bool(mx.array_equal(reference, y).item()),
                'max_abs': float(mx.max(mx.abs(reference.astype(mx.float32) - y.astype(mx.float32))).item()),
                'relative_rms': float(mx.sqrt(mx.mean(mx.square(reference.astype(mx.float32) - y.astype(mx.float32))) / mx.mean(mx.square(reference.astype(mx.float32)))).item()),
            }
            assert numerical[name]['finite']
            for _ in range(3): mx.eval(fn())
        times = {name: [] for name in fns}
        for repeat in range(8):
            for name in (list(fns) if repeat % 2 == 0 else list(reversed(fns))):
                at = time.perf_counter()
                for _ in range(4): mx.eval(fns[name]())
                times[name].append((time.perf_counter() - at) / 4)
        row = {'width': width, 'output': output, 'rows': count, 'numerical': numerical,
               'extra_cached_weight_bytes': dense.nbytes, 'samples_s': times,
               'median_s': {k: statistics.median(v) for k, v in times.items()}}
        rows.append(row)
        (ROOT / 'quant-prefill.json').write_text(json.dumps(rows, indent=2))
        print(json.dumps(row), flush=True)
    del dense, q, scales, biases, reference, y, x
    gc.collect(); mx.clear_cache()
