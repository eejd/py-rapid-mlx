"""Research only: retain a completed text turn through existing exact APC."""
import atexit
import json
import os
from pathlib import Path
import sys
import time
import mlx.core as mx

ROOT=Path('/private/tmp/rapid-mlx-speed-search-round3')
assert (ROOT/'.task-owner').read_text()=='vector-speed-search-round3-v1'
sys.path.insert(0,str(ROOT/'src'))
variant=os.environ['STUDY_VARIANT'];assert variant in ['baseline','tail']
from rapid_mlx import mllm_batch_generator as bg
from rapid_mlx.models.mlx_vlm_vendored.apc import _clone_prompt_cache_for_apc
events=[]
init_original=bg.MLLMBatchGenerator.__init__
def init(self,*args,**kwargs):
    init_original(self,*args,**kwargs)
    model=self.model
    assert type(model).__module__=='mlx_vlm.models.gemma4.gemma4'
    # Apply the previously qualified last-row optimization equally to both
    # arms so this experiment cannot rediscover that earlier prefill gain.
    class LastRow:
        def __getattr__(self,name):return getattr(model,name)
        def __call__(self,input_ids,*args,**kwargs):
            kwargs['logits_to_keep']=1
            return model(input_ids,*args,**kwargs)
    self.model=LastRow()
    events.append({'cache_mode':self._prefix_cache_mode,'last_row_both_arms':True})
    manager=self._prefix_cache
    assert manager is not None
    original_store=manager.store_exact_cache
    diagnosed=[False]
    def store(ids,caches,**kwargs):
        result=original_store(ids,caches,**kwargs)
        if result and not diagnosed[0] and 250<len(ids)<450:
            diagnosed[0]=True
            entries=[e for e in manager._exact_cache.values() if tuple(e.token_ids)==tuple(ids)]
            assert len(entries)==1
            stored=entries[0].prompt_cache
            def tensors(value):
                if isinstance(value,mx.array):return [value]
                if isinstance(value,(tuple,list)):return [a for v in value for a in tensors(v)]
                return []
            bits=[];metadata=[]
            for a,b in zip(caches,stored):
                av,bv=tensors(a.state),tensors(b.state)
                assert len(av)==len(bv)
                for x,y in zip(av,bv):
                    integer=mx.uint16 if x.dtype in (mx.bfloat16,mx.float16) else mx.uint32
                    bits.append(bool(mx.array_equal(x.view(integer),y.view(integer)).item()))
                metadata.append({'kind':type(a).__name__,'same_kind':type(a)==type(b),
                    'offset_equal':int(a.offset)==int(b.offset),
                    'idx_equal':getattr(a,'_idx',None)==getattr(b,'_idx',None)})
            left=_clone_prompt_cache_for_apc(caches);right=_clone_prompt_cache_for_apc(stored)
            suffix=mx.array([[7,8,9]])
            a=model(suffix,cache=left,pixel_values=None,logits_to_keep=1).logits
            b=model(suffix,cache=right,pixel_values=None,logits_to_keep=1).logits
            mx.eval(a,b)
            exact=bool(mx.array_equal(a.view(mx.uint32 if a.dtype==mx.float32 else mx.uint16),b.view(mx.uint32 if b.dtype==mx.float32 else mx.uint16)).item())
            fresh=model.language_model.make_cache()
            model(mx.array([ids]),cache=fresh,pixel_values=None,logits_to_keep=1)
            c=model(suffix,cache=fresh,pixel_values=None,logits_to_keep=1).logits
            mx.eval(c)
            delta=b.astype(mx.float32)-c.astype(mx.float32)
            events.append({'diagnostic':True,'snapshot_tokens':len(ids),'clone_array_bits':bits,'metadata':metadata,
                'clone_resume_logits_bits_equal':exact,'fresh_recompute_max_abs_logits':float(mx.max(mx.abs(delta)).item()),
                'fresh_recompute_relative_rms_logits':float(mx.sqrt(mx.mean(mx.square(delta))/mx.mean(mx.square(c.astype(mx.float32)))).item()),
                'fresh_recompute_same_argmax':int(mx.argmax(b).item())==int(mx.argmax(c).item()),
                'fresh_recompute_finite':bool(mx.all(mx.isfinite(c)).item())})
        return result
    manager.store_exact_cache=store

bg.MLLMBatchGenerator.__init__=init
process_original=bg.MLLMBatchGenerator._process_prompts
def process(self,requests):
    for req in requests:
        req._round3_text_only=bg._is_text_only_request(req) and not req.extra_kwargs and bg._attention_mask_is_droppable(req.attention_mask)
    out=process_original(self,requests)
    for req in requests:events.append({'request':req.request_id,'prompt':len(req.full_prompt_token_ids),'cached':req.cached_tokens})
    return out
bg.MLLMBatchGenerator._process_prompts=process
next_original=bg.MLLMBatchGenerator._next
def step(self):
    batch=self.active_batch
    requests={req.request_id:req for req in batch.requests} if batch else {}
    out=next_original(self)
    for response in out:
        req=requests.get(response.request_id)
        if req is None or response.finish_reason not in ['length','stop'] or not getattr(req,'_round3_text_only',False):continue
        if self._prefix_cache_mode!='exact' or self._prefix_cache is None:continue
        ids=req.full_prompt_token_ids+req.output_tokens
        offsets=[int(getattr(c,'offset',-1)) for c in response.prompt_cache]
        aligned=all(n==len(ids) for n in offsets)
        row={'request':req.request_id,'completed_tokens':len(req.output_tokens),'snapshot_tokens':len(ids),'aligned':aligned,'stored':False,'finish':response.finish_reason,'control_stop':bool(response.token_is_stop_token)}
        if variant=='tail' and aligned:
            at=time.perf_counter()
            row['stored']=self._prefix_cache.store_exact_cache(ids,response.prompt_cache,extra_hash=self._prefix_cache_extra_hash)
            self._enforce_exact_cache_budget(self._prefix_cache)
            row['store_s']=time.perf_counter()-at
        events.append(row)
    return out
bg.MLLMBatchGenerator._next=step
@atexit.register
def save():
    (ROOT/(os.environ['STUDY_RUN']+'-instrumentation.json')).write_text(json.dumps({'variant':variant,'events':events},indent=2))
from rapid_mlx.cli import cli_entrypoint
sys.argv=[sys.argv[0],'serve',os.environ['STUDY_MODEL'],'--host','127.0.0.1','--port','18647','--served-model-name','decode-study','--no-spec-decode','--disable-disk-caches','--disable-model-downloads','--log-level','WARNING']
cli_entrypoint()
