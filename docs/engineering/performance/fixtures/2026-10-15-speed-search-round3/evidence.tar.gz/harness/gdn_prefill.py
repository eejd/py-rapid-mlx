"""Screen an existing parallel prefill operator; never change serving defaults."""
import json
from pathlib import Path
import statistics
import time

import mlx.core as mx
from mlx_vlm.models.qwen3_5 import gated_delta as gd

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round3')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-round3-v1'
rows = []
for length in [128, 512, 2048]:
    q = mx.random.normal((1, length, 16, 128), key=mx.random.key(101)).astype(mx.bfloat16)
    k = mx.random.normal(q.shape, key=mx.random.key(102)).astype(mx.bfloat16)
    q = (128**-1) * mx.fast.rms_norm(q, None, 1e-6)
    k = (128**-.5) * mx.fast.rms_norm(k, None, 1e-6)
    v = mx.random.normal((1, length, 32, 128), key=mx.random.key(103)).astype(mx.bfloat16)
    g = mx.random.uniform(.1, .99, (1, length, 32), key=mx.random.key(104))
    beta = mx.random.uniform(.1, .9, (1, length, 32), key=mx.random.key(105)).astype(mx.bfloat16)
    state = mx.random.normal((1,32,128,128), key=mx.random.key(106)) * .01
    mx.eval(q,k,v,g,beta,state)
    funcs = {'sequential_metal': lambda: gd.gated_delta_kernel(q,k,v,g,beta,state,None)}
    for chunk in [16,32,64]:
        funcs[str(chunk)] = lambda chunk=chunk: gd.gated_delta_chunked(q,k,v,g,beta,state,None,C=chunk)
    reference=funcs['sequential_metal']();mx.eval(reference)
    numerics={}
    for name, fn in funcs.items():
        out=fn();mx.eval(out)
        numerics[name]=[{
            'finite':bool(mx.all(mx.isfinite(y)).item()),
            'exact':bool(mx.array_equal(x.view(mx.uint16 if x.dtype==mx.bfloat16 else mx.uint32), y.view(mx.uint16 if y.dtype==mx.bfloat16 else mx.uint32)).item()),
            'max_abs':float(mx.max(mx.abs(x.astype(mx.float32)-y.astype(mx.float32))).item()),
            'relative_rms':float(mx.sqrt(mx.mean(mx.square(x.astype(mx.float32)-y.astype(mx.float32)))/mx.mean(mx.square(x.astype(mx.float32)))).item()),
        } for x,y in zip(reference,out)]
        assert all(c['finite'] for c in numerics[name]),(length,name)
        for _ in range(2):mx.eval(fn())
    timings={name:[] for name in funcs}
    for repeat in range(6):
        for name in (list(funcs) if repeat%2==0 else list(reversed(funcs))):
            at=time.perf_counter();mx.eval(funcs[name]());timings[name].append(time.perf_counter()-at)
    row={'length':length,'numerical':numerics,'samples_s':timings,'median_s':{name:statistics.median(v) for name,v in timings.items()}}
    rows.append(row);(ROOT/'gdn-prefill.json').write_text(json.dumps(rows,indent=2));print(json.dumps(row),flush=True)
