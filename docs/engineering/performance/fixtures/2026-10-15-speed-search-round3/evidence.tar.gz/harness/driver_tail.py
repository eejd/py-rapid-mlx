import os,subprocess,json
from pathlib import Path
r=Path('/private/tmp/rapid-mlx-speed-search-round3');status=[]
for model,label in [('gemma4b','E4'),('gemma2b','E2')]:
 for variant,trial in [('baseline',label+'-A1'),('tail',label+'-B1'),('tail',label+'-B2'),('baseline',label+'-A2')]:
  with (r/('tail-'+trial+'.log')).open('w') as f:p=subprocess.run([str(r/'venv/bin/python'),str(r/'run_tail_models.py'),variant,model],cwd=r,env=dict(os.environ,STUDY_TRIAL=trial),stdout=f,stderr=subprocess.STDOUT)
  status.append({'model':model,'variant':variant,'trial':trial,'exit':p.returncode});(r/'tail-status.json').write_text(json.dumps(status,indent=2));print(status[-1],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
