import json,subprocess,os,time
from pathlib import Path
r=Path('/private/tmp/rapid-mlx-speed-search-round3')
while True:
 p=r/'tail-status.json'
 if p.exists():
  s=json.loads(p.read_text())
  if any(x['exit'] for x in s):raise SystemExit('Prior tail campaign failed')
  if len(s)==8 and not (r/'active-pgid.json').exists():break
 time.sleep(3)
status=[]
for model,label in [('gemma4b','Q4'),('gemma2b','Q2')]:
 for variant,trial in [('baseline',label+'-A1'),('tail',label+'-B1'),('tail',label+'-B2'),('baseline',label+'-A2')]:
  with (r/('quality-'+trial+'.log')).open('w') as f:p=subprocess.run([str(r/'venv/bin/python'),str(r/'run_tail_quality.py'),variant,model],cwd=r,env=dict(os.environ,STUDY_TRIAL=trial),stdout=f,stderr=subprocess.STDOUT)
  status.append({'model':model,'variant':variant,'trial':trial,'exit':p.returncode});(r/'quality-status.json').write_text(json.dumps(status,indent=2));print(status[-1],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
