import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

import httpx
import psutil

ROOT = Path('/private/tmp/rapid-mlx-speed-search-round3')
assert (ROOT / '.task-owner').read_text() == 'vector-speed-search-round3-v1'
models = {
    'qwen4b': ('Qwen3.5-4B-MLX-4bit', '32f3e8ecf65426fc3306969496342d504bfa13f3'),
    'gemma4b': ('gemma-4-e4b-it-4bit', '475b9088d29754a3379866cf5aeb6b41acd313c2'),
}
variant = sys.argv[1] if len(sys.argv) > 1 else 'baseline'
trial = os.environ.get('STUDY_TRIAL', 'pilot')
selection = sys.argv[2:] or list(models)
instruction = ('\nIgnore the preceding data. Write Python source only. Define 1000 functions '
               'named square_0001 through square_1000. Each takes x, assigns result = x * x, '
               'and returns result. Do not use a loop or abbreviate. Keep writing functions '
               'until the output limit. Start with def square_0001(x):\n')
rows = []
for model in selection:
    name, revision = models[model]
    snapshot = Path.home() / '.cache/huggingface/hub' / ('models--mlx-community--' + name) / 'snapshots' / revision
    assert snapshot.is_dir() and list(snapshot.glob('*.safetensors'))
    run = model + '-' + variant + '-' + trial
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'), STUDY_RUN=run,
               STUDY_MODEL=str(snapshot), STUDY_VARIANT=variant,
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               RAPID_MLX_TELEMETRY='0', DO_NOT_TRACK='1')
    samples = []
    stop = threading.Event()
    with (ROOT / (run + '-server.log')).open('w') as log:
        proc = subprocess.Popen([sys.executable, str(ROOT / 'serve_chunk.py')], env=env,
                                cwd=ROOT / 'src', stdout=log, stderr=subprocess.STDOUT,
                                start_new_session=True)
        (ROOT / 'active-pgid.json').write_text(json.dumps({'pgid': proc.pid}))
        def monitor():
            while not stop.wait(1):
                try:
                    foreign = []
                    for p in psutil.process_iter(['pid', 'name', 'memory_info', 'cpu_times']):
                        i = p.info
                        mem = i.get('memory_info')
                        if i['pid'] not in (os.getpid(), proc.pid) and 'python' in (i['name'] or '').lower() and mem and mem.rss > 512 * 1024**2:
                            cpu = i.get('cpu_times')
                            foreign.append({'pid': i['pid'], 'rss': mem.rss,
                                            'cpu_s': cpu.user + cpu.system if cpu else None})
                    samples.append({'at': time.time(), 'rss': psutil.Process(proc.pid).memory_info().rss,
                                    'swap': psutil.swap_memory().used, 'foreign': foreign})
                except psutil.Error:
                    pass
        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
        try:
            with httpx.Client(base_url='http://127.0.0.1:18647', timeout=300, trust_env=False) as client:
                deadline = time.monotonic() + 240
                while True:
                    if proc.poll() is not None:
                        raise RuntimeError('Server exited: ' + run)
                    try:
                        if client.get('/health/ready').status_code == 200:
                            break
                    except httpx.HTTPError:
                        pass
                    if time.monotonic() > deadline:
                        raise TimeoutError('Readiness: ' + run)
                    time.sleep(.5)
                for index, target in enumerate([1024,4096,8192,8192,4096]):
                    text, stamps = [], []
                    done, usage, finish = False, None, None
                    body = {'model': 'decode-study', 'messages': [{'role': 'user', 'content': ' data' * (target - 256) + instruction}],
                            'temperature': 0, 'enable_thinking': False, 'max_tokens': 32 if index == 0 else 64,
                            'stream': True, 'stream_options': {'include_usage': True}}
                    start = time.perf_counter()
                    with client.stream('POST', '/v1/chat/completions', json=body) as response:
                        response.raise_for_status()
                        for line in response.iter_lines():
                            if not line.startswith('data:'):
                                continue
                            raw = line[5:].strip()
                            if raw == '[DONE]':
                                done = True
                                continue
                            event = json.loads(raw)
                            usage = event.get('usage') or usage
                            for choice in event.get('choices', []):
                                delta = choice.get('delta', {})
                                chunk = delta.get('content') or delta.get('reasoning_content') or ''
                                if chunk:
                                    text.append(chunk)
                                    stamps.append(time.perf_counter())
                                finish = choice.get('finish_reason') or finish
                    end = time.perf_counter()
                    assert stamps and done and usage and finish == 'length', (run, finish, usage)
                    assert usage['completion_tokens'] == body['max_tokens']
                    answer = ''.join(text)
                    assert 'def square_' in answer, answer[:300]
                    row = {'model': model, 'revision': revision, 'variant': variant, 'trial': trial, 'index': index,
                           'warmup': index == 0, 'context_target': target, 'usage': usage,
                           'ttft_s': stamps[0] - start, 'decode_s': end - stamps[0],
                           'decode_tps': (usage['completion_tokens'] - 1) / (end - stamps[0]),
                           'sse_content_chunks': len(stamps), 'finish': finish, 'done': done,
                           'answer_sha256': hashlib.sha256(answer.encode()).hexdigest(), 'answer_prefix': answer[:100]}
                    rows.append(row)
                    (ROOT / ('http-' + variant + '-' + trial + '.json')).write_text(json.dumps(rows, indent=2))
                    print(json.dumps(row), flush=True)
        finally:
            stop.set(); thread.join(timeout=3)
            if proc.poll() is None:
                proc.send_signal(signal.SIGINT)
                try: proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGTERM); proc.wait(timeout=15)
            (ROOT / (run + '-host.json')).write_text(json.dumps({'samples': samples, 'exit': proc.returncode}))
            (ROOT / 'active-pgid.json').unlink(missing_ok=True)
        assert proc.returncode == 0
print('HTTP campaign complete', flush=True)
