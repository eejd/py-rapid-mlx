import json,os,subprocess
from pathlib import Path
r=Path('/private/tmp/rapid-mlx-speed-search-round3');status=[]
for model in ['qwen4b','gemma4b']:
 for variant,trial in [('2048','C-base1'),('512','C-512'),('1024','C-1024'),('4096','C-4096'),('2048','C-base2')]:
  with (r/('chunk-'+model+'-'+trial+'.log')).open('w') as f:
   p=subprocess.run([str(r/'venv/bin/python'),str(r/'run_chunk.py'),variant,model],cwd=r,env=dict(os.environ,STUDY_TRIAL=trial),stdout=f,stderr=subprocess.STDOUT)
  status.append({'model':model,'variant':variant,'trial':trial,'exit':p.returncode});(r/'chunk-status.json').write_text(json.dumps(status,indent=2));print(status[-1],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
