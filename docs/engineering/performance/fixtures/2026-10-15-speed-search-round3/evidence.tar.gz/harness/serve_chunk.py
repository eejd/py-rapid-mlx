import atexit,collections,json,os,sys
from pathlib import Path
ROOT=Path('/private/tmp/rapid-mlx-speed-search-round3')
assert (ROOT/'.task-owner').read_text()=='vector-speed-search-round3-v1'
sys.path.insert(0,str(ROOT/'src'))
variant=os.environ['STUDY_VARIANT'];size=int(variant)
assert size in [256,512,1024,2048,4096]
import mlx.core as mx
import rapid_mlx.mllm_batch_generator as mllm
from rapid_mlx.engine.batched import BatchedEngine
mllm._MLLM_PREFILL_CHUNK_TOKENS=size
counts=collections.Counter()
original_start=BatchedEngine.start
async def start(self):
 await original_start(self)
 def install():
  cls=type(self._model);orig=cls.__call__
  def call(obj,*args,**kwargs):
   x=args[0] if args else kwargs.get('input_ids')
   if x is not None:counts[int(x.shape[-1])]+=1
   return orig(obj,*args,**kwargs)
  cls.__call__=call
 self._model_load_executor.submit(install).result()
BatchedEngine.start=start
@atexit.register
def save():
 (ROOT/(os.environ['STUDY_RUN']+'-instrumentation.json')).write_text(json.dumps({'variant':variant,'forward_rows':dict(counts),'metal_peak_bytes':mx.get_peak_memory()},indent=2))
from rapid_mlx.cli import cli_entrypoint
sys.argv=[sys.argv[0],'serve',os.environ['STUDY_MODEL'],'--host','127.0.0.1','--port','18647','--served-model-name','decode-study','--no-spec-decode','--disable-prefix-cache','--disable-disk-caches','--disable-model-downloads','--prefill-step-size',str(size),'--log-level','WARNING']
cli_entrypoint()
